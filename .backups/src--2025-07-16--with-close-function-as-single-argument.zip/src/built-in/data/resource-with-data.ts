import { type OnResourceClose, Resource } from '../../resource/resource.js';

export class ResourceWithData<GData> extends Resource {
  readonly #data: GData;

  constructor(data: GData, close?: OnResourceClose) {
    super(close);
    this.#data = data;
  }

  get data(): GData {
    return this.#data;
  }
}
