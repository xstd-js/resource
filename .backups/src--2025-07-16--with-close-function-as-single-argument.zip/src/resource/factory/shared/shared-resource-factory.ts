import { type Abortable, abortify } from '@xstd/abortable';
import { CloseResource, OnResourceClose } from '../../resource.js';

export interface OpenSharedResource<GData> {
  (signal: AbortSignal): Promise<SharedResourceLike<GData>> | SharedResourceLike<GData>;
}

export interface SharedResourceLike<GData> {
  readonly data: GData;
  readonly close: OnResourceClose;
}

export interface SharedResource<GData> {
  readonly data: GData;
  readonly close: CloseResource;
}

export class SharedResourceFactory<GData> {
  readonly #open: OpenSharedResource<GData>;

  #usageCount: number;
  #openController: AbortController | undefined;
  #openPromise: Promise<SharedResourceLike<GData>> | undefined;
  #closePromise: Promise<void> | undefined;

  constructor(open: OpenSharedResource<GData>) {
    this.#open = open;
    this.#usageCount = 0;
  }

  async open(options?: Abortable): Promise<SharedResource<GData>> {
    options?.signal?.throwIfAborted();

    // await previous close
    if (this.#closePromise !== undefined) {
      await abortify(this.#closePromise, options);
    }

    this.#usageCount++;

    // open the common resource
    if (this.#openPromise === undefined) {
      const openController: AbortController = new AbortController();
      this.#openController = openController;

      this.#openPromise = Promise.try(this.#open, openController.signal).finally((): void => {
        openController.abort();
      });
    }

    // await the opening of the common resource
    let commonResource: SharedResourceLike<GData>;
    try {
      commonResource = await abortify(this.#openPromise!, options);
    } catch (error: unknown) {
      // failed to open for the common resource
      this.#usageCount--;

      if (this.#usageCount === 0) {
        this.#openController!.abort();
        this.#openController = undefined;
        this.#openPromise = undefined;
      }

      throw error;
    }

    let closed: boolean = false;

    return {
      data: commonResource.data,
      close: async (reason: unknown): Promise<void> => {
        if (closed) {
          throw new Error('Already closed.');
        } else {
          closed = true;

          this.#usageCount--;

          if (this.#usageCount === 0) {
            this.#openPromise = undefined;

            await (this.#closePromise = commonResource.close(reason).finally((): void => {
              this.#closePromise = undefined;
            }));
          }
        }
      },
    };
  }
}
