export interface OnResourceClose {
  (reason: unknown): PromiseLike<any> | any;
}

export interface CloseResource {
  (reason?: unknown): Promise<void>;
}

// export interface InitResource {
//   (signal: AbortSignal): OnResourceClose | void | undefined;
// }

export class Resource {
  readonly #controller: AbortController;
  readonly #closePromise: PromiseWithResolvers<void>;
  readonly #close: OnResourceClose | void | undefined;

  constructor(close?: OnResourceClose | void | undefined) {
    this.#controller = new AbortController();
    this.#closePromise = Promise.withResolvers();
    this.#close = close;
  }

  throwIfClosed(): void {
    if (this.closeSignal.aborted) {
      throw new Error('Resource closed.');
    }
  }

  get closeSignal(): AbortSignal {
    return this.#controller.signal;
  }

  get closed(): Promise<void> {
    return this.#closePromise.promise;
  }

  close(reason?: unknown): Promise<void> {
    if (!this.#controller.signal.aborted) {
      this.#controller.abort(reason);

      this.#closePromise.resolve(
        this.#close === undefined ? undefined : Promise.try(this.#close, reason),
      );
    }

    return this.#closePromise.promise;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }
}
