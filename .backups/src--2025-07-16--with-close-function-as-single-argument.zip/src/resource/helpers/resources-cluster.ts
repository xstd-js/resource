import { Resource } from '../resource.js';
import { runConcurrentlyVoidPromises } from './run-concurrently-void-promises.js';

/**
 * TODO
 */
export class ResourcesCluster {
  readonly #resources: Set<Resource>;

  constructor() {
    this.#resources = new Set<Resource>();
  }

  add<GResource extends Resource>(resource: GResource): GResource {
    resource.throwIfClosed();

    this.#resources.add(resource);

    resource.closed.finally((): void => {
      this.#resources.delete(resource);
    });

    return resource;
  }

  closeResources(reason: unknown): Promise<void> {
    return runConcurrentlyVoidPromises(
      this.#resources.values().map((resource: Resource): Promise<void> => {
        return resource.close(reason);
      }),
    );
  }

  awaitResourcesClosed(): Promise<void> {
    return runConcurrentlyVoidPromises(
      this.#resources.values().map((resource: Resource): Promise<void> => {
        return resource.closed;
      }),
    );
  }
}
