export interface AsyncTask<GReturn> {
  (): PromiseLike<GReturn> | GReturn;
}

export class AsyncTasksManager {
  readonly #pendingTasks: Set<Promise<unknown>>;

  constructor() {
    this.#pendingTasks = new Set<Promise<unknown>>();
  }

  async run<GReturn>(task: AsyncTask<GReturn> | PromiseLike<GReturn>): Promise<GReturn> {
    const taskPromise: Promise<GReturn> =
      typeof task === 'function' ? Promise.try(task) : Promise.resolve(task);

    this.#pendingTasks.add(taskPromise);

    try {
      return await taskPromise;
    } finally {
      this.#pendingTasks.delete(taskPromise);
    }
  }

  async awaitPendingTasksResolution(): Promise<void> {
    await Promise.allSettled(this.#pendingTasks.values());
  }
}
