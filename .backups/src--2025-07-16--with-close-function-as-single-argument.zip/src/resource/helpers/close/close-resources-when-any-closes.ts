import { type Resource } from '../../resource.js';
import { closeChildResourceWhenParentCloses } from './close-child-resource-when-parent-closes.js';

export function closeResourcesWhenAnyCloses(resources: Iterable<Resource>): void {
  for (const a of resources) {
    for (const b of resources) {
      closeChildResourceWhenParentCloses(a, b);
    }
  }
}
