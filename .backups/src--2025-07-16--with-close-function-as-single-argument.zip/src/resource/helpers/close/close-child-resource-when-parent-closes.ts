import { type Resource } from '../../resource.js';

export function closeChildResourceWhenParentCloses<GChild extends Resource>(
  child: GChild,
  parent: Resource,
): GChild {
  if (child !== parent && !child.closeSignal.aborted) {
    if (parent.closeSignal.aborted) {
      void child.close(parent.closeSignal.reason);
    } else {
      parent.closeSignal.addEventListener(
        'abort',
        (): void => {
          void child.close(parent.closeSignal.reason);
        },
        {
          signal: child.closeSignal,
        },
      );
    }
  }

  return child;
}
