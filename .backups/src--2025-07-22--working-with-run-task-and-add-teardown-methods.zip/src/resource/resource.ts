import { type Abortable, mergeAbortSignals } from '@xstd/abortable';
import { noop } from '@xstd/noop';
import { registerResource, registerResourceRelation } from './graph.private/graph.js';

export interface CloseResource {
  (reason?: unknown): Promise<void>;
}

export interface ResourceTask<GReturn> {
  (signal: AbortSignal): PromiseLike<GReturn> | GReturn;
}

export interface ResourceTeardown {
  (reason: unknown): PromiseLike<any> | any;
}

export interface ForkResourceOptions extends Abortable {
  readonly closesWithForked?: boolean;
}

export class Resource {
  // close
  readonly #controller: AbortController;
  readonly #closePromise: PromiseWithResolvers<void>;

  // tasks
  readonly #pendingTasks: Promise<unknown>[];
  readonly #teardowns: ResourceTeardown[];

  constructor() {
    this.#controller = new AbortController();
    this.#closePromise = Promise.withResolvers();
    this.#pendingTasks = [];
    this.#teardowns = [];

    // TODO DEBUG_MODE
    registerResource(this);
  }

  /* CLOSE */

  throwIfClosed(): void {
    if (this.closeSignal.aborted) {
      throw new Error('Resource closed.');
    }
  }

  get closeSignal(): AbortSignal {
    return this.#controller.signal;
  }

  get closed(): Promise<void> {
    return this.#closePromise.promise;
  }

  close(reason?: unknown): Promise<void> {
    if (!this.#controller.signal.aborted) {
      this.#controller.abort(reason);

      this.#closePromise.resolve(
        Promise.allSettled(this.#pendingTasks).then(async (): Promise<void> => {
          let isErrored: boolean = false;
          let error: unknown;

          for (let i: number = this.#teardowns.length - 1; i >= 0; i--) {
            try {
              await this.#teardowns[i](reason);
            } catch (closeError: unknown) {
              if (isErrored) {
                error = new SuppressedError(closeError, error);
              } else {
                isErrored = true;
                error = closeError;
              }
            }
          }

          if (isErrored) {
            throw error;
          }
        }),
      );
    }

    return this.#closePromise.promise;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }

  /* TASKS */

  async runTask<GReturn>(
    task: ResourceTask<GReturn> | PromiseLike<GReturn>,
    { signal }: Abortable = {},
  ): Promise<GReturn> {
    this.throwIfClosed();

    const controller: AbortController = new AbortController();

    const taskPromise: Promise<GReturn> =
      typeof task === 'function' ?
        Promise.try(task, mergeAbortSignals([this.#controller.signal, controller.signal, signal]))
      : Promise.resolve(task);

    this.#pendingTasks.push(taskPromise);

    try {
      return await taskPromise;
    } finally {
      controller.abort();
      this.#pendingTasks.splice(this.#pendingTasks.indexOf(taskPromise), 1);
    }
  }

  addTeardown(teardown: ResourceTeardown, { signal }: Abortable = {}): this {
    if (!signal?.aborted) {
      this.throwIfClosed();

      this.#teardowns.push(teardown);

      signal?.addEventListener(
        'abort',
        (): void => {
          const index: number = this.#teardowns.indexOf(teardown);

          if (this.#controller.signal.aborted) {
            this.#teardowns[index] = noop;
          } else {
            this.#teardowns.splice(index, 1);
          }
        },
        {
          signal: this.#controller.signal,
        },
      );
    }

    return this;
  }

  closesWith(...resources: Resource[]): this {
    this.throwIfClosed();

    for (const resource of resources) {
      if (resource.closeSignal.aborted) {
        void this.close(resource.closeSignal.reason);
        break;
      } else {
        // TODO DEBUG_MODE
        registerResourceRelation(resource, 'close', this);

        resource.closeSignal.addEventListener(
          'abort',
          (): void => {
            void this.close(resource.closeSignal.reason);
          },
          {
            signal: this.closeSignal,
          },
        );
      }
    }

    return this;
  }

  fork<GResource extends Resource>(
    resource: GResource,
    { signal, closesWithForked = false }: ForkResourceOptions = {},
  ): GResource {
    const controller: AbortController = new AbortController();

    // TODO DEBUG_MODE
    registerResourceRelation(this, 'fork', resource);

    this.addTeardown(
      (reason: unknown): Promise<void> => {
        return resource.close(reason);
      },
      {
        signal:
          signal === undefined ? controller.signal : AbortSignal.any([signal, controller.signal]),
      },
    );

    resource.closed.finally((): void => {
      controller.abort();
    });

    if (closesWithForked) {
      this.closesWith(resource);
    }

    return resource;
  }
}
