import { Resource } from '../../resource/resource.js';

export class DataResource<GData> extends Resource {
  readonly #data: GData;

  constructor(data: GData) {
    super();
    this.#data = data;
  }

  get data(): GData {
    return this.#data;
  }
}
