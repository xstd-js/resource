import { abortify } from '@xstd/abortable';
import { CompleteError } from '@xstd/custom-error';
import mqtt, { IDisconnectPacket, IPublishPacket, ISubscriptionGrant, MqttClient } from 'mqtt';
import { OpenResourceOptions } from '../../../resource/factory/open-resource.js';
import { SharedResourceFactory } from '../../../resource/factory/shared/shared-resource-factory.js';
import { Resource } from '../../../resource/resource.js';
import { EmitterResource } from '../../emitter-resource/emitter-resource.js';
import { MqttTopic } from '../topic/mqtt-topic.js';
import { MqttPublishPacket } from './types/mqtt-publish-packet.js';
import { MqttResourcePublishOptions } from './types/mqtt-resource-publish-options.js';
import { MqttResourceSubscribeOptions } from './types/mqtt-resource-subscribe-options.js';

export interface MqttResourceOptions extends OpenResourceOptions {
  readonly clientId?: string;
  readonly username?: string;
  readonly password?: string;

  // readonly keepalive?: number;
  // readonly clean?: boolean;
}

interface ActiveSubscription {
  readonly qos: 0 | 1 | 2;
  readonly noLocal: boolean;
  readonly retainAsPublished: boolean;
  readonly retainHandling: 0 | 1 | 2;

  readonly shared: SharedResourceFactory<Resource, EmitterResource<MqttPublishPacket>>;
}

export class MqttResource extends Resource {
  static async open(
    url: string | URL,
    { signal, ...options }: MqttResourceOptions = {},
  ): Promise<MqttResource> {
    signal?.throwIfAborted();

    const client: MqttClient = await mqtt.connectAsync(url.toString(), {
      ...options,
      reconnectPeriod: 0,
      autoUseTopicAlias: true,
      autoAssignTopicAlias: true,
    });

    // TODO
    client.setMaxListeners(20);
    // client.setMaxListeners(50);

    if (signal?.aborted) {
      await client.endAsync();
      throw signal.reason;
    }

    return new MqttResource(client);
  }

  readonly #client: MqttClient;
  readonly #activeSubscriptions: Map<string /* topic */, ActiveSubscription>;

  private constructor(client: MqttClient) {
    super();

    this.#client = client;
    this.#activeSubscriptions = new Map<string, ActiveSubscription>();

    if (!client.connected) {
      throw new Error('MqttClient not open.');
    }

    this.addTeardown((): Promise<void> => {
      return client.endAsync();
    });

    const onClientDisconnect = (packet: IDisconnectPacket): void => {
      if (packet.reasonCode === undefined || packet.reasonCode === 0x00) {
        void this.close(new CompleteError());
      } else {
        void this.close(new Error('Disconnected', { cause: packet }));
      }
    };

    const onClientError = (error: unknown): void => {
      void this.close(error);
    };

    const onClientEnd = (): void => {
      void this.close(new Error('Client ended'));
    };

    client.on('disconnect', onClientDisconnect);
    client.on('error', onClientError);
    client.on('end', onClientEnd);

    this.closeSignal.addEventListener('abort', (): void => {
      client.off('disconnect', onClientDisconnect);
      client.off('error', onClientError);
      client.off('end', onClientEnd);
    });
  }

  publish(
    topic: string,
    payload: string | Uint8Array,
    { signal, ...options }: MqttResourcePublishOptions = {},
  ): Promise<void> {
    return this.runTask(
      async (signal: AbortSignal): Promise<void> => {
        await abortify(this.#client.publishAsync(topic, payload as any, options), {
          signal,
        });
      },
      { signal },
    );
  }

  async subscribe(
    topic: string,
    {
      qos = 0,
      noLocal = false,
      retainAsPublished = false,
      retainHandling = 0,
      signal,
    }: MqttResourceSubscribeOptions = {},
  ): Promise<EmitterResource<MqttPublishPacket>> {
    let activeSubscription: ActiveSubscription | undefined = this.#activeSubscriptions.get(topic);

    if (activeSubscription === undefined) {
      activeSubscription = {
        qos,
        noLocal,
        retainAsPublished,
        retainHandling,

        shared: new SharedResourceFactory<Resource, EmitterResource<MqttPublishPacket>>({
          main: async (signal: AbortSignal): Promise<Resource> => {
            try {
              const [granted]: ISubscriptionGrant[] = await this.#client.subscribeAsync(topic, {
                qos,
                nl: noLocal,
                rap: retainAsPublished,
                rh: retainHandling,
              });

              if (signal.aborted) {
                await this.#client.unsubscribeAsync(topic);
                throw signal.reason;
              }

              if (qos !== undefined && granted.qos < qos) {
                await this.#client.unsubscribeAsync(topic);
                throw new Error(
                  `Cannot subscribe to "${topic}" with a qos of ${qos}. Granted ${granted.qos}.`,
                );
              }

              return this.fork(
                new Resource().addTeardown(async (): Promise<void> => {
                  try {
                    await this.#client.unsubscribeAsync(topic);
                  } finally {
                    this.#activeSubscriptions.delete(topic);
                  }
                }),
              );
            } catch (error: unknown) {
              this.#activeSubscriptions.delete(topic);
              throw error;
            }
          },
          fork: (): EmitterResource<MqttPublishPacket> => {
            const { emitter, dispatch } = EmitterResource.withDispatcher<MqttPublishPacket>();

            const topicMatcher: MqttTopic = new MqttTopic(topic);

            const onClientMessage = (
              topic: string,
              payload: Buffer,
              _packet: IPublishPacket,
            ): void => {
              if (topicMatcher.matches(topic)) {
                dispatch({
                  topic,
                  payload,
                });
              }
            };

            this.#client.on('message', onClientMessage);

            emitter.closeSignal.addEventListener('abort', (): void => {
              this.#client.off('message', onClientMessage);
            });

            return emitter;
          },
        }),
      };

      this.#activeSubscriptions.set(topic, activeSubscription);
    } else {
      if (
        qos !== activeSubscription.qos ||
        noLocal !== activeSubscription.noLocal ||
        retainAsPublished !== activeSubscription.retainAsPublished ||
        retainHandling !== activeSubscription.retainHandling
      ) {
        throw new Error(
          `Subscription "${topic}" with options ${JSON.stringify({ qos, noLocal, retainAsPublished, retainHandling })} is already locked. Use the same options, or close the previous one.`,
        );
      }
    }

    return await activeSubscription.shared.open({ signal });
  }
}
