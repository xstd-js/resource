import { sleep } from '@xstd/abortable';
import { WebSocketError } from '@xstd/custom-error';
import { type OpenResourceOptions } from '../../resource/factory/open-resource.js';
import { Resource } from '../../resource/resource.js';
import { EmitterResource } from '../emitter-resource/emitter-resource.js';
import { type WebSocketDownValue } from './types/web-socket-down-value.js';
import { type WebSocketUpValue } from './types/web-socket-up-value.js';

export interface OpenWebSocketResourceOptions extends OpenResourceOptions {
  readonly protocols?: string | readonly string[];
}

export class WebSocketResource extends Resource {
  static open(
    url: string | URL,
    { protocols, signal }: OpenWebSocketResourceOptions = {},
  ): Promise<WebSocketResource> {
    return new Promise(
      (_resolve: (value: WebSocketResource) => void, _reject: (error: unknown) => void): void => {
        signal?.throwIfAborted();

        const end = (): void => {
          signal?.removeEventListener('abort', onAbort);
          webSocket.removeEventListener('open', onOpen);
          webSocket.removeEventListener('close', onClose);
          webSocket.removeEventListener('error', onError);
        };

        const resolve = (value: WebSocketResource): void => {
          end();
          _resolve(value);
        };

        const reject = (error: unknown): void => {
          end();
          _reject(error);
        };

        const onAbort = (): void => {
          end();
          reject(signal!.reason);
        };

        const onOpen = (): void => {
          end();
          resolve(new WebSocketResource(webSocket));
        };

        const onClose = (event: CloseEvent): void => {
          end();
          reject(WebSocketError.fromCloseEvent(event));
        };

        const onError = (): void => {
          end();
          reject(new WebSocketError());
        };

        const webSocket: WebSocket = new WebSocket(url, protocols as string[]);
        webSocket.binaryType = 'arraybuffer';

        signal?.addEventListener('abort', onAbort);
        webSocket.addEventListener('open', onOpen);
        webSocket.addEventListener('close', onClose);
        webSocket.addEventListener('error', onError);
      },
    );
  }

  readonly #webSocket: WebSocket;

  private constructor(webSocket: WebSocket) {
    super();

    this.#webSocket = webSocket;

    if (this.#webSocket.readyState !== WebSocket.OPEN) {
      throw new Error('WebSocket not open.');
    }

    this.#webSocket.addEventListener(
      'close',
      (event: CloseEvent): void => {
        void this.close(WebSocketError.fromCloseEvent(event));
      },
      {
        signal: this.closeSignal,
      },
    );

    this.#webSocket.addEventListener(
      'error',
      (): void => {
        void this.close(new WebSocketError());
      },
      {
        signal: this.closeSignal,
      },
    );

    this.addTeardown((reason: unknown): void => {
      if (
        this.#webSocket.readyState === WebSocket.CONNECTING ||
        this.#webSocket.readyState === WebSocket.OPEN
      ) {
        // TODO await buffer flushed ?
        if (reason instanceof WebSocketError) {
          this.#webSocket.close(reason.code, reason.reason);
        } else {
          this.#webSocket.close();
        }
      }
    });
  }

  send(payload: WebSocketUpValue): Promise<void> {
    return this.runTask(async (signal: AbortSignal): Promise<void> => {
      this.#webSocket.send(payload);

      while (this.#webSocket.bufferedAmount > 0) {
        if (
          this.#webSocket.readyState === WebSocket.CLOSING ||
          this.#webSocket.readyState === WebSocket.CLOSED
        ) {
          throw new Error(
            `WebSocket ${this.#webSocket.readyState === WebSocket.CLOSING ? 'closing' : 'closed'}.`,
          );
        }
        await sleep(0, { signal });
      }
    });
  }

  receiver(): EmitterResource<WebSocketDownValue> {
    this.throwIfClosed();

    const { emitter, dispatch } = EmitterResource.withDispatcher<WebSocketDownValue>();

    this.#webSocket.addEventListener(
      'message',
      (event: MessageEvent<WebSocketDownValue>): void => {
        dispatch(event.data);
      },
      {
        signal: emitter.closeSignal,
      },
    );

    return this.fork(emitter);
  }
}
