import { Abortable, sleep } from '@xstd/abortable';
import { block } from '@xstd/block';
import { MQTT_CONFIG } from '../../configs/mqtt/mqtt-config.private.js';
import { EmitterResource } from './src/built-in/emitter-resource/emitter-resource.js';
import { MqttResource } from './src/built-in/mqtt/client/mqtt-resource.js';
import { MqttPublishPacket } from './src/built-in/mqtt/client/types/mqtt-publish-packet.js';
import { WebSocketResource } from './src/built-in/web-socket/web-socket-resource.js';
import { openResourceGraph } from './src/resource/graph.private/graph.js';
import { debugResource } from './src/resource/helpers/debug-resource.js';
import { Resource } from './src/resource/resource.js';

// /*---*/
//
// export interface ZigbeeResource extends Resource {
//   send(packet: ZigbeePacket, options?: Abortable): Promise<void>;
//
//   readonly receive$: EventEmitter<ZigbeePacket>;
// }
//
/*---*/

/*---*/

// export interface ThingPropertyEventMap<GValue> extends ResourceEventMap {
//   readonly change: CustomEvent<GValue>;
// }
//
// export interface ThingProperty<GValue>
//   extends Omit<Resource, keyof TypedEventTarget<ThingPropertyEventMap<GValue>>>,
//     TypedEventTarget<ThingPropertyEventMap<GValue>> {
//   set(value: GValue, options?: Abortable): Promise<void>;
//
//   get(options?: Abortable): Promise<GValue>;
// }

/*-----*/

export interface ThingProperty<GValue> extends Resource {
  set(value: GValue, options?: Abortable): Promise<void>;

  get(options?: Abortable): Promise<GValue>;

  observer(): EmitterResource<GValue>;
}

/*-----*/

// TODO use [flowchart](https://mermaid.js.org/syntax/flowchart.html) to create a map of the used resources

/*-----*/

async function resourceDebug01() {
  await using ws = await WebSocketResource.open('wss://echo.websocket.org');

  Promise.all([
    block(async () => {
      for await (const value of ws.receiver()) {
        console.log('read', value);
      }
    }),
    block(async () => {
      while (!ws.closeSignal.aborted) {
        const value: string = new Date().toISOString();
        console.log('write', value);
        await ws.send(value);
        await sleep(500, { signal: ws.closeSignal });
      }
    }),
  ]).catch((reason: unknown) => {
    console.log('=> caught');
    console.log(reason);
  });

  await sleep(1700);
}

async function resourceDebug02() {
  await using mqtt = debugResource(await MqttResource.open(MQTT_CONFIG.url, MQTT_CONFIG), 'mqtt');

  Promise.all([
    block(async () => {
      const sub: EmitterResource<MqttPublishPacket> = debugResource(
        await mqtt.subscribe('test'),
        'subscribe',
      );
      for await (const event of sub) {
        console.log('read', event.topic, new TextDecoder().decode(event.payload));
      }
    }),
    block(async () => {
      while (!mqtt.closeSignal.aborted) {
        const value: string = new Date().toISOString();
        console.log('write', value);
        await mqtt.publish('test', value);
        await sleep(1500, { signal: mqtt.closeSignal });
      }
    }),
  ]).catch((reason: unknown) => {
    console.log('catch');
    console.log(reason);
  });

  await sleep(1000);
  await openResourceGraph();

  await sleep(1700);
  // await mqtt.close();
}

export async function resourceDebug() {
  // await resourceDebug01();
  await resourceDebug02();
}
