import { type Abortable } from '@xstd/abortable';
import { type AsyncResource } from '../async-resource.js';

export interface OpenAsyncResource<
  GArguments extends readonly any[],
  GResource extends AsyncResource,
> {
  (...args: GArguments): PromiseLike<GResource> | GResource;
}

export type OpenAsyncResourceArguments<GArguments extends readonly any[]> =
  [...GArguments] extends readonly [...args: infer GArgs, last?: infer GLast] ?
    GLast extends Abortable ?
      GArguments
    : [...args: GArgs, options?: Abortable]
  : never;

export class AsyncResourceFactory<
  GArguments extends OpenAsyncResourceArguments<GArguments>,
  GResource extends AsyncResource,
> {
  readonly #open: OpenAsyncResource<GArguments, GResource>;

  constructor(open: OpenAsyncResource<GArguments, GResource>) {
    this.#open = open;
  }

  open(...args: GArguments): Promise<GResource> {
    return Promise.try(this.#open, ...args);
  }
}

// export interface OpenAsyncResource<
//   GArguments extends readonly any[],
//   GOptions extends Abortable,
//   GResource extends AsyncResource,
// > {
//   (...args: OpenAsyncResourceArguments<GArguments, GOptions>): PromiseLike<GResource> | GResource;
// }
//
// export type OpenAsyncResourceArguments<
//   GArguments extends readonly any[],
//   GOptions extends Abortable,
// > = readonly [...args: GArguments, options?: GOptions];
//
// export class AsyncResourceFactory<
//   GArguments extends readonly any[],
//   GOptions extends Abortable,
//   GResource extends AsyncResource,
// > {
//   readonly #open: OpenAsyncResource<GArguments, GOptions, GResource>;
//
//   constructor(open: OpenAsyncResource<GArguments, GOptions, GResource>) {
//     this.#open = open;
//   }
//
//   open(...args: OpenAsyncResourceArguments<GArguments, GOptions>): Promise<GResource> {
//     return Promise.try(this.#open, ...args);
//   }
// }
