import { type Abortable, abortify } from '@xstd/abortable';
import { AsyncResource } from '../../async-resource.js';

export interface SharedResourceFactoryOptions<
  GMainResource extends AsyncResource,
  GForkedResource extends AsyncResource,
> {
  readonly main: OpenMainResource<GMainResource>;
  readonly fork: OpenForkedResource<GMainResource, GForkedResource>;
}

export interface OpenMainResource<GMainResource extends AsyncResource> {
  (signal: AbortSignal): Promise<GMainResource> | GMainResource;
}

export interface OpenForkedResource<
  GMainResource extends AsyncResource,
  GForkedResource extends AsyncResource,
> {
  (main: GMainResource, options?: Abortable): Promise<GForkedResource> | GForkedResource;
}

export class SharedResourceFactory<
  GMainResource extends AsyncResource,
  GForkedResource extends AsyncResource,
> {
  readonly #main: OpenMainResource<GMainResource>;
  readonly #fork: OpenForkedResource<GMainResource, GForkedResource>;

  #usageCount: number;
  #openController: AbortController | undefined;
  #openPromise: Promise<GMainResource> | undefined;
  #closePromise: Promise<void> | undefined;

  constructor({ main, fork }: SharedResourceFactoryOptions<GMainResource, GForkedResource>) {
    this.#main = main;
    this.#fork = fork;
    this.#usageCount = 0;
  }

  async open(options?: Abortable): Promise<GForkedResource> {
    options?.signal?.throwIfAborted();

    // await previous close
    if (this.#closePromise !== undefined) {
      await abortify(this.#closePromise, options);
    }

    this.#usageCount++;

    if (this.#openPromise === undefined) {
      const openController: AbortController = new AbortController();
      this.#openController = openController;

      this.#openPromise = Promise.try(this.#main, openController.signal).finally((): void => {
        openController.abort();
      });
    }

    try {
      const mainResource: GMainResource = await abortify(this.#openPromise!, options);

      return mainResource.fork(
        (await Promise.try(this.#fork, mainResource, options)).addTeardown(
          async (reason: unknown): Promise<void> => {
            this.#usageCount--;

            if (this.#usageCount === 0) {
              this.#openPromise = undefined;

              if (mainResource.closeSignal.aborted) {
                this.#closePromise = undefined;
              } else {
                await (this.#closePromise = mainResource.close(reason).finally((): void => {
                  this.#closePromise = undefined;
                }));
              }
            }
          },
        ),
      );
    } catch (error: unknown) {
      this.#usageCount--;

      if (this.#usageCount === 0) {
        this.#openController!.abort();
        this.#openController = undefined;
        this.#openPromise = undefined;
      }

      throw error;
    }
  }
}
