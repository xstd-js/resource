export interface InitAsyncResource {
  (ctx: AsyncResourceContext): void;
}

export interface AsyncResourceContext {
  readonly controller: AbortController;
  readonly close: AsyncResourceCloseContext;
}

export interface AsyncResourceCloseContext {
  readonly resolve: (value?: void | PromiseLike<void>) => void;
  readonly reject: (reason?: unknown) => void;
  readonly promise: Promise<void>;
}

export class AsyncResource implements AsyncDisposable {
  readonly #controller: AbortController;
  readonly #closed: Promise<void>;

  constructor(init: InitAsyncResource) {
    this.#controller = new AbortController();
    const { promise, resolve, reject } = Promise.withResolvers<void>();
    this.#closed = promise;

    init({
      controller: this.#controller,
      close: {
        promise,
        resolve, // TODO ensure controller is closed before
        reject,
      },
    });
  }

  get closeSignal(): AbortSignal {
    return this.#controller.signal;
  }

  get closed(): Promise<void> {
    return this.#closed;
  }

  close(reason?: unknown): Promise<void> {
    if (!this.#controller.signal.aborted) {
      this.#controller.abort(reason);
    }

    return this.#closed;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }
}
