import { type Resource } from '../resource.js';

export interface OpenResource<GArguments extends readonly any[], GResource extends Resource> {
  (...args: GArguments): GResource;
}

// TODO rename in `Provider`, `Pool` ?

export class ResourceFactory<GArguments extends readonly any[], GResource extends Resource> {
  readonly #open: OpenResource<GArguments, GResource>;

  constructor(open: OpenResource<GArguments, GResource>) {
    this.#open = open;
  }

  open(...args: GArguments): GResource {
    return this.#open(...args);
  }
}
