export interface InitResource {
  (ctx: ResourceContext): void;
}

export interface ResourceContext {
  readonly controller: AbortController;
}

export class Resource implements Disposable {
  readonly #controller: AbortController;

  constructor(init: InitResource) {
    this.#controller = new AbortController();

    init({
      controller: this.#controller,
    });
  }

  get closeSignal(): AbortSignal {
    return this.#controller.signal;
  }

  close(reason?: unknown): void {
    if (!this.#controller.signal.aborted) {
      this.#controller.abort(reason);
    }
  }

  [Symbol.dispose](): void {
    return this.close();
  }
}

/*----------*/

// export interface InitEphemeral {
//   (ctx: EphemeralContext): void;
// }
//
// export interface EphemeralContext {
//   readonly controller: AbortController;
// }
//
// export class Ephemeral {
//   readonly #controller: AbortController;
//
//   constructor(init: InitEphemeral) {
//     this.#controller = new AbortController();
//
//     init({
//       controller: this.#controller,
//     });
//   }
//
//   get closeSignal(): AbortSignal {
//     return this.#controller.signal;
//   }
// }
