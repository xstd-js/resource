export function resourceThrowIfClosed({
  closeSignal,
}: {
  readonly closeSignal: AbortSignal;
}): void {
  if (closeSignal.aborted) {
    throw new Error('Resource closed');
  }
}
