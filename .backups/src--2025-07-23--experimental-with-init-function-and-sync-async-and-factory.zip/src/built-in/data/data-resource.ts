import { AsyncResource } from '../../resource/async/async-resource.js';

export class DataResource<GData> extends AsyncResource {
  readonly #data: GData;

  constructor(data: GData) {
    super();
    this.#data = data;
  }

  get data(): GData {
    return this.#data;
  }
}
