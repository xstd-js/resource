import { sleep } from '@xstd/abortable';
import { WebSocketError } from '@xstd/custom-error';
import { AsyncResource, AsyncResourceContext } from '../../resource/async/async-resource.js';
import { AsyncTaskRunner } from '../../resource/async/helpers/async-task-runner.js';
import { runSequentiallyVoidPromiseFactories } from '../../resource/async/helpers/run-sequentially-void-promise-factories.js';
import { EmitterContext, EmitterFactory } from '../emitter/emitter-factory.js';
import { type WebSocketDownValue } from './types/web-socket-down-value.js';
import { type WebSocketUpValue } from './types/web-socket-up-value.js';
import {
  type OpenWebSocketResourceOptions,
  WebSocketResourceFactory,
} from './web-socket-resource-factory.js';

export interface WebSocketResourceSend {
  (payload: WebSocketUpValue): Promise<void>;
}

export class WebSocketResource extends AsyncResource {
  static #factory: WebSocketResourceFactory;

  static open(
    url: string | URL,
    options?: OpenWebSocketResourceOptions,
  ): Promise<WebSocketResource> {
    if (this.#factory === undefined) {
      this.#factory = new WebSocketResourceFactory();
    }

    return this.#factory.open(url, options);
  }

  readonly #send: WebSocketResourceSend;
  readonly #receiver: EmitterFactory<WebSocketDownValue>;

  constructor(webSocket: WebSocket) {
    let self!: {
      send: WebSocketResourceSend;
      receiver: EmitterFactory<WebSocketDownValue>;
    };

    super(({ controller, close: { resolve } }: AsyncResourceContext): void => {
      if (webSocket.readyState !== WebSocket.OPEN) {
        throw new Error('WebSocket not open.');
      }

      // close this resource when the webSocket closes
      webSocket.addEventListener(
        'close',
        (event: CloseEvent): void => {
          controller.abort(WebSocketError.fromCloseEvent(event));
        },
        controller,
      );

      // close this resource when the webSocket errors
      webSocket.addEventListener(
        'error',
        (): void => {
          controller.abort(new WebSocketError());
        },
        controller,
      );

      const taskRunner: AsyncTaskRunner = new AsyncTaskRunner(controller.signal);

      // METHODS/PROPERTIES

      // send a payload
      const send: WebSocketResourceSend = (payload: WebSocketUpValue): Promise<void> => {
        return taskRunner.runTask(async (signal: AbortSignal): Promise<void> => {
          webSocket.send(payload);

          while (webSocket.bufferedAmount > 0) {
            if (
              webSocket.readyState === WebSocket.CLOSING ||
              webSocket.readyState === WebSocket.CLOSED
            ) {
              throw new Error(
                `WebSocket ${webSocket.readyState === WebSocket.CLOSING ? 'closing' : 'closed'}.`,
              );
            }
            await sleep(0, { signal });
          }
        });
      };

      // receive payloads
      const receiver: EmitterFactory<WebSocketDownValue> = new EmitterFactory<WebSocketDownValue>(
        ({
          controller: receiverController,
          dispatch,
        }: EmitterContext<WebSocketDownValue>): void => {
          if (controller.signal.aborted) {
            receiverController.abort(controller.signal.reason);
          } else {
            // close the EmitterResource when this WebSocketResource closes
            controller.signal.addEventListener(
              'abort',
              (): void => {
                receiverController.abort(controller.signal.reason);
              },
              receiverController,
            );

            webSocket.addEventListener(
              'message',
              (event: MessageEvent<WebSocketDownValue>): void => {
                dispatch(event.data);
              },
              receiverController,
            );
          }
        },
      );

      self = {
        send,
        receiver,
      };

      // when this WebSocketResource closes
      controller.signal.addEventListener('abort', (): void => {
        resolve(
          runSequentiallyVoidPromiseFactories(
            [
              (): Promise<void> => {
                return taskRunner.flush();
              },
              (reason: unknown): void => {
                if (
                  webSocket.readyState === WebSocket.CONNECTING ||
                  webSocket.readyState === WebSocket.OPEN
                ) {
                  // TODO await buffer flushed ?
                  if (reason instanceof WebSocketError) {
                    webSocket.close(reason.code, reason.reason);
                  } else {
                    webSocket.close();
                  }
                }
              },
            ],
            controller.signal.reason,
          ),
        );
      });
    });

    this.#send = self.send;
    this.#receiver = self.receiver;
  }

  get send(): WebSocketResourceSend {
    return this.#send;
  }

  get receiver(): EmitterFactory<WebSocketDownValue> {
    return this.#receiver;
  }
}
