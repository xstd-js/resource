import { Abortable, abortify } from '@xstd/abortable';
import { CompleteError } from '@xstd/custom-error';
import mqtt, { IDisconnectPacket, IPublishPacket, ISubscriptionGrant, MqttClient } from 'mqtt';
import { AsyncResource, AsyncResourceContext } from '../../../resource/async/async-resource.js';
import { SharedResourceFactory } from '../../../resource/async/factory/shared/shared-resource-factory.js';
import { AsyncTaskRunner } from '../../../resource/async/helpers/async-task-runner.js';
import { runSequentiallyVoidPromiseFactories } from '../../../resource/async/helpers/run-sequentially-void-promise-factories.js';
import { EmitterFactory } from '../../emitter/emitter-factory.js';
import { MqttTopic } from '../topic/mqtt-topic.js';
import { MqttPublishPacket } from './types/mqtt-publish-packet.js';
import { MqttResourceSubscribeOptions } from './types/mqtt-resource-subscribe-options.js';

export interface OpenMqttResourceOptions extends Abortable {
  readonly clientId?: string;
  readonly username?: string;
  readonly password?: string;

  // readonly keepalive?: number;
  // readonly clean?: boolean;
}

/** TYPES **/

// PUBLISH

export interface MqttResourcePublish {
  (
    topic: string,
    payload: string | Uint8Array,
    options?: MqttResourcePublishOptions,
  ): Promise<void>;
}

export interface MqttResourcePublishOptions extends Abortable {
  readonly qos?: 0 | 1 | 2;
  readonly retain?: boolean;
  readonly dup?: boolean;
}

// SUBSCRIBE

export interface MqttResourceSubscribe {
  (
    topic: string,
    options?: MqttResourceSubscribeOptions,
  ): Promise<EmitterFactory<MqttPublishPacket>>;
}

export interface MqttResourceSubscribeOptions extends Abortable {
  readonly qos?: 0 | 1 | 2;
  readonly noLocal?: boolean;
  readonly retainAsPublished?: boolean;
  readonly retainHandling?: 0 | 1 | 2;
}

interface ActiveSubscription {
  readonly qos: 0 | 1 | 2;
  readonly noLocal: boolean;
  readonly retainAsPublished: boolean;
  readonly retainHandling: 0 | 1 | 2;

  // TODO
  // readonly shared: SharedResourceFactory<AsyncResource, EmitterResource<MqttPublishPacket>>;
}

/** CLASS **/

export class MqttResource extends AsyncResource {
  static async open(
    url: string | URL,
    { signal, ...options }: OpenMqttResourceOptions = {},
  ): Promise<MqttResource> {
    signal?.throwIfAborted();

    const client: MqttClient = await mqtt.connectAsync(url.toString(), {
      ...options,
      reconnectPeriod: 0,
      autoUseTopicAlias: true,
      autoAssignTopicAlias: true,
    });

    // TODO
    client.setMaxListeners(20);
    // client.setMaxListeners(50);

    if (signal?.aborted) {
      await client.endAsync();
      throw signal.reason;
    }

    return new MqttResource(client);
  }

  readonly #publish: MqttResourcePublish;
  // readonly #activeSubscriptions: Map<string /* topic */, ActiveSubscription>;

  constructor(client: MqttClient) {
    let self!: {
      publish: MqttResourcePublish;
    };

    super(({ controller, close: { resolve } }: AsyncResourceContext): void => {
      if (!client.connected) {
        throw new Error('MqttClient not open.');
      }

      const onClientDisconnect = (packet: IDisconnectPacket): void => {
        if (packet.reasonCode === undefined || packet.reasonCode === 0x00) {
          controller.abort(new CompleteError());
        } else {
          controller.abort(new Error('Disconnected', { cause: packet }));
        }
      };

      const onClientError = (error: unknown): void => {
        controller.abort(error);
      };

      const onClientEnd = (): void => {
        controller.abort(new Error('Client ended'));
      };

      client.on('disconnect', onClientDisconnect);
      client.on('error', onClientError);
      client.on('end', onClientEnd);

      const taskRunner: AsyncTaskRunner = new AsyncTaskRunner(controller.signal);

      // METHODS

      const publish: MqttResourcePublish = (
        topic: string,
        payload: string | Uint8Array,
        { signal, ...options }: MqttResourcePublishOptions = {},
      ): Promise<void> => {
        return taskRunner.runTask(
          async (signal: AbortSignal): Promise<void> => {
            await abortify(client.publishAsync(topic, payload as any, options), {
              signal,
            });
          },
          { signal },
        );
      };

      const subscribe = async (
        topic: string,
        {
          qos = 0,
          noLocal = false,
          retainAsPublished = false,
          retainHandling = 0,
          signal,
        }: MqttResourceSubscribeOptions = {},
      ): EmitterFactory<MqttPublishPacket> => {
        let activeSubscription: ActiveSubscription | undefined =
          this.#activeSubscriptions.get(topic);

        if (activeSubscription === undefined) {
          activeSubscription = {
            qos,
            noLocal,
            retainAsPublished,
            retainHandling,

            shared: new SharedResourceFactory<AsyncResource, EmitterResource<MqttPublishPacket>>({
              main: async (signal: AbortSignal): Promise<AsyncResource> => {
                try {
                  const [granted]: ISubscriptionGrant[] = await this.#client.subscribeAsync(topic, {
                    qos,
                    nl: noLocal,
                    rap: retainAsPublished,
                    rh: retainHandling,
                  });

                  if (signal.aborted) {
                    await this.#client.unsubscribeAsync(topic);
                    throw signal.reason;
                  }

                  if (qos !== undefined && granted.qos < qos) {
                    await this.#client.unsubscribeAsync(topic);
                    throw new Error(
                      `Cannot subscribe to "${topic}" with a qos of ${qos}. Granted ${granted.qos}.`,
                    );
                  }

                  return this.fork(
                    new AsyncResource().addTeardown(async (): Promise<void> => {
                      try {
                        await this.#client.unsubscribeAsync(topic);
                      } finally {
                        this.#activeSubscriptions.delete(topic);
                      }
                    }),
                  );
                } catch (error: unknown) {
                  this.#activeSubscriptions.delete(topic);
                  throw error;
                }
              },
              fork: (): EmitterResource<MqttPublishPacket> => {
                const { emitter, dispatch } = EmitterResource.withDispatcher<MqttPublishPacket>();

                const topicMatcher: MqttTopic = new MqttTopic(topic);

                const onClientMessage = (
                  topic: string,
                  payload: Buffer,
                  _packet: IPublishPacket,
                ): void => {
                  if (topicMatcher.matches(topic)) {
                    dispatch({
                      topic,
                      payload,
                    });
                  }
                };

                this.#client.on('message', onClientMessage);

                emitter.closeSignal.addEventListener('abort', (): void => {
                  this.#client.off('message', onClientMessage);
                });

                return emitter;
              },
            }),
          };

          this.#activeSubscriptions.set(topic, activeSubscription);
        } else {
          if (
            qos !== activeSubscription.qos ||
            noLocal !== activeSubscription.noLocal ||
            retainAsPublished !== activeSubscription.retainAsPublished ||
            retainHandling !== activeSubscription.retainHandling
          ) {
            throw new Error(
              `Subscription "${topic}" with options ${JSON.stringify({ qos, noLocal, retainAsPublished, retainHandling })} is already locked. Use the same options, or close the previous one.`,
            );
          }
        }

        return await activeSubscription.shared.open({ signal });
      };

      // when this MqttResource closes
      controller.signal.addEventListener('abort', (): void => {
        resolve(
          runSequentiallyVoidPromiseFactories(
            [
              (reason: unknown): void => {
                client.off('disconnect', onClientDisconnect);
                client.off('error', onClientError);
                client.off('end', onClientEnd);
              },
              (): Promise<void> => {
                return taskRunner.flush();
              },
              (): Promise<void> => {
                return client.endAsync();
              },
            ],
            controller.signal.reason,
          ),
        );
      });
    });

    this.#publish = self.publish;
  }

  get publish(): MqttResourcePublish {
    return this.#publish;
  }
}
