import { type Abortable } from '@xstd/abortable';
import { type MapFunction } from '@xstd/functional';
import { AsyncResource, AsyncResourceContext } from '../../resource/async/async-resource.js';
import { AsyncResourceFactory } from '../../resource/async/factory/async-resource-factory.js';
import { Resource } from '../../resource/sync/resource.js';
import { DispatchValue, ValueListener } from './emitter-factory.js';

export interface OpenAsyncEmitterResource<GValue> {
  (
    options?: Abortable,
  ): PromiseLike<InitAsyncEmitterResource<GValue>> | InitAsyncEmitterResource<GValue>;
}

export interface InitAsyncEmitterResource<GValue> {
  (ctx: AsyncEmitterContext<GValue>): PromiseLike<void> | void;
}

export interface AsyncEmitterContext<GValue> extends AsyncResourceContext {
  readonly dispatch: DispatchValue<GValue>;
}

export class AsyncEmitterFactory<GValue> extends AsyncResourceFactory<
  [listener: ValueListener<GValue>, options?: Abortable],
  AsyncResource
> {
  constructor(init: InitAsyncEmitterResource<GValue>) {
    super((listener: ValueListener<GValue>, { signal }: Abortable = {}): Promise<AsyncResource> => {
      return new Promise<AsyncResource>(
        (resolve: (value: AsyncResource) => void, reject: (reason?: any) => void): void => {
          const resource: AsyncResource = new AsyncResource((ctx: AsyncResourceContext): void => {
            if (signal !== undefined) {
              if (signal.aborted) {
                ctx.controller.abort(signal.reason);
              } else {
                signal.addEventListener(
                  'abort',
                  (): void => {
                    ctx.controller.abort(signal.reason);
                  },
                  ctx.controller,
                );
              }
            }

            Promise.try(init, {
              ...ctx,
              dispatch: (value: GValue): void => {
                if (ctx.controller.signal.aborted) {
                  throw new Error('Resource closed');
                }
                listener(value);
              },
            }).then((): void => {
              resolve(resource);
            }, reject);
          });
        },
      );
    });
  }

  #transform<GNewValue>(
    onValue: (value: GValue, dispatch: DispatchValue<GNewValue>) => void,
  ): AsyncEmitterFactory<GNewValue> {
    return new AsyncEmitterFactory<GNewValue>(
      async ({ dispatch, controller }: AsyncEmitterContext<GNewValue>): Promise<void> => {
        const listener: AsyncResource = await this.open((value: GValue): void => {
          onValue(value, dispatch);
        }, controller);

        // TODO choose between implementations
        // listener.closed.finally((): void => {
        //   controller.abort(listener.closeSignal.reason);
        // });

        if (listener.closeSignal.aborted) {
          controller.abort(listener.closeSignal.reason);
        } else {
          listener.closeSignal.addEventListener(
            'abort',
            (): void => {
              controller.abort(listener.closeSignal.reason);
            },
            controller,
          );
        }
      },
    );
  }

  map<GNewValue>(mapFnc: MapFunction<GValue, GNewValue>): EmitterFactory<GNewValue> {
    return this.#transform((value: GValue, dispatch: DispatchValue<GNewValue>): void => {
      dispatch(mapFnc(value));
    });
  }

  first({ signal }: Abortable = {}): Promise<GValue> {
    return new Promise<GValue>(
      (resolve: (value: GValue) => void, reject: (reason?: any) => void): void => {
        signal?.throwIfAborted();

        const onAbort = (): void => {
          signal!.removeEventListener('abort', onAbort);
          controller.abort(signal!.reason);
          reject(signal!.reason);
        };

        signal?.addEventListener('abort', onAbort);

        const controller: AbortController = new AbortController();

        this.open((value: GValue): void => {
          signal?.removeEventListener('abort', onAbort);
          controller.abort();
          resolve(value);
        }, controller);
      },
    );
  }

  async *toAsyncGenerator({
    bufferSize = Number.POSITIVE_INFINITY,
    windowTime = Number.POSITIVE_INFINITY,
    signal,
  }: EmitterResourceToAsyncIteratorOptions = {}): AsyncGenerator<GValue> {
    bufferSize = Math.max(0, bufferSize);
    windowTime = Math.max(0, windowTime);

    interface PendingValue {
      readonly value: GValue;
      readonly expirationDate: number;
    }

    const values: PendingValue[] = [];
    let pendingRead: PromiseWithResolvers<void> | undefined;

    using listener: Resource = this.open(
      (value: GValue): void => {
        if (bufferSize > 0 && windowTime > 0) {
          values.push({
            value,
            expirationDate: Date.now() + windowTime,
          });

          if (values.length > bufferSize) {
            values.shift();
          }
        } else {
          if (pendingRead !== undefined) {
            values.length = 0;
            values.push({
              value,
              expirationDate: Number.POSITIVE_INFINITY,
            });
          }
        }

        if (pendingRead !== undefined) {
          pendingRead.resolve();
          pendingRead = undefined;
        }
      },
      {
        signal,
      },
    );

    const sharedSignal: AbortSignal = listener.closeSignal;

    while (true) {
      sharedSignal.throwIfAborted();

      // remove the expired values
      const now: number = Date.now();
      while (values.length > 0 && values[0].expirationDate < now) {
        values.shift();
      }

      if (values.length > 0) {
        yield values.shift()!.value;
      } else {
        pendingRead = Promise.withResolvers<void>();

        const onAbort = (): void => {
          sharedSignal.removeEventListener('abort', onAbort);
          pendingRead!.reject(sharedSignal!.reason);
          pendingRead = undefined;
        };

        sharedSignal.addEventListener('abort', onAbort);

        try {
          await pendingRead.promise;
        } finally {
          sharedSignal.removeEventListener('abort', onAbort);
        }
      }
    }
  }

  [Symbol.asyncIterator](): AsyncGenerator<GValue, void, void> {
    return this.toAsyncGenerator();
  }
}

// export interface EmitterResourceWithDispatcher<GValue> {
//   readonly emitter: EmitterResource<GValue>;
//   readonly dispatch: DispatchEmitterResourceValue<GValue>;
// }

// export class EmitterResource<GValue> extends Resource {
//   static readonly #maxUnsubscribeCount: number = 0xff;
//
//   // static withDispatcher<GValue>(): EmitterResourceWithDispatcher<GValue> {
//   //   let dispatch!: DispatchEmitterResourceValue<GValue>;
//   //
//   //   const emitter = new EmitterResource<GValue>(
//   //     (_dispatch: DispatchEmitterResourceValue<GValue>): void => {
//   //       dispatch = _dispatch;
//   //     },
//   //   );
//   //
//   //   return {
//   //     emitter,
//   //     dispatch,
//   //   };
//   // }
//
//   // the list of listeners
//   #listeners: EmitterResourceListener<GValue>[];
//
//   // the number of postponed unsubscribed listeners
//   #postponedUnsubscriptions: number;
//   // the id of the last batch of unsubscriptions
//   #lastUnsubscriptionsBatchId: number;
//   // if we are dispatching
//   #dispatching: boolean;
//
//   constructor(init: InitEmitterResource<GValue>) {
//     super();
//
//     this.#listeners = [];
//     this.#postponedUnsubscriptions = 0;
//     this.#lastUnsubscriptionsBatchId = 0;
//     this.#dispatching = false;
//
//     init((value: GValue): void => {
//       this.#dispatch(value);
//     });
//   }
//
//   #dispatch(value: GValue): void {
//     this.throwIfClosed();
//
//     if (this.#dispatching) {
//       throw new Error('Dispatch loop detected.');
//     }
//
//     this.#dispatching = true;
//
//     for (let i: number = 0; i < this.#listeners.length; i++) {
//       this.#listeners[i](value);
//     }
//
//     this.#batchUnsubscribe();
//
//     this.#dispatching = false;
//   }
//
//   #batchUnsubscribe(): void {
//     if (this.#postponedUnsubscriptions >= EmitterResource.#maxUnsubscribeCount) {
//       this.#postponedUnsubscriptions = 0;
//       this.#lastUnsubscriptionsBatchId++;
//       this.#listeners = this.#listeners.filter(
//         (listener: EmitterResourceListener<GValue>): boolean => {
//           return listener !== noop;
//         },
//       );
//     }
//   }
//
//   #listen(listener: EmitterResourceListener<GValue>): UndoFunction {
//     this.throwIfClosed();
//
//     let listenerIndex: number = this.#listeners.length;
//     let listenerUnsubscriptionsBatchId: number = this.#lastUnsubscriptionsBatchId;
//
//     this.#listeners.push(listener);
//
//     return (): void => {
//       if (listenerUnsubscriptionsBatchId !== this.#lastUnsubscriptionsBatchId) {
//         // => a batch of unsubscriptions happened before we unsubscribed this listener
//         listenerIndex = this.#listeners.indexOf(listener);
//       }
//       this.#listeners[listenerIndex] = noop;
//       this.#postponedUnsubscriptions++;
//
//       if (!this.#dispatching) {
//         this.#batchUnsubscribe();
//       }
//     };
//   }
//
//   listen(listener: EmitterResourceListener<GValue>): AsyncResource {
//     this.throwIfClosed();
//
//     return this.fork(new AsyncResource().addTeardown(this.#listen(listener)));
//   }
//
//   #transform<GNewValue>(
//     onValue: (value: GValue, dispatch: DispatchEmitterResourceValue<GNewValue>) => void,
//   ): EmitterResource<GNewValue> {
//     this.throwIfClosed();
//
//     let dispatch: DispatchEmitterResourceValue<GNewValue>;
//
//     return this.fork(
//       new EmitterResource<GNewValue>((_dispatch: DispatchEmitterResourceValue<GNewValue>): void => {
//         dispatch = _dispatch;
//       }).addTeardown(
//         this.#listen((value: GValue): void => {
//           onValue(value, dispatch);
//         }),
//       ),
//     );
//
//     // return this.listen((value: GValue): void => {
//     //   onValue(value, dispatch);
//     // }).fork(
//     //   new EmitterResource<GNewValue>((_dispatch: DispatchEmitterResourceValue<GNewValue>): void => {
//     //     dispatch = _dispatch;
//     //   }),
//     //   {
//     //     closesWithForked: true,
//     //   },
//     // );
//   }
//
//   // new(): EmitterResource<GValue> {
//   //   return this.#transform(
//   //     (value: GValue, dispatch: DispatchEmitterResourceValue<GValue>): void => {
//   //       dispatch(value);
//   //     },
//   //   );
//   // }
//   //
//   // map<GNewValue>(mapFnc: MapFunction<GValue, GNewValue>): EmitterResource<GNewValue> {
//   //   return this.#transform(
//   //     (value: GValue, dispatch: DispatchEmitterResourceValue<GNewValue>): void => {
//   //       dispatch(mapFnc(value));
//   //     },
//   //   );
//   // }
//   //
//   // filter<GNewValue extends GValue>(
//   //   filterFnc: FilterFunctionWithSubType<GValue, GNewValue>,
//   // ): EmitterResource<GNewValue>;
//   // filter(filterFnc: FilterFunction<GValue>): EmitterResource<GValue>;
//   // filter(filterFnc: FilterFunction<GValue>): EmitterResource<GValue> {
//   //   return this.#transform(
//   //     (value: GValue, dispatch: DispatchEmitterResourceValue<GValue>): void => {
//   //       if (filterFnc(value)) {
//   //         dispatch(value);
//   //       }
//   //     },
//   //   );
//   // }
//   //
//   // mapFilter<GNewValue>(
//   //   mapFilterFnc: MapFilterFunction<GValue, GNewValue>,
//   // ): EmitterResource<GNewValue> {
//   //   return this.#transform(
//   //     (value: GValue, dispatch: DispatchEmitterResourceValue<GNewValue>): void => {
//   //       const newValue: GNewValue | null = mapFilterFnc(value);
//   //       if (newValue !== null) {
//   //         dispatch(newValue);
//   //       }
//   //     },
//   //   );
//   // }
//   //
//   // distinct({
//   //   initialValue = NONE as GValue,
//   //   equal = EQUAL_FUNCTION_STRICT_EQUAL,
//   // }: EmitterResourceDistinctOptions<GValue> = {}): EmitterResource<GValue> {
//   //   return this.#transform(
//   //     (value: GValue, dispatch: DispatchEmitterResourceValue<GValue>): void => {
//   //       if (!equal(value, initialValue)) {
//   //         initialValue = value;
//   //         dispatch(value);
//   //       }
//   //     },
//   //   );
//   // }
//
//   async next({ signal }: Abortable = {}): Promise<GValue> {
//     return new Promise<GValue>(
//       (resolve: (value: GValue) => void, reject: (reason: unknown) => void): void => {
//         const sharedSignal: AbortSignal = mergeAbortSignals([signal, this.closeSignal]);
//
//         sharedSignal.throwIfAborted();
//
//         const end = (): void => {
//           sharedSignal.removeEventListener('abort', onAbort);
//           stopListener();
//         };
//
//         const onAbort = (): void => {
//           end();
//           reject(sharedSignal.reason);
//         };
//
//         sharedSignal.addEventListener('abort', onAbort);
//
//         const stopListener: UndoFunction = this.#listen((value: GValue): void => {
//           end();
//           resolve(value);
//         });
//       },
//     );
//   }
//
//   async *toAsyncGenerator({
//     bufferSize = Number.POSITIVE_INFINITY,
//     windowTime = Number.POSITIVE_INFINITY,
//     signal,
//   }: EmitterResourceToAsyncIteratorOptions = {}): AsyncGenerator<GValue> {
//     bufferSize = Math.max(0, bufferSize);
//     windowTime = Math.max(0, windowTime);
//
//     const sharedSignal: AbortSignal = mergeAbortSignals([signal, this.closeSignal]);
//
//     interface PendingValue {
//       readonly value: GValue;
//       readonly expirationDate: number;
//     }
//
//     const values: PendingValue[] = [];
//     let pendingRead: PromiseWithResolvers<void> | undefined;
//
//     await using _listenerHook = this.listen((value: GValue): void => {
//       if (bufferSize > 0 && windowTime > 0) {
//         values.push({
//           value,
//           expirationDate: Date.now() + windowTime,
//         });
//
//         if (values.length > bufferSize) {
//           values.shift();
//         }
//       } else {
//         if (pendingRead !== undefined) {
//           values.length = 0;
//           values.push({
//             value,
//             expirationDate: Number.POSITIVE_INFINITY,
//           });
//         }
//       }
//
//       if (pendingRead !== undefined) {
//         pendingRead.resolve();
//         pendingRead = undefined;
//       }
//     });
//
//     while (true) {
//       sharedSignal.throwIfAborted();
//
//       // remove the expired values
//       const now: number = Date.now();
//       while (values.length > 0 && values[0].expirationDate < now) {
//         values.shift();
//       }
//
//       if (values.length > 0) {
//         yield values.shift()!.value;
//       } else {
//         pendingRead = Promise.withResolvers<void>();
//
//         const onAbort = (): void => {
//           sharedSignal.removeEventListener('abort', onAbort);
//           pendingRead!.reject(sharedSignal!.reason);
//           pendingRead = undefined;
//         };
//
//         sharedSignal.addEventListener('abort', onAbort);
//
//         try {
//           await pendingRead.promise;
//         } finally {
//           sharedSignal.removeEventListener('abort', onAbort);
//         }
//       }
//     }
//   }
//
//   [Symbol.asyncIterator](): AsyncGenerator<GValue, void, void> {
//     return this.toAsyncGenerator();
//   }
// }
