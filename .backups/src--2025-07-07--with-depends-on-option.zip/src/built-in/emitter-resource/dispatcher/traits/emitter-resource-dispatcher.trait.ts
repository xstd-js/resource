import { type EmitterResourceDispatcherDispatchTrait } from './properties/dispatch/emitter-resource-dispatcher-dispatch.trait.js';
import { type EmitterResourceDispatcherEmitterTrait } from './properties/emitter/emitter-resource-dispatcher.emitter.trait.js';

export interface EmitterResourceDispatcherTrait<GValue>
  extends EmitterResourceDispatcherEmitterTrait<GValue>,
    EmitterResourceDispatcherDispatchTrait<GValue> {}
