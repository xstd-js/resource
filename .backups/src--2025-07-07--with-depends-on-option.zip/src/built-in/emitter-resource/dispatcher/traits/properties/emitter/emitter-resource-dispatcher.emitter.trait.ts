import { type EmitterResourceTrait } from '../../../../traits/emitter-resource.trait.js';

export interface EmitterResourceDispatcherEmitterTrait<GValue> {
  readonly emitter: EmitterResourceTrait<GValue>;
}
