import { type EmitterResourceDispatchFunction } from '../../../../implementations/types/emitter-resource-dispatch-function.js';

export interface EmitterResourceDispatcherDispatchTrait<GValue> {
  readonly dispatch: EmitterResourceDispatchFunction<GValue>;
}
