import { EmitterResource } from '../../implementations/emitter-resource.js';
import { type EmitterResourceDispatchFunction } from '../../implementations/types/emitter-resource-dispatch-function.js';
import { type EmitterResourceOptions } from '../../implementations/types/emitter-resource-options.js';
import { type EmitterResourceDispatcherTrait } from '../traits/emitter-resource-dispatcher.trait.js';

export class EmitterResourceDispatcher<GValue> implements EmitterResourceDispatcherTrait<GValue> {
  readonly #emitter: EmitterResource<GValue>;
  readonly #dispatch: EmitterResourceDispatchFunction<GValue>;

  constructor(options?: EmitterResourceOptions) {
    let dispatch!: EmitterResourceDispatchFunction<GValue>;

    this.#emitter = new EmitterResource<GValue>(
      (_dispatch: EmitterResourceDispatchFunction<GValue>): void => {
        dispatch = _dispatch;
      },
      options,
    );

    this.#dispatch = dispatch;
  }

  get emitter(): EmitterResource<GValue> {
    return this.#emitter;
  }

  get dispatch(): EmitterResourceDispatchFunction<GValue> {
    return this.#dispatch;
  }
}
