import { type ResourceOptions } from '../../../../resource/implementations/resource.js';

export type EmitterResourceOptions = Omit<ResourceOptions, 'close'>;
