import { type EmitterResourceDispatchFunction } from './emitter-resource-dispatch-function.js';

/**
 * A function called when an `EmitterResource` is initialized.
 */
export interface EmitterResourceInitFunction<GValue> {
  (dispatch: EmitterResourceDispatchFunction<GValue>): void;
}
