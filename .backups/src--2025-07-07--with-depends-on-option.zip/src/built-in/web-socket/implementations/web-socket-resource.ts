import { sleep } from '@xstd/abortable';
import { WebSocketError } from '@xstd/custom-error';
import { mergeCloseSignalsOfOpenResourceOptions } from '../../../resource/factory/merge-close-signals-of-open-resource-options.js';
import { type OpenResourceOptions } from '../../../resource/factory/open-resource.js';
import { Resource, type ResourceOptions } from '../../../resource/implementations/resource.js';
import { EmitterResourceDispatcher } from '../../emitter-resource/dispatcher/implementations/emitter-resource-dispatcher.js';
import { type EmitterResourceTrait } from '../../emitter-resource/traits/emitter-resource.trait.js';
import { type WebSocketDownValue } from '../traits/types/web-socket-down-value.js';
import { type WebSocketUpValue } from '../traits/types/web-socket-up-value.js';
import { type WebSocketResourceTrait } from '../traits/web-socket-resource.trait.js';

export interface WebSocketResourceOptions extends OpenResourceOptions {
  readonly protocols?: string | readonly string[];
}

interface InternalWebSocketResourceOptions extends Omit<ResourceOptions, 'close'> {
  readonly webSocket: WebSocket;
}

export class WebSocketResource extends Resource implements WebSocketResourceTrait {
  static open(
    url: string | URL,
    { protocols, ...options }: WebSocketResourceOptions = {},
  ): Promise<WebSocketResource> {
    return new Promise(
      (_resolve: (value: WebSocketResource) => void, _reject: (error: unknown) => void): void => {
        const signal: AbortSignal = mergeCloseSignalsOfOpenResourceOptions(options);
        signal.throwIfAborted();

        const end = (): void => {
          signal.removeEventListener('abort', onAbort);
          webSocket.removeEventListener('open', onOpen);
          webSocket.removeEventListener('close', onClose);
          webSocket.removeEventListener('error', onError);
        };

        const resolve = (value: WebSocketResource): void => {
          end();
          _resolve(value);
        };

        const reject = (error: unknown): void => {
          end();
          _reject(error);
        };

        const onAbort = (): void => {
          end();
          reject(signal.reason);
        };

        const onOpen = (): void => {
          end();
          resolve(
            new WebSocketResource({
              ...options,
              webSocket,
            }),
          );
        };

        const onClose = (event: CloseEvent): void => {
          end();
          reject(WebSocketError.fromCloseEvent(event));
        };

        const onError = (): void => {
          end();
          reject(new WebSocketError());
        };

        const webSocket: WebSocket = new WebSocket(url, protocols as string[]);
        webSocket.binaryType = 'arraybuffer';

        signal.addEventListener('abort', onAbort);
        webSocket.addEventListener('open', onOpen);
        webSocket.addEventListener('close', onClose);
        webSocket.addEventListener('error', onError);
      },
    );
  }

  readonly #webSocket: WebSocket;
  readonly #receive$: EmitterResourceDispatcher<WebSocketDownValue>;

  private constructor({ webSocket, ...options }: InternalWebSocketResourceOptions) {
    if (webSocket.readyState !== WebSocket.OPEN) {
      throw new Error('WebSocket not open.');
    }

    const onClose = (event: CloseEvent): void => {
      void this.close(WebSocketError.fromCloseEvent(event));
    };

    const onError = (): void => {
      void this.close(new WebSocketError());
    };

    const onMessage = (event: MessageEvent<WebSocketDownValue>): void => {
      this.#receive$.dispatch(event.data);
    };

    webSocket.addEventListener('close', onClose);
    webSocket.addEventListener('error', onError);
    webSocket.addEventListener('message', onMessage);

    super({
      ...options,
      close: (reason: unknown): void => {
        webSocket.removeEventListener('close', onClose);
        webSocket.removeEventListener('error', onError);
        webSocket.removeEventListener('message', onMessage);

        if (
          webSocket.readyState === WebSocket.CONNECTING ||
          webSocket.readyState === WebSocket.OPEN
        ) {
          // TODO await buffer flushed ?
          if (reason instanceof WebSocketError) {
            webSocket.close(reason.code, reason.reason);
          } else {
            webSocket.close();
          }
        }
      },
    });

    this.#webSocket = webSocket;
    this.#receive$ = new EmitterResourceDispatcher<WebSocketDownValue>({
      dependsOn: [this],
    });
  }

  send(payload: WebSocketUpValue): Promise<void> {
    return this.runTask(async (): Promise<void> => {
      this.#webSocket.send(payload);

      while (this.#webSocket.bufferedAmount > 0) {
        if (
          this.#webSocket.readyState === WebSocket.CLOSING ||
          this.#webSocket.readyState === WebSocket.CLOSED
        ) {
          throw new Error(
            `WebSocket ${this.#webSocket.readyState === WebSocket.CLOSING ? 'closing' : 'closed'}.`,
          );
        }
        await sleep(0, { signal: this.closeSignal });
      }
    });
  }

  get receive$(): EmitterResourceTrait<WebSocketDownValue> {
    return this.#receive$.emitter;
  }
}
