import { ResourceTrait } from '../../../../resource/traits/resource.trait.js';
import { MqttSubscriptionResourceChange$Trait } from './properties/change$/mqtt-subscription-resource.change$.trait.js';

export interface MqttSubscriptionResourceTrait
  extends ResourceTrait,
    MqttSubscriptionResourceChange$Trait {}
