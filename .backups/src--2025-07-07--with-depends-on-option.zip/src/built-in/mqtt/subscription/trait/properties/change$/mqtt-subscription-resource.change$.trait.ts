import { EmitterResourceTrait } from '../../../../../emitter-resource/traits/emitter-resource.trait.js';
import { MqttPublishPacket } from './mqtt-publish-packet.js';

export interface MqttSubscriptionResourceChange$Trait {
  readonly change$: EmitterResourceTrait<MqttPublishPacket>;
}
