import { IPublishPacket, MqttClient } from 'mqtt';
import { CreateChildResourceOptions } from '../../../../resource/factory/shared/shared-resource-factory.js';
import { Resource } from '../../../../resource/implementations/resource.js';
import { EmitterResourceDispatcher } from '../../../emitter-resource/dispatcher/implementations/emitter-resource-dispatcher.js';
import { EmitterResourceTrait } from '../../../emitter-resource/traits/emitter-resource.trait.js';
import { MqttTopic } from '../../topic/mqtt-topic.js';
import { MqttSubscriptionResourceTrait } from '../trait/mqtt-subscription-resource.trait.js';
import { MqttPublishPacket } from '../trait/properties/change$/mqtt-publish-packet.js';

export interface MqttSubscriptionResourceOptions extends CreateChildResourceOptions {
  readonly client: MqttClient;
  readonly topic: string;
}

export class MqttSubscriptionResource extends Resource implements MqttSubscriptionResourceTrait {
  readonly #change$: EmitterResourceDispatcher<MqttPublishPacket>;

  constructor({ client, topic, close, ...options }: MqttSubscriptionResourceOptions) {
    const topicMatcher: MqttTopic = new MqttTopic(topic);

    const onClientMessage = (topic: string, payload: Buffer, _packet: IPublishPacket): void => {
      if (topicMatcher.matches(topic)) {
        this.#change$.dispatch({
          topic,
          payload,
        });
      }
    };

    client.on('message', onClientMessage);

    super({
      ...options,
      close: (reason: unknown): PromiseLike<void> | void => {
        client.off('message', onClientMessage);
        return close?.(reason);
      },
    });

    this.#change$ = new EmitterResourceDispatcher<MqttPublishPacket>();
  }

  get change$(): EmitterResourceTrait<MqttPublishPacket> {
    return this.#change$.emitter;
  }
}
