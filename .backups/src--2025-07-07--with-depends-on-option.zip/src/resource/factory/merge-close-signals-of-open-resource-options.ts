import { mergeAbortSignals } from '@xstd/abortable';
import { type Resource } from '../implementations/resource.js';
import { type OpenResourceOptions } from './open-resource.js';

export function mergeCloseSignalsOfOpenResourceOptions({
  dependsOn = [],
  signal,
}: OpenResourceOptions): AbortSignal {
  return mergeAbortSignals([
    signal,
    ...Array.from(dependsOn, (required: Resource): AbortSignal => required.closeSignal),
  ]);
}
