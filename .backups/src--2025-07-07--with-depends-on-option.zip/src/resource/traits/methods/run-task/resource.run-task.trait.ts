export interface ResourceRunTaskTrait {
  /**
   * Runs and appends a _task_ linked to this `Resource`.
   */
  runTask<GReturn>(
    task: Promise<GReturn> | (() => PromiseLike<GReturn> | GReturn),
  ): Promise<GReturn>;
}
