import { type ResourceTrait } from '../traits/resource.trait.js';

export interface ResourceOptions {
  readonly close?: CloseResource;
  readonly dependsOn?: Iterable<Resource>;
}

export interface CloseResource {
  (reason: unknown): PromiseLike<void> | void;
}

export class Resource implements ResourceTrait {
  // close
  readonly #close: CloseResource | undefined;
  readonly #closedPromise: PromiseWithResolvers<unknown>;
  #closed: boolean;
  #closeReason: unknown;

  // tree
  #requires: ReadonlySet<Resource>;
  #isRequiredBy: Set<Resource>;

  // tasks
  readonly #pendingTasks: Set<Promise<any>>;

  // misc
  #controller: AbortController | undefined;

  constructor({ close, dependsOn }: ResourceOptions = {}) {
    this.#close = close;
    this.#closedPromise = Promise.withResolvers<unknown>();
    this.#closed = false;

    this.#requires = dependsOn === undefined ? new Set<Resource>() : new Set<Resource>(dependsOn);
    this.#isRequiredBy = new Set<Resource>();

    this.#pendingTasks = new Set<Promise<any>>();

    for (const required of this.#requires) {
      if (required.#closed) {
        throw new Error('One of the required Resources is closed.');
      }

      required.#isRequiredBy.add(this);
    }
  }

  /* CLOSE */

  /**
   * A Promise resolved when the `Resource` is closed.
   */
  get closed(): Promise<unknown> {
    return this.#closedPromise.promise;
  }

  /**
   * An `AbortSignal` aborted when the `Resource` is closing.
   */
  get closeSignal(): AbortSignal {
    if (this.#controller === undefined) {
      this.#controller = new AbortController();

      if (this.#closed) {
        this.#controller.abort(this.#closeReason);
      }
    }

    return this.#controller.signal;
  }

  /**
   * Closes the `Resource`.
   */
  async close(reason?: unknown): Promise<void> {
    if (!this.#closed) {
      this.#closed = true;
      this.#closeReason = reason;

      if (this.#controller !== undefined) {
        this.#controller.abort(reason);
      }

      this.#closedPromise.resolve(
        Promise.allSettled([
          ...this.#isRequiredBy.values().map((childResource: Resource): Promise<void> => {
            return childResource.close(reason);
          }),
          ...this.#pendingTasks.values(),
        ])
          .then((): PromiseLike<void> | void => {
            return this.#close?.(reason);
          })
          .finally((): void => {
            for (const required of this.#requires) {
              required.#isRequiredBy.delete(this);
            }
          }),
      );
    }

    await this.#closedPromise.promise!;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }

  /* TASKS */

  /**
   * Runs and appends a _task_ linked to this `Resource`.
   */
  async runTask<GReturn>(
    task: Promise<GReturn> | (() => PromiseLike<GReturn> | GReturn),
  ): Promise<GReturn> {
    if (this.#closed) {
      throw new Error('Resource closed.');
    }

    if (typeof task === 'function') {
      task = Promise.try(task);
    }

    if (this.#pendingTasks.has(task)) {
      throw new Error('Task already running.');
    }

    this.#pendingTasks.add(task);

    try {
      return await task;
    } finally {
      this.#pendingTasks.delete(task);
    }
  }
}
