import { Abortable, mergeAbortSignals } from '@xstd/abortable';
import { MapFunction } from '@xstd/functional';
import { noop } from '@xstd/noop';
import { InitResourceContext, Resource } from '../../resource/resource.js';

export interface EmitterResourceListener<GValue> {
  (value: GValue): void;
}

export interface EmitterResourceToAsyncIteratorOptions extends Abortable {
  readonly bufferSize?: number;
  readonly windowTime?: number;
}

export interface InitEmitterResource<GValue> {
  (dispatch: DispatchEmitterResourceValue<GValue>): void;
}

export interface DispatchEmitterResourceValue<GValue> {
  (value: GValue): void;
}

// export class EmitterResource<GValue> extends Resource<EmitterResourceRef<GValue>> {
//   constructor(init: InitEmitterResource<GValue>) {
//     super((ctx: InitResourceContext): EmitterResourceRef<GValue> => {
//       return new EmitterResourceRef<GValue>(ctx, init);
//     });
//   }
// }

export type EmitterResource<GValue> = Resource<EmitterResourceRef<GValue>>;

export class EmitterResourceRef<GValue> {
  static readonly #maxUnsubscribeCount: number = 0xff;

  static new<GValue>(init: InitEmitterResource<GValue>): EmitterResourceRef<unknown> {}

  readonly #ctx: InitResourceContext;

  // the list of listeners
  #listeners: EmitterResourceListener<GValue>[];

  // the number of postponed unsubscribed listeners
  #postponedUnsubscriptions: number;
  // the id of the last batch of unsubscriptions
  #lastUnsubscriptionsBatchId: number;
  // if we are dispatching
  #dispatching: boolean;

  private constructor(ctx: InitResourceContext, init: InitEmitterResource<GValue>) {
    this.#ctx = ctx;
    this.#listeners = [];
    this.#postponedUnsubscriptions = 0;
    this.#lastUnsubscriptionsBatchId = 0;
    this.#dispatching = false;

    init((value: GValue): void => {
      this.#dispatch(value);
    });
  }

  #dispatch(value: GValue): void {
    return this.#ctx.runTask((): void => {
      if (this.#dispatching) {
        throw new Error('Dispatch loop detected.');
      }

      this.#dispatching = true;

      for (let i: number = 0; i < this.#listeners.length; i++) {
        this.#listeners[i](value);
      }

      this.#batchUnsubscribe();

      this.#dispatching = false;
    });
  }

  #batchUnsubscribe(): void {
    if (this.#postponedUnsubscriptions >= EmitterResourceRef.#maxUnsubscribeCount) {
      this.#postponedUnsubscriptions = 0;
      this.#lastUnsubscriptionsBatchId++;
      this.#listeners = this.#listeners.filter(
        (listener: EmitterResourceListener<GValue>): boolean => {
          return listener !== noop;
        },
      );
    }
  }

  listen(listener: EmitterResourceListener<GValue>): Resource<void> {
    return this.#ctx.runTask((): Resource<void> => {
      let listenerIndex: number = this.#listeners.length;
      let listenerUnsubscriptionsBatchId: number = this.#lastUnsubscriptionsBatchId;

      this.#listeners.push(listener);

      return new Resource<void>((ctx: InitResourceContext): void => {
        ctx.signal.addEventListener(
          'abort',
          (): void => {
            if (listenerUnsubscriptionsBatchId !== this.#lastUnsubscriptionsBatchId) {
              // => a batch of unsubscriptions happened before we unsubscribed this listener
              listenerIndex = this.#listeners.indexOf(listener);
            }
            this.#listeners[listenerIndex] = noop;
            this.#postponedUnsubscriptions++;

            if (!this.#dispatching) {
              this.#batchUnsubscribe();
            }
          },
          {
            once: true,
          },
        );

        this.#ctx.signal.addEventListener(
          'abort',
          (): void => {
            void ctx.close(this.#ctx.signal.reason);
          },
          {
            signal: ctx.signal,
          },
        );
      });
    });
  }

  map<GNewValue>(mapFnc: MapFunction<GValue, GNewValue>): EmitterResourceRef<GNewValue> {
    return new EmitterResourceRef<GNewValue>((ctx: InitEmitterResourceContext<GNewValue>): void => {
      const listener: Resource<void> = this.listen((value: GValue): void => {
        ctx.dispatch(mapFnc(value));
      });

      ctx.addTeardown((reason: unknown): Promise<void> => {
        return listener.close(reason);
      });

      listener.signal.addEventListener(
        'abort',
        (): void => {
          void ctx.close(listener.signal.reason);
        },
        {
          signal: ctx.signal,
        },
      );
    });
  }

  async *toAsyncGenerator({
    bufferSize = Number.POSITIVE_INFINITY,
    windowTime = Number.POSITIVE_INFINITY,
    signal,
  }: EmitterResourceToAsyncIteratorOptions = {}): AsyncGenerator<GValue> {
    bufferSize = Math.max(0, bufferSize);
    windowTime = Math.max(0, windowTime);

    const sharedSignal: AbortSignal = mergeAbortSignals([signal, this.#ctx.signal]);

    interface PendingValue {
      readonly value: GValue;
      readonly expirationDate: number;
    }

    const values: PendingValue[] = [];
    let pendingRead: PromiseWithResolvers<void> | undefined;

    await using _listenerHook = this.listen((value: GValue): void => {
      if (bufferSize > 0 && windowTime > 0) {
        values.push({
          value,
          expirationDate: Date.now() + windowTime,
        });

        if (values.length > bufferSize) {
          values.shift();
        }
      } else {
        if (pendingRead !== undefined) {
          values.length = 0;
          values.push({
            value,
            expirationDate: Number.POSITIVE_INFINITY,
          });
        }
      }

      if (pendingRead !== undefined) {
        pendingRead.resolve();
        pendingRead = undefined;
      }
    });

    while (true) {
      sharedSignal.throwIfAborted();

      // remove the expired values
      const now: number = Date.now();
      while (values.length > 0 && values[0].expirationDate < now) {
        values.shift();
      }

      if (values.length > 0) {
        yield values.shift()!.value;
      } else {
        pendingRead = Promise.withResolvers<void>();

        const onAbort = (): void => {
          sharedSignal.removeEventListener('abort', onAbort);
          pendingRead!.reject(sharedSignal!.reason);
          pendingRead = undefined;
        };

        sharedSignal.addEventListener('abort', onAbort);

        try {
          await pendingRead.promise;
        } finally {
          sharedSignal.removeEventListener('abort', onAbort);
        }
      }
    }
  }

  [Symbol.asyncIterator](): AsyncGenerator<GValue, void, void> {
    return this.toAsyncGenerator();
  }
}
