import { type InitResourceContext } from '../resource.js';

export interface CloseResourceChildContextWhenParentCloseOptions {
  readonly withTeardown?: boolean;
}

export function closeResourceChildContextWhenParentClose(
  parentContext: InitResourceContext,
  childContext: InitResourceContext,
  { withTeardown = true }: CloseResourceChildContextWhenParentCloseOptions = {},
): any {
  if (parentContext.signal.aborted) {
    throw new Error('parent resource aborted');
  }

  if (childContext.signal.aborted) {
    throw new Error('child resource aborted');
  }

  if (withTeardown) {
    parentContext.addTeardown((reason: unknown): Promise<void> | void => {
      if (!childContext.signal.aborted) {
        return childContext.close(reason);
      }
    });
  }

  parentContext.signal.addEventListener(
    'abort',
    (): void => {
      void childContext.close(parentContext.signal.reason);
    },
    {
      signal: childContext.signal,
      once: true,
    },
  );
}
