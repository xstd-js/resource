import { runSequentiallyVoidPromiseFactories } from './helpers/run-sequentially-void-promise-factories.js';

export interface RunResourceTask {
  <GReturn>(task: ResourceTask<GReturn>): GReturn;
}

export interface ResourceTask<GReturn> {
  (): GReturn;
}

export interface RunAsyncResourceTask {
  <GReturn>(task: AsyncResourceTask<GReturn> | PromiseLike<GReturn>): Promise<GReturn>;
}

export interface AsyncResourceTask<GReturn> {
  (signal: AbortSignal): PromiseLike<GReturn> | GReturn;
}

export interface AddResourceTeardown {
  (teardown: ResourceTeardown): void;
}

export interface ResourceTeardown {
  (reason: unknown): PromiseLike<any> | any;
}

export interface CloseResource {
  (reason?: unknown): Promise<void>;
}

export interface InitResource<GRef> {
  (ctx: InitResourceContext): GRef;
}

export interface InitResourceContext {
  readonly signal: AbortSignal;
  readonly close: CloseResource;
  readonly runTask: RunResourceTask;
  readonly runAsyncTask: RunAsyncResourceTask;
  readonly addTeardown: AddResourceTeardown;
}

export abstract class PrimitiveResource<GRef> {
  abstract readonly ref: GRef;
  abstract readonly signal: AbortSignal;
  abstract readonly closed: Promise<void>;
}

export class Resource<GRef> extends PrimitiveResource<GRef> {
  readonly #ref: GRef;

  readonly #controller: AbortController;
  readonly #closePromise: PromiseWithResolvers<void>;
  readonly #pendingTasks: Set<Promise<unknown>>;
  readonly #teardowns: ResourceTeardown[];

  #primitive!: PrimitiveResource<GRef>;

  constructor(init: InitResource<GRef>) {
    super();

    this.#controller = new AbortController();
    this.#closePromise = Promise.withResolvers();
    this.#pendingTasks = new Set<Promise<unknown>>();
    this.#teardowns = [];

    this.#ref = init({
      signal: this.#controller.signal,
      close: (reason?: unknown): Promise<void> => {
        return this.close(reason);
      },
      runTask: <GReturn>(task: ResourceTask<GReturn>): GReturn => {
        return this.#runTask<GReturn>(task);
      },
      runAsyncTask: async <GReturn>(
        task: AsyncResourceTask<GReturn> | PromiseLike<GReturn>,
      ): Promise<GReturn> => {
        return this.#runAsyncTask<GReturn>(task);
      },
      addTeardown: (teardown: ResourceTeardown): void => {
        return this.#addTeardown(teardown);
      },
    });
  }

  #throwIfClosed(): void {
    if (this.#controller.signal.aborted) {
      throw new Error('Resource closed.');
    }
  }

  #runTask<GReturn>(task: ResourceTask<GReturn>): GReturn {
    this.#throwIfClosed();
    return task();
  }

  async #runAsyncTask<GReturn>(
    task: AsyncResourceTask<GReturn> | PromiseLike<GReturn>,
  ): Promise<GReturn> {
    this.#throwIfClosed();

    const taskPromise: Promise<GReturn> =
      typeof task === 'function' ?
        Promise.try(task, this.#controller.signal)
      : Promise.resolve(task);

    this.#pendingTasks.add(taskPromise);

    try {
      return await taskPromise;
    } finally {
      this.#pendingTasks.delete(taskPromise);
    }
  }

  #addTeardown(teardown: ResourceTeardown): void {
    this.#throwIfClosed();
    this.#teardowns.push(teardown);
  }

  override get ref(): GRef {
    return this.#ref;
  }

  override get signal(): AbortSignal {
    return this.#controller.signal;
  }

  override get closed(): Promise<void> {
    return this.#closePromise.promise;
  }

  close(reason?: unknown): Promise<void> {
    if (!this.#controller.signal.aborted) {
      this.#controller.abort(reason);

      this.#closePromise.resolve(
        Promise.allSettled(this.#pendingTasks.values())
          // .then(async (): Promise<void> => {
          //   let isErrored: boolean = false;
          //   let error: unknown;
          //
          //   for (let i: number = this.#teardowns.length - 1; i >= 0; i--) {
          //     try {
          //       await this.#teardowns[i](reason);
          //     } catch (closeError: unknown) {
          //       if (isErrored) {
          //         error = new SuppressedError(closeError, error);
          //       } else {
          //         isErrored = true;
          //         error = closeError;
          //       }
          //     }
          //   }
          //
          //   if (isErrored) {
          //     throw error;
          //   }
          // })
          .then((): Promise<void> => {
            return runSequentiallyVoidPromiseFactories(this.#teardowns.reverse(), reason);
          }),
      );
    }

    return this.#closePromise.promise;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }

  toPrimitive(): PrimitiveResource<GRef> {
    if (this.#primitive === undefined) {
      this.#primitive = new ResourceToPrimitive(
        this.#ref,
        this.#controller.signal,
        this.#closePromise.promise,
      );
    }
    return this.#primitive;
  }
}

export class ResourceToPrimitive<GRef> extends PrimitiveResource<GRef> {
  readonly #ref: GRef;
  readonly #signal: AbortSignal;
  readonly #closed: Promise<void>;

  constructor(ref: GRef, signal: AbortSignal, closed: Promise<void>) {
    super();
    this.#ref = ref;
    this.#signal = signal;
    this.#closed = closed;
  }

  override get ref(): GRef {
    return this.#ref;
  }

  override get signal(): AbortSignal {
    return this.#signal;
  }

  override get closed(): Promise<void> {
    return this.#closed;
  }
}
