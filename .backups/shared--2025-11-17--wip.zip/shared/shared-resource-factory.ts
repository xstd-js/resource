import { type Abortable, abortify } from '@xstd/abortable';
import { ResourceFactory } from '../../factory/resource-factory.js';
import { type OpenResource } from '../../factory/types/open-resource.js';
import { Resource } from '../../resource/resource.js';
import { forceResourcesToAdoptThisOnclose } from './forced-ressource-on-close.private.js';
import { type SharedResource } from './shared-resource.js';

export interface SharedResourceFactoryOptions<
  GOriginalResource extends Resource,
  GSharedResource extends SharedResource,
> extends SharedResourceFactoryOptionsForConsumer {
  readonly open: OpenResource<[], GOriginalResource> | ResourceFactory<[], GOriginalResource>;
  readonly create: CreateSharedResource<GOriginalResource, GSharedResource>;
}

export interface SharedResourceFactoryOptionsForConsumer {
  readonly maintainAlive?: number;
}

export interface CreateSharedResource<
  GOriginalResource extends Resource,
  GSharedResource extends SharedResource,
> {
  (originalResource: GOriginalResource): GSharedResource;
}

export class SharedResourceFactory<
  GOriginalResource extends Resource,
  GSharedResource extends SharedResource,
> extends ResourceFactory<[], GSharedResource> {
  constructor({
    open,
    create,
    maintainAlive = 0,
  }: SharedResourceFactoryOptions<GOriginalResource, GSharedResource>) {
    if (typeof open === 'function') {
      open = new ResourceFactory<[], GOriginalResource>(open);
    }

    let consumers: number = 0;
    let openController: AbortController | undefined;
    let openPromise: Promise<void> | undefined;
    let originalResource: GOriginalResource | undefined;
    let closePromise: Promise<void> | undefined;
    let maintainAliveTimer: any | undefined;

    const closeDefinitively = async (reason: unknown): Promise<void> => {
      openController!.abort(reason);
      openController = undefined;

      const { promise, resolve } = Promise.withResolvers<void>();
      closePromise = promise;

      try {
        await originalResource!.close();
      } finally {
        originalResource = undefined;
        closePromise = undefined;
        resolve();
      }
    };

    const close = async (reason: unknown): Promise<void> => {
      consumers--;

      if (consumers === 0) {
        if (maintainAlive <= 0) {
          await closeDefinitively(reason);
        } else {
          maintainAliveTimer = setTimeout((): void => {
            maintainAliveTimer = undefined;
            closeDefinitively(reason).catch(reportError);
          }, maintainAlive);
        }
      }
    };

    super(async ({ signal }: Abortable = {}): Promise<GSharedResource> => {
      signal?.throwIfAborted();

      if (maintainAliveTimer !== undefined) {
        clearTimeout(maintainAliveTimer);
        maintainAliveTimer = undefined;
      }

      if (closePromise !== undefined) {
        await abortify(closePromise, { signal });
      }

      consumers++;

      try {
        if (consumers === 1) {
          openController = new AbortController();
          const signal: AbortSignal = openController.signal;
          openPromise = open.open({ signal }).then((resource: GOriginalResource): void => {
            signal.throwIfAborted();
            originalResource = resource;
          });
        }

        await abortify(openPromise!, {
          signal,
        });

        return forceResourcesToAdoptThisOnclose(
          {
            close,
          },
          (): GSharedResource => {
            return create(originalResource!).closesWith(originalResource!);
          },
        );
      } catch (error: unknown) {
        try {
          await close(error);
        } catch (_error: unknown) {
          throw new SuppressedError(error, _error);
        }

        throw error;
      }
    });
  }
}
