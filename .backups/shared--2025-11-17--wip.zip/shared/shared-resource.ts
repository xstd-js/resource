import { runSequentiallyVoidPromiseFactories } from '../../helpers/run-sequentially-void-promise-factories.js';
import { Resource } from '../../resource/resource.js';
import { type OnCloseResource } from '../../resource/types/on-close-resource.js';
import {
  getForcedResourceOnClose,
  type InternalResourceContext,
} from './forced-ressource-on-close.private.js';

export class SharedResource extends Resource {
  constructor(close?: OnCloseResource) {
    const context: InternalResourceContext = getForcedResourceOnClose();

    super(
      close === undefined
        ? context.close
        : (reason: unknown): Promise<void> => {
            return runSequentiallyVoidPromiseFactories([close, context.close], reason);
          },
    );
  }
}
