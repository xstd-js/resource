import { Resource, type ResourceOptions } from '../../resource/resource.js';

export class ResourceWithData<GData> extends Resource {
  readonly #data: GData;

  constructor(data: GData, options?: ResourceOptions) {
    super(options);
    this.#data = data;
  }

  get data(): GData {
    return this.#data;
  }
}
