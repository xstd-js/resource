import { type Abortable, abortify } from '@xstd/abortable';
import { SharedAsyncRefCount } from './shared-async-ref-count.js';

export interface AbortableAsyncDisposable {
  [Symbol.asyncDispose](options?: Abortable): PromiseLike<void>;
}

export interface OpenSharedValue<GShared extends AbortableAsyncDisposable> {
  (signal: AbortSignal): PromiseLike<GShared> | GShared;
}

export class AsyncRefCount<GShared extends AbortableAsyncDisposable> {
  readonly #open: OpenSharedValue<GShared>;

  #count: number;

  #openController: AbortController | undefined;
  #openPromise: Promise<GShared> | undefined;

  #closeController: AbortController | undefined;
  #closePromise: Promise<void> | undefined;

  constructor(open: OpenSharedValue<GShared>) {
    this.#open = open;
    this.#count = 0;
  }

  async #close(shared: GShared): Promise<void> {
    this.#closeController = new AbortController();

    try {
      await (this.#closePromise = Promise.try(shared[Symbol.asyncDispose], {
        signal: this.#closeController!.signal,
      }));
    } finally {
      this.#closeController = undefined;
      this.#closePromise = undefined;
    }
  }

  async open({ signal }: Abortable = {}): Promise<SharedAsyncRefCount<GShared>> {
    signal?.throwIfAborted();

    if (this.#closePromise !== undefined) {
      this.#closeController!.abort();

      await abortify(
        this.#closePromise.catch((): void => {}),
        { signal },
      );
    }

    this.#count++;

    if (this.#count === 1) {
      const openController: AbortController = new AbortController();
      this.#openController = openController;
      this.#openPromise = Promise.try(this.#open, openController.signal).finally((): void => {
        openController.abort();
        if (this.#openController === openController) {
          this.#openController = undefined;
        }
      });
    }

    try {
      const shared: GShared = await abortify(this.#openPromise!, {
        signal,
      });

      return new SharedAsyncRefCount<GShared>(shared, async (): Promise<void> => {
        this.#count--;

        if (this.#count === 0) {
          await this.#close(shared);
        }
      });
    } catch (error: unknown) {
      try {
        // => failed to open shared resource OR signal aborted
        this.#count--;

        if (this.#count === 0) {
          this.#openController?.abort();
          // safeguard: if `openPromise` resolves (should not happen), we close it immediately
          await this.#close(await this.#openPromise!);
        }
      } finally {
        throw error;
      }
    }
  }
}
