import { type MqttResourcePublishOptions } from './mqtt-resource-publish-options.js';

export interface MqttResourcePublishTrait {
  publish(
    topic: string,
    payload: string | Uint8Array,
    options: MqttResourcePublishOptions,
  ): Promise<void>;
}
