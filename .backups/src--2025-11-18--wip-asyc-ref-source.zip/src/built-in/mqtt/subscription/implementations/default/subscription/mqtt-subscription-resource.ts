import { type Abortable, mergeAbortSignals } from '@xstd/abortable';
import { MqttTopic } from '@xstd/mqtt-topic';
import { type IPublishPacket, type MqttClient } from 'mqtt';
import { ResourceFactory } from '../../../../../../factory/resource-factory.js';
import { Resource } from '../../../../../../resource/resource.js';
import { resolveMaxMaintainAliveOptions } from '../../../../../ref-count/maintain-alive-option/helpers/resolve-max-maintain-alive-options.js';
import { type MaintainAliveOption } from '../../../../../ref-count/maintain-alive-option/maintain-alive-option.js';
import {
  type CloseRefCountResource,
  RefCountResourceFactory,
} from '../../../../../ref-count/ref-count-resource-factory.js';
import { type MqttSubscriptionResourceTrait } from '../../../traits/mqtt-subscription-resource.trait.js';
import { type MqttSubscriptionResourceOpenOptions } from '../../../traits/static/types/methods/open/mqtt-subscription-resource-open-options.js';
import { type MqttSubscriptionResourceOptions } from '../../../traits/static/types/mqtt-subscription-resource-options.js';
import { type MqttSubscriptionResourceFactory } from '../../../traits/static/types/properties/factory/mqtt-subscription-resource-factory.js';
import { type MqttSubscriptionResourceListener } from '../../../traits/types/methods/listen/mqtt-subscription-resource-listener.js';
import { subscribeToMqttClientSubscription } from './functions.private/subscribe-to-mqtt-client-subscription.js';

/* INTERNAL TYPES */

interface ActiveSubscription
  extends Omit<Required<MqttSubscriptionResourceOptions>, 'maintainAlive'> {
  readonly maintainAliveOptions: MaintainAliveOption[];
  readonly factory: RefCountResourceFactory<Resource, MqttSubscriptionResource>;
}

/* CLASS */

export class MqttSubscriptionResource extends Resource implements MqttSubscriptionResourceTrait {
  static #activeSubscriptions = new WeakMap<
    MqttClient,
    Map<string /* topic */, ActiveSubscription>
  >();

  static readonly #factory: MqttSubscriptionResourceFactory<MqttSubscriptionResource> =
    new ResourceFactory<
      [client: MqttClient, topic: string],
      MqttSubscriptionResource,
      MqttSubscriptionResourceOpenOptions
    >(
      async (
        client: MqttClient,
        topic: string,
        {
          qos = 0,
          noLocal = false,
          retainAsPublished = false,
          retainHandling = 0,
          maintainAlive = 0,
          signal,
        }: MqttSubscriptionResourceOpenOptions = {},
      ): Promise<MqttSubscriptionResource> => {
        signal?.throwIfAborted();

        let activeSubscriptions: Map<string, ActiveSubscription> | undefined =
          this.#activeSubscriptions.get(client);

        if (activeSubscriptions === undefined) {
          activeSubscriptions = new Map<string, ActiveSubscription>();
          this.#activeSubscriptions.set(client, activeSubscriptions);
        }

        let activeSubscription: ActiveSubscription | undefined = activeSubscriptions.get(topic);

        if (activeSubscription === undefined) {
          const maintainAliveOptions: MaintainAliveOption[] = [];

          activeSubscription = {
            qos,
            noLocal,
            retainAsPublished,
            retainHandling,
            factory: new RefCountResourceFactory<Resource, MqttSubscriptionResource>({
              open: async ({ signal }: Abortable = {}): Promise<Resource> => {
                await subscribeToMqttClientSubscription(client, topic, {
                  qos,
                  noLocal,
                  retainAsPublished,
                  retainHandling,
                  signal,
                });

                return new Resource(async (): Promise<void> => {
                  try {
                    await client.unsubscribeAsync(topic);
                  } finally {
                    activeSubscriptions.delete(topic);
                    if (activeSubscriptions.size === 0) {
                      this.#activeSubscriptions.delete(client);
                    }
                  }
                });
              },
              create: (
                sharedResource: Resource,
                close: CloseRefCountResource,
              ): MqttSubscriptionResource => {
                return new MqttSubscriptionResource(client, topic, close).closesWith(
                  sharedResource,
                );
              },
              maintainAlive: (): number => {
                return resolveMaxMaintainAliveOptions(maintainAliveOptions);
              },
            }),
            maintainAliveOptions,
          };

          activeSubscriptions.set(topic, activeSubscription);
        } else if (
          activeSubscription.qos !== qos ||
          activeSubscription.noLocal !== noLocal ||
          activeSubscription.retainAsPublished !== retainAsPublished ||
          activeSubscription.retainHandling !== retainHandling
        ) {
          throw new Error(`Subscription to "${topic}" already locked.`);
        }

        activeSubscription!.maintainAliveOptions.push(maintainAlive);

        return activeSubscription!.factory.open({ signal });
      },
    );

  static get factory(): MqttSubscriptionResourceFactory<MqttSubscriptionResource> {
    return this.#factory;
  }

  static open(
    client: MqttClient,
    topic: string,
    options?: MqttSubscriptionResourceOpenOptions,
  ): Promise<MqttSubscriptionResource> {
    return this.#factory.open(client, topic, options);
  }

  readonly #client: MqttClient;
  readonly #topic: MqttTopic;

  protected constructor(client: MqttClient, topic: string, close: CloseRefCountResource) {
    super(close);

    this.#client = client;
    this.#topic = new MqttTopic(topic);
  }

  listen(listener: MqttSubscriptionResourceListener, { signal }: Abortable = {}): void {
    if (signal?.aborted) {
      throw signal.reason;
    }

    this.throwIfClosed();

    const onClientMessage = (topic: string, payload: Buffer, _packet: IPublishPacket): void => {
      if (this.#topic.matches(topic)) {
        listener({
          topic,
          payload,
        });
      }
    };

    this.#client.on('message', onClientMessage);

    mergeAbortSignals([this.closeSignal, signal]).addEventListener(
      'abort',
      (): void => {
        this.#client.off('message', onClientMessage);
      },
      { once: true },
    );
  }
}
