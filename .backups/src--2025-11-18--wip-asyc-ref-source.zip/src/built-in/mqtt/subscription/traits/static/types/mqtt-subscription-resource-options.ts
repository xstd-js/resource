import { type HavingMaintainAliveOption } from '../../../../../ref-count/maintain-alive-option/having-maintain-alive-option.js';

export interface MqttSubscriptionResourceOptions extends HavingMaintainAliveOption {
  readonly qos?: 0 | 1 | 2;
  readonly noLocal?: boolean;
  readonly retainAsPublished?: boolean;
  readonly retainHandling?: 0 | 1 | 2;
}
