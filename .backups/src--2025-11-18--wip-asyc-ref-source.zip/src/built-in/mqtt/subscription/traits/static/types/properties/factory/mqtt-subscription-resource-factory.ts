import { type MqttClient } from 'mqtt';
import { type ResourceFactory } from '../../../../../../../../factory/resource-factory.js';
import { type MqttSubscriptionResourceTrait } from '../../../../mqtt-subscription-resource.trait.js';
import { type MqttSubscriptionResourceOpenOptions } from '../../methods/open/mqtt-subscription-resource-open-options.js';

export type MqttSubscriptionResourceFactory<
  GMqttSubscriptionResource extends MqttSubscriptionResourceTrait,
> = ResourceFactory<
  [client: MqttClient, topic: string],
  GMqttSubscriptionResource,
  MqttSubscriptionResourceOpenOptions
>;
