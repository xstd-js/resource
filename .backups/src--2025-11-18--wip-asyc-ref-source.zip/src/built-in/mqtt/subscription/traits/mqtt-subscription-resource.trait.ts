import { type Resource } from '../../../../resource/resource.js';
import { type MqttSubscriptionResourceListenTrait } from './types/methods/listen/mqtt-subscription-resource.listen.trait.js';

export interface MqttSubscriptionResourceTrait
  extends Resource,
    MqttSubscriptionResourceListenTrait {}
