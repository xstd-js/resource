import { MapFunction } from '@xstd/functional';

export async function* mapAsyncIterable<GIn, GOut>(
  iterable: AsyncIteratorObject<GIn>,
  mapFnc: MapFunction<GIn, GOut>,
): AsyncGenerator<GOut> {
  for await (const value of iterable) {
    yield mapFnc(value);
  }
}
