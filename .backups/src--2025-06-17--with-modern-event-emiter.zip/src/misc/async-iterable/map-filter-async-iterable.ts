import { MapFilterFunction } from '@xstd/functional';

export async function* mapFilterAsyncIterable<GIn, GOut>(
  iterable: AsyncIteratorObject<GIn>,
  mapFnc: MapFilterFunction<GIn, GOut>,
): AsyncGenerator<GOut> {
  for await (const value of iterable) {
    const result: GOut | null = mapFnc(value);

    if (result !== null) {
      yield result;
    }
  }
}
