export class TypedEvent<GType extends string> extends Event {
  override readonly type!: GType;

  constructor(type: GType, options?: EventInit) {
    super(type, options);
  }
}
