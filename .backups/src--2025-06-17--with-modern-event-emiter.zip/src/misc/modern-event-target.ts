import { type Abortable, untilEvent } from '@xstd/abortable';
import { type UndoFunction } from '@xstd/undo-function';
import { TypedEvent } from './typed-event.js';

export type EventMapConstraint<GEventMap> = Record<Extract<keyof GEventMap, string>, Event>;

export type ModernEventTargetListener<GEvent extends Event> = (event: GEvent) => void;

export interface ModernEventTargetAsyncIteratorOptions extends Abortable {
  readonly bufferSize?: number;
  readonly windowTime?: number;
}

export class ModernEventTarget<
  GEventMap extends EventMapConstraint<GEventMap>,
> extends EventTarget {
  // @ts-ignore
  override addEventListener<GKey extends keyof GEventMap>(
    type: GKey,
    listener: ModernEventTargetListener<GEventMap[GKey]>,
    options?: boolean | AddEventListenerOptions,
  ): void;
  override addEventListener(
    type: string,
    listener: EventListenerOrEventListenerObject,
    options?: boolean | AddEventListenerOptions,
  ): void;
  override addEventListener(
    type: string,
    listener: EventListenerOrEventListenerObject,
    options?: boolean | AddEventListenerOptions,
  ): void {
    return super.addEventListener(type, listener, options);
  }

  // @ts-ignore
  override removeEventListener<GKey extends keyof GEventMap>(
    type: GKey,
    listener: ModernEventTargetListener<GEventMap[GKey]>,
    options?: boolean | EventListenerOptions,
  ): void;
  override removeEventListener(
    type: string,
    listener: EventListenerOrEventListenerObject,
    options?: boolean | EventListenerOptions,
  ): void;
  override removeEventListener(
    type: string,
    listener: EventListenerOrEventListenerObject,
    options?: boolean | EventListenerOptions,
  ): void {
    return super.removeEventListener(type, listener, options);
  }

  override dispatchEvent<GKey extends Extract<keyof GEventMap, string>>(
    event: TypedEvent<GKey>,
  ): boolean;
  override dispatchEvent(event: Event): boolean;
  override dispatchEvent(event: Event): boolean {
    return super.dispatchEvent(event);
  }

  listen<GKey extends keyof GEventMap>(
    type: GKey,
    listener: ModernEventTargetListener<GEventMap[GKey]>,
  ): UndoFunction {
    this.addEventListener(type, listener);

    return (): void => {
      this.removeEventListener(type, listener);
    };
  }

  /**
   * Returns a Promise resolved when an event of type `type` is received.
   * @param type The type to listen to.
   * @param options An optional AbortSignal to stop awaiting this event.
   */
  until<GKey extends keyof GEventMap>(type: GKey, options?: Abortable): Promise<GEventMap[GKey]> {
    return untilEvent<GEventMap[GKey]>(this, type as string, options);
  }

  async *iter<GKey extends keyof GEventMap>(
    type: GKey,
    {
      bufferSize = Number.POSITIVE_INFINITY,
      windowTime = Number.POSITIVE_INFINITY,
      signal,
    }: ModernEventTargetAsyncIteratorOptions = {},
  ): AsyncGenerator<GEventMap[GKey]> {
    type GValue = GEventMap[GKey];

    bufferSize = Math.max(0, bufferSize);
    windowTime = Math.max(0, windowTime);

    interface PendingValue {
      readonly value: GValue;
      readonly expirationDate: number;
    }

    const values: PendingValue[] = [];
    let pendingRead: PromiseWithResolvers<void> | undefined;

    using stack: DisposableStack = new DisposableStack();

    stack.defer(
      this.listen(type, (value: GValue): void => {
        if (bufferSize > 0 && windowTime > 0) {
          values.push({
            value,
            expirationDate: Date.now() + windowTime,
          });

          if (values.length > bufferSize) {
            values.shift();
          }
        } else {
          if (pendingRead !== undefined) {
            values.length = 0;
            values.push({
              value,
              expirationDate: Number.POSITIVE_INFINITY,
            });
          }
        }

        if (pendingRead !== undefined) {
          pendingRead.resolve();
          pendingRead = undefined;
        }
      }),
    );

    while (true) {
      signal?.throwIfAborted();

      // remove the expired values
      const now: number = Date.now();
      while (values.length > 0 && values[0].expirationDate < now) {
        values.shift();
      }

      if (values.length > 0) {
        yield values.shift()!.value;
      } else {
        pendingRead = Promise.withResolvers<void>();

        const onAbort = (): void => {
          signal!.removeEventListener('abort', onAbort);
          pendingRead!.reject(signal!.reason);
          pendingRead = undefined;
        };

        signal?.addEventListener('abort', onAbort);

        try {
          await pendingRead.promise;
        } finally {
          signal?.removeEventListener('abort', onAbort);
        }
      }
    }
  }
}
