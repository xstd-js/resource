import { Abortable, abortify, mergeAbortSignals } from '@xstd/abortable';
import { CompleteError } from '@xstd/custom-error';
import mqtt, { IDisconnectPacket, ISubscriptionGrant, MqttClient } from 'mqtt';
import {
  mergeAbortSignalsOfOpenResourceOptions,
  OpenResourceOptions,
} from '../../resource/open-resource.js';
import { Resource, ResourceOptions } from '../../resource/resource.js';
import {
  CreateChildResourceOptions,
  SharedResourceFactory,
} from '../../resource/shared-resource-factory.js';
import { MqttSubscriptionResource } from './mqtt-subscription-resource.js';

export interface MqttResourceOptions extends OpenResourceOptions {
  readonly clientId?: string;
  readonly username?: string;
  readonly password?: string;

  // readonly keepalive?: number;
  // readonly clean?: boolean;
}

interface InternalMqttResourceOptions extends Omit<ResourceOptions, 'close'> {
  readonly client: MqttClient;
}

export interface MqttResourcePublishOptions extends Abortable {
  readonly qos?: 0 | 1 | 2;
  readonly retain?: boolean;
  readonly dup?: boolean;
}

export interface MqttResourceSubscribeOptions extends Abortable {
  readonly qos?: 0 | 1 | 2;
  readonly noLocal?: boolean;
  readonly retainAsPublished?: boolean;
  readonly retainHandling?: 0 | 1 | 2;
}

interface ActiveSubscription {
  readonly qos: 0 | 1 | 2;
  readonly noLocal: boolean;
  readonly retainAsPublished: boolean;
  readonly retainHandling: 0 | 1 | 2;

  readonly shared: SharedResourceFactory<Resource, MqttSubscriptionResource>;
}

export class MqttResource extends Resource {
  static async open(url: string | URL, options: MqttResourceOptions = {}): Promise<MqttResource> {
    const signal: AbortSignal = mergeAbortSignalsOfOpenResourceOptions(options);
    signal.throwIfAborted();

    const client: MqttClient = await mqtt.connectAsync(url.toString(), {
      ...options,
      reconnectPeriod: 0,
      autoUseTopicAlias: true,
      autoAssignTopicAlias: true,
    });

    // TODO
    client.setMaxListeners(20);
    // client.setMaxListeners(50);

    if (signal.aborted) {
      await client.endAsync();
      throw signal.reason;
    }

    return new MqttResource({
      ...options,
      client,
    });
  }

  readonly #client: MqttClient;
  readonly #activeSubscriptions: Map<string /* topic */, ActiveSubscription>;

  private constructor({ client, ...options }: InternalMqttResourceOptions) {
    if (!client.connected) {
      throw new Error('MqttClient not open.');
    }

    const onClientDisconnect = (packet: IDisconnectPacket): void => {
      if (packet.reasonCode === undefined || packet.reasonCode === 0x00) {
        void this.close(new CompleteError());
      } else {
        void this.close(new Error('Disconnected', { cause: packet }));
      }
    };

    const onClientError = (error: unknown): void => {
      void this.close(error);
    };

    const onClientEnd = (): void => {
      void this.close(new Error('Client ended'));
    };

    client.on('disconnect', onClientDisconnect);
    client.on('error', onClientError);
    client.on('end', onClientEnd);

    super({
      ...options,
      close: async (): Promise<void> => {
        client.off('disconnect', onClientDisconnect);
        client.off('error', onClientError);
        client.off('end', onClientEnd);

        await client.endAsync();
      },
    });

    this.#client = client;
    this.#activeSubscriptions = new Map<string, ActiveSubscription>();
  }

  publish(
    topic: string,
    payload: string | Uint8Array,
    { signal, ...options }: MqttResourcePublishOptions = {},
  ): Promise<void> {
    return this.runTask(async (): Promise<void> => {
      await abortify(this.#client.publishAsync(topic, payload as any, options), {
        signal: mergeAbortSignals([signal, this.signal]),
      });
    });
  }

  async subscribe(
    topic: string,
    {
      qos = 0,
      noLocal = false,
      retainAsPublished = false,
      retainHandling = 0,
      signal,
    }: MqttResourceSubscribeOptions = {},
  ): Promise<MqttSubscriptionResource> {
    let activeSubscription: ActiveSubscription | undefined = this.#activeSubscriptions.get(topic);

    if (activeSubscription === undefined) {
      activeSubscription = {
        qos,
        noLocal,
        retainAsPublished,
        retainHandling,

        shared: new SharedResourceFactory<Resource, MqttSubscriptionResource>({
          main: async (signal: AbortSignal): Promise<Resource> => {
            try {
              const [granted]: ISubscriptionGrant[] = await this.#client.subscribeAsync(topic, {
                qos,
                nl: noLocal,
                rap: retainAsPublished,
                rh: retainHandling,
              });

              if (signal.aborted) {
                await this.#client.unsubscribeAsync(topic);
                throw signal.reason;
              }

              if (qos !== undefined && granted.qos < qos) {
                await this.#client.unsubscribeAsync(topic);
                throw new Error(
                  `Cannot subscribe to "${topic}" with a qos of ${qos}. Granted ${granted.qos}.`,
                );
              }

              return new Resource({
                close: async (): Promise<void> => {
                  try {
                    await this.#client.unsubscribeAsync(topic);
                  } finally {
                    this.#activeSubscriptions.delete(topic);
                  }
                },
                requires: [this],
              });
            } catch (error: unknown) {
              this.#activeSubscriptions.delete(topic);
              throw error;
            }
          },
          child: (options: CreateChildResourceOptions): MqttSubscriptionResource => {
            return new MqttSubscriptionResource({
              ...options,
              client: this.#client,
              topic,
            });
          },
        }),
      };

      this.#activeSubscriptions.set(topic, activeSubscription);
    } else {
      if (
        qos !== activeSubscription.qos ||
        noLocal !== activeSubscription.noLocal ||
        retainAsPublished !== activeSubscription.retainAsPublished ||
        retainHandling !== activeSubscription.retainHandling
      ) {
        throw new Error(
          `Subscription "${topic}" with options ${JSON.stringify({ qos, noLocal, retainAsPublished, retainHandling })} is already locked. Use the same options, or close the previous one.`,
        );
      }
    }

    return await activeSubscription.shared.open({ signal });
  }
}
