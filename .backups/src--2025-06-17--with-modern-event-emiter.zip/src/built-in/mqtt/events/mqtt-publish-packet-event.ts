import { TypedEvent } from '../../../misc/typed-event.js';

export class MqttPublishPacketEvent<GType extends string> extends TypedEvent<GType> {
  readonly topic: string;
  readonly payload: Uint8Array;

  constructor(type: GType, { topic, payload, ...options }: MqttPublishPacketEventInit) {
    super(type, options);

    this.topic = topic;
    this.payload = payload;
  }
}

export interface MqttPublishPacketEventInit extends EventInit {
  readonly topic: string;
  readonly payload: Uint8Array;
}
