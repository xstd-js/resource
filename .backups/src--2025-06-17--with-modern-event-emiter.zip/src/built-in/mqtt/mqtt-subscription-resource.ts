import { IPublishPacket, MqttClient } from 'mqtt';
import { Resource, ResourceEventMap } from '../../resource/resource.js';
import { CreateChildResourceOptions } from '../../resource/shared-resource-factory.js';
import { MqttPublishPacketEvent } from './events/mqtt-publish-packet-event.js';
import { MqttTopic } from './topic/mqtt-topic.js';

export interface MqttSubscriptionResourceEventMap extends ResourceEventMap {
  readonly packet: MqttPublishPacketEvent<'packet'>;
}

export interface MqttSubscriptionResourceOptions extends CreateChildResourceOptions {
  readonly client: MqttClient;
  readonly topic: string;
}

export class MqttSubscriptionResource extends Resource<MqttSubscriptionResourceEventMap> {
  constructor({ client, topic, close, ...options }: MqttSubscriptionResourceOptions) {
    const topicMatcher: MqttTopic = new MqttTopic(topic);

    const onClientMessage = (topic: string, payload: Buffer, _packet: IPublishPacket): void => {
      if (topicMatcher.matches(topic)) {
        this.dispatchEvent<'packet'>(
          new MqttPublishPacketEvent('packet', {
            topic,
            payload,
          }),
        );
      }
    };

    client.on('message', onClientMessage);

    super({
      ...options,
      close: (reason: unknown): PromiseLike<void> | void => {
        client.off('message', onClientMessage);
        return close?.(reason);
      },
    });
  }
}
