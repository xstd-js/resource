import { TypedEvent } from '../../../misc/typed-event.js';
import { WebSocketDownValue } from '../types/web-socket-down-value.js';

export class WebSocketMessageEvent<GType extends string> extends TypedEvent<GType> {
  readonly payload: WebSocketDownValue;

  constructor(type: GType, { payload, ...options }: WebSocketMessageEventInit) {
    super(type, options);

    this.payload = payload;
  }
}

export interface WebSocketMessageEventInit extends EventInit {
  readonly payload: WebSocketDownValue;
}
