export type WebSocketDownValue = ArrayBuffer | string;
