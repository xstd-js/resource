export type WebSocketUpValue = string | ArrayBufferLike | Blob | ArrayBufferView;
