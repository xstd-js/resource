import { type EventMapConstraint, ModernEventTarget } from '../misc/modern-event-target.js';
import { debugResource } from './helpers/debug-resource.js';

/*----*/

export interface ResourceOptions {
  readonly close?: CloseResource;
  readonly requires?: Iterable<Resource>;
}

export interface CloseResource {
  (reason: unknown): PromiseLike<void> | void;
}

export type ResourceState = 'open' | 'closing' | 'closed';

export interface ResourceEventMap {
  readonly closing: Event;
  readonly closed: Event;
}

export interface InspectResourceOptions {
  readonly open?: () => void;
  readonly closing?: (reason: unknown) => void;
  readonly closed?: (reason: unknown) => void;
}

export class Resource<
    GEventMap extends EventMapConstraint<GEventMap> & ResourceEventMap = ResourceEventMap,
  >
  extends ModernEventTarget<GEventMap>
  implements AsyncDisposable
{
  // close
  readonly #close: CloseResource | undefined;
  #state: ResourceState;
  #closeReason: unknown;
  #closePromise: Promise<void> | undefined;

  // tree
  #requires: ReadonlySet<Resource>;
  #isRequiredBy: Set<Resource>;

  // tasks
  readonly #pendingTasks: Set<Promise<any>>;

  // misc
  #controller: AbortController | undefined;

  constructor({ close, requires }: ResourceOptions) {
    super();

    this.#close = close;
    this.#state = 'open';

    this.#requires = requires === undefined ? new Set<Resource>() : new Set<Resource>(requires);
    this.#isRequiredBy = new Set<Resource>();

    this.#pendingTasks = new Set<Promise<any>>();

    for (const required of this.#requires) {
      if (required.#state !== 'open') {
        throw new Error('One of the required Resources is not open.');
      }

      required.#isRequiredBy.add(this);
    }
  }

  /* CLOSE */

  get state(): ResourceState {
    return this.#state;
  }

  get closeReason(): unknown {
    return this.#closeReason;
  }

  throwIfClosed(direct: boolean = false): void {
    if (this.#state !== 'open') {
      throw direct ?
          this.#closeReason
        : new Error('Resource closed.', {
            cause: this.#closeReason,
          });
    }
  }

  close(reason?: unknown): Promise<void> {
    if (this.#state === 'open') {
      this.#state = 'closing';
      this.#closeReason = reason;
      this.dispatchEvent(new Event('closing'));

      if (this.#controller !== undefined) {
        this.#controller.abort(reason);
      }

      this.#closePromise = Promise.allSettled([
        ...this.#isRequiredBy.values().map((childResource: Resource): Promise<void> => {
          return childResource.close(reason);
        }),
        ...this.#pendingTasks.values(),
      ])
        .then((): PromiseLike<void> | void => {
          return this.#close?.(reason);
        })
        .finally((): void => {
          this.#state = 'closed';

          for (const required of this.#requires) {
            required.#isRequiredBy.delete(this);
          }

          this.dispatchEvent(new Event('closed'));
        });
    }

    return this.#closePromise!;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }

  /* TREE */

  // get parents(): ReadonlySet<Resource> {
  //   return this.#parents;
  // }
  //
  // get children(): ReadonlySet<Resource> {
  //   return this.#children;
  // }

  /* TASKS */

  async runTask<GReturn>(
    task: Promise<GReturn> | (() => PromiseLike<GReturn> | GReturn),
  ): Promise<GReturn> {
    this.throwIfClosed();

    if (typeof task === 'function') {
      task = Promise.try(task);
    }

    if (this.#pendingTasks.has(task)) {
      throw new Error('Task already running.');
    }

    this.#pendingTasks.add(task);

    try {
      return await task;
    } finally {
      this.#pendingTasks.delete(task);
    }
  }

  /* MISC */

  get signal(): AbortSignal {
    if (this.#controller === undefined) {
      this.#controller = new AbortController();

      if (this.#state !== 'open') {
        this.#controller.abort(this.#closeReason);
      }
    }

    return this.#controller.signal;
  }

  inspect({ open, closing, closed }: InspectResourceOptions = {}): this {
    if (open !== undefined) {
      open();
    }

    if (closing !== undefined) {
      this.addEventListener('closing', (): void => {
        closing(this.#closeReason);
      });
    }

    if (closed !== undefined) {
      this.addEventListener('closed', (): void => {
        closed(this.#closeReason);
      });
    }

    return this;
  }

  debug(name: string): this {
    return this.inspect(debugResource(name));
  }
}
