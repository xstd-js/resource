import { type Abortable, mergeAbortSignals } from '@xstd/abortable';
import { type Resource, ResourceOptions } from './resource.js';

export interface OpenResource<GResource extends Resource> {
  (options?: OpenResourceOptions): PromiseLike<GResource> | GResource;
}

export interface OpenResourceOptions extends Omit<ResourceOptions, 'close'>, Abortable {}

export function mergeAbortSignalsOfOpenResourceOptions({
  requires = [],
  signal,
}: OpenResourceOptions): AbortSignal {
  return mergeAbortSignals([
    signal,
    ...Array.from(requires, (required: Resource): AbortSignal => required.signal),
  ]);
}
