import { FilterFunction } from '@lirx/utils';
import { Abortable, mergeAbortSignals } from '@xstd/abortable';
import { FilterFunctionWithSubType, MapFilterFunction, MapFunction } from '@xstd/functional';
import { noop } from '@xstd/noop';
import { ResourceCloser } from '../../resource/helpers/close/resource-closer.js';
import { Resource } from '../../resource/resource.js';

export interface EmitterResourceListener<GValue> {
  (value: GValue): void;
}

export interface EmitterResourceToAsyncIteratorOptions extends Abortable {
  readonly bufferSize?: number;
  readonly windowTime?: number;
}

export interface InitEmitterResource<GValue> {
  (dispatch: DispatchEmitterResourceValue<GValue>): void;
}

export interface DispatchEmitterResourceValue<GValue> {
  (value: GValue): void;
}

export interface EmitterResourceWithDispatcher<GValue> {
  readonly emitter: EmitterResource<GValue>;
  readonly dispatch: DispatchEmitterResourceValue<GValue>;
}

export class EmitterResource<GValue> extends Resource {
  static readonly #maxUnsubscribeCount: number = 0xff;

  static withDispatcher<GValue>(): EmitterResourceWithDispatcher<GValue> {
    let dispatch!: DispatchEmitterResourceValue<GValue>;
    const emitter = new EmitterResource<GValue>(
      (_dispatch: DispatchEmitterResourceValue<GValue>): void => {
        dispatch = _dispatch;
      },
    );

    return {
      emitter,
      dispatch,
    };
  }

  // the list of listeners
  #listeners: EmitterResourceListener<GValue>[];

  // the number of postponed unsubscribed listeners
  #postponedUnsubscriptions: number;
  // the id of the last batch of unsubscriptions
  #lastUnsubscriptionsBatchId: number;
  // if we are dispatching
  #dispatching: boolean;

  constructor(init: InitEmitterResource<GValue>) {
    super();
    this.#listeners = [];
    this.#postponedUnsubscriptions = 0;
    this.#lastUnsubscriptionsBatchId = 0;
    this.#dispatching = false;

    init((value: GValue): void => {
      this.#dispatch(value);
    });
  }

  #dispatch(value: GValue): void {
    this.throwIfClosed();

    if (this.#dispatching) {
      throw new Error('Dispatch loop detected.');
    }

    this.#dispatching = true;

    for (let i: number = 0; i < this.#listeners.length; i++) {
      this.#listeners[i](value);
    }

    this.#batchUnsubscribe();

    this.#dispatching = false;
  }

  #batchUnsubscribe(): void {
    if (this.#postponedUnsubscriptions >= EmitterResource.#maxUnsubscribeCount) {
      this.#postponedUnsubscriptions = 0;
      this.#lastUnsubscriptionsBatchId++;
      this.#listeners = this.#listeners.filter(
        (listener: EmitterResourceListener<GValue>): boolean => {
          return listener !== noop;
        },
      );
    }
  }

  listen(listener: EmitterResourceListener<GValue>): Resource {
    this.throwIfClosed();

    let listenerIndex: number = this.#listeners.length;
    let listenerUnsubscriptionsBatchId: number = this.#lastUnsubscriptionsBatchId;

    this.#listeners.push(listener);

    return ResourceCloser.closeChildResourceWhenParentCloses(
      new Resource((): void => {
        if (listenerUnsubscriptionsBatchId !== this.#lastUnsubscriptionsBatchId) {
          // => a batch of unsubscriptions happened before we unsubscribed this listener
          listenerIndex = this.#listeners.indexOf(listener);
        }
        this.#listeners[listenerIndex] = noop;
        this.#postponedUnsubscriptions++;

        if (!this.#dispatching) {
          this.#batchUnsubscribe();
        }
      }),
      this,
    );
  }

  #transform<GNewValue>(
    onValue: (value: GValue, dispatch: DispatchEmitterResourceValue<GNewValue>) => void,
  ): EmitterResource<GNewValue> {
    let dispatch: DispatchEmitterResourceValue<GNewValue>;

    const listener: Resource = this.listen((value: GValue): void => {
      onValue(value, dispatch);
    });

    const emitter: EmitterResource<GNewValue> = new EmitterResource<GNewValue>(
      (_dispatch: DispatchEmitterResourceValue<GNewValue>): void => {
        dispatch = _dispatch;
      },
    );

    ResourceCloser.closeResourcesWhenAnyCloses([listener, emitter]);

    return emitter;
  }

  map<GNewValue>(mapFnc: MapFunction<GValue, GNewValue>): EmitterResource<GNewValue> {
    return this.#transform(
      (value: GValue, dispatch: DispatchEmitterResourceValue<GNewValue>): void => {
        dispatch(mapFnc(value));
      },
    );
  }

  filter<GNewValue extends GValue>(
    filterFnc: FilterFunctionWithSubType<GValue, GNewValue>,
  ): EmitterResource<GNewValue>;
  filter(filterFnc: FilterFunction<GValue>): EmitterResource<GValue>;
  filter(filterFnc: FilterFunction<GValue>): EmitterResource<GValue> {
    return this.#transform(
      (value: GValue, dispatch: DispatchEmitterResourceValue<GValue>): void => {
        if (filterFnc(value)) {
          dispatch(value);
        }
      },
    );
  }

  mapFilter<GNewValue>(
    mapFilterFnc: MapFilterFunction<GValue, GNewValue>,
  ): EmitterResource<GNewValue> {
    return this.#transform(
      (value: GValue, dispatch: DispatchEmitterResourceValue<GNewValue>): void => {
        const newValue: GNewValue | null = mapFilterFnc(value);
        if (newValue !== null) {
          dispatch(newValue);
        }
      },
    );
  }

  async *toAsyncGenerator({
    bufferSize = Number.POSITIVE_INFINITY,
    windowTime = Number.POSITIVE_INFINITY,
    signal,
  }: EmitterResourceToAsyncIteratorOptions = {}): AsyncGenerator<GValue> {
    bufferSize = Math.max(0, bufferSize);
    windowTime = Math.max(0, windowTime);

    const sharedSignal: AbortSignal = mergeAbortSignals([signal, this.closeSignal]);

    interface PendingValue {
      readonly value: GValue;
      readonly expirationDate: number;
    }

    const values: PendingValue[] = [];
    let pendingRead: PromiseWithResolvers<void> | undefined;

    await using _listenerHook = this.listen((value: GValue): void => {
      if (bufferSize > 0 && windowTime > 0) {
        values.push({
          value,
          expirationDate: Date.now() + windowTime,
        });

        if (values.length > bufferSize) {
          values.shift();
        }
      } else {
        if (pendingRead !== undefined) {
          values.length = 0;
          values.push({
            value,
            expirationDate: Number.POSITIVE_INFINITY,
          });
        }
      }

      if (pendingRead !== undefined) {
        pendingRead.resolve();
        pendingRead = undefined;
      }
    });

    while (true) {
      sharedSignal.throwIfAborted();

      // remove the expired values
      const now: number = Date.now();
      while (values.length > 0 && values[0].expirationDate < now) {
        values.shift();
      }

      if (values.length > 0) {
        yield values.shift()!.value;
      } else {
        pendingRead = Promise.withResolvers<void>();

        const onAbort = (): void => {
          sharedSignal.removeEventListener('abort', onAbort);
          pendingRead!.reject(sharedSignal!.reason);
          pendingRead = undefined;
        };

        sharedSignal.addEventListener('abort', onAbort);

        try {
          await pendingRead.promise;
        } finally {
          sharedSignal.removeEventListener('abort', onAbort);
        }
      }
    }
  }

  [Symbol.asyncIterator](): AsyncGenerator<GValue, void, void> {
    return this.toAsyncGenerator();
  }
}
