import { EmitterResourceTrait } from '../../../../../emitter-resource/__traits.private/emitter-resource.trait.js';
import { MqttPublishPacket } from './mqtt-publish-packet.js';

export interface MqttSubscriptionResourceReceiveTrait {
  readonly receive$: EmitterResourceTrait<MqttPublishPacket>;
}
