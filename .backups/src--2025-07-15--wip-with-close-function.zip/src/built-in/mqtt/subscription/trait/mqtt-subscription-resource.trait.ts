import { ResourceTrait } from '../../../../resource/__traits.private/resource.trait.js';
import { MqttSubscriptionResourceReceiveTrait } from './properties/receive$/mqtt-subscription-resource.receive$.trait.js';

export interface MqttSubscriptionResourceTrait
  extends ResourceTrait,
    MqttSubscriptionResourceReceiveTrait {}
