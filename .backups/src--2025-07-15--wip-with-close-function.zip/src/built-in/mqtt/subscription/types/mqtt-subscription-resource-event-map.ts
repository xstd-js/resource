import { type ResourceEventMap } from '../../../../resource/__traits.private/types/resource-event-map.js';
import { type MqttPublishPacketEvent } from '../../__events.legacy/mqtt-publish-packet-event.js';

export interface MqttSubscriptionResourceEventMap extends ResourceEventMap {
  readonly packet: MqttPublishPacketEvent;
}
