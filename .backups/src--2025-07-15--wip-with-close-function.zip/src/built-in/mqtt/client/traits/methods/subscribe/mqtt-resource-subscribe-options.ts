import { type Abortable } from '@xstd/abortable';

export interface MqttResourceSubscribeOptions extends Abortable {
  readonly qos?: 0 | 1 | 2;
  readonly noLocal?: boolean;
  readonly retainAsPublished?: boolean;
  readonly retainHandling?: 0 | 1 | 2;
}
