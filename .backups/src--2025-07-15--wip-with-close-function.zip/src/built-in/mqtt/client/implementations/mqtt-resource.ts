import { abortify, mergeAbortSignals } from '@xstd/abortable';
import { CompleteError } from '@xstd/custom-error';
import mqtt, { IDisconnectPacket, ISubscriptionGrant, MqttClient } from 'mqtt';
import { OpenResourceOptions } from '../../../../resource/factory/open-resource.js';
import {
  OpenMainResourceOptions,
  SharedResourceFactory,
} from '../../../../resource/factory/shared/shared-resource-factory.js';
import { runConcurrentlyVoidPromises } from '../../../../resource/helpers/run-concurrently-void-promises.js';
import { runSequentiallyVoidPromiseFactories } from '../../../../resource/helpers/run-sequentially-void-promise-factories.js';
import { InitResourceContext, Resource } from '../../../../resource/resource.js';
import { MqttSubscriptionResource } from '../../subscription/implementation/mqtt-subscription-resource.js';
import { MqttResourcePublishOptions } from '../traits/methods/publish/mqtt-resource-publish-options.js';
import { MqttResourceSubscribeOptions } from '../traits/methods/subscribe/mqtt-resource-subscribe-options.js';

export interface MqttResourceOptions extends OpenResourceOptions {
  readonly clientId?: string;
  readonly username?: string;
  readonly password?: string;

  // readonly keepalive?: number;
  // readonly clean?: boolean;
}

interface ActiveSubscription {
  readonly qos: 0 | 1 | 2;
  readonly noLocal: boolean;
  readonly retainAsPublished: boolean;
  readonly retainHandling: 0 | 1 | 2;

  readonly shared: SharedResourceFactory<Resource<void>, MqttSubscriptionResource>;
}

export class MqttResource extends Resource<MqttResourceRef> {
  static async open(
    url: string | URL,
    { signal, ...options }: MqttResourceOptions = {},
  ): Promise<MqttResource> {
    signal?.throwIfAborted();

    const client: MqttClient = await mqtt.connectAsync(url.toString(), {
      ...options,
      reconnectPeriod: 0,
      autoUseTopicAlias: true,
      autoAssignTopicAlias: true,
    });

    // TODO
    client.setMaxListeners(20);
    // client.setMaxListeners(50);

    if (signal?.aborted) {
      await client.endAsync();
      throw signal.reason;
    }

    return new MqttResource(client);
  }

  private constructor(client: MqttClient) {
    super((ctx: InitResourceContext): MqttResourceRef => {
      return new MqttResourceRef(ctx, client);
    });
  }
}

export class MqttResourceRef {
  readonly #ctx: InitResourceContext;
  readonly #client: MqttClient;
  readonly #activeSubscriptions: Map<string /* topic */, ActiveSubscription>;
  readonly #sharedSubscriptions: Set<Resource<void>>;

  constructor(ctx: InitResourceContext, client: MqttClient) {
    if (!client.connected) {
      throw new Error('MqttClient not open.');
    }

    this.#ctx = ctx;
    this.#client = client;
    this.#activeSubscriptions = new Map<string, ActiveSubscription>();
    this.#sharedSubscriptions = new Set<Resource<void>>();

    const onClientDisconnect = (packet: IDisconnectPacket): void => {
      if (packet.reasonCode === undefined || packet.reasonCode === 0x00) {
        void this.#ctx.close(new CompleteError());
      } else {
        void this.#ctx.close(new Error('Disconnected', { cause: packet }));
      }
    };

    const onClientError = (error: unknown): void => {
      void this.#ctx.close(error);
    };

    const onClientEnd = (): void => {
      void this.#ctx.close(new Error('Client ended'));
    };

    client.on('disconnect', onClientDisconnect);
    client.on('error', onClientError);
    client.on('end', onClientEnd);

    this.#ctx.addTeardown((reason: unknown): Promise<void> => {
      return runSequentiallyVoidPromiseFactories([
        (): void => {
          client.off('disconnect', onClientDisconnect);
          client.off('error', onClientError);
          client.off('end', onClientEnd);
        },
        (): Promise<void> => {
          return runConcurrentlyVoidPromises(
            this.#sharedSubscriptions
              .values()
              .map((sharedSubscription: Resource<void>): Promise<void> => {
                return sharedSubscription.close(reason);
              }),
          );
        },
        (): Promise<void> => {
          return client.endAsync();
        },
      ]);
    });
  }

  publish(
    topic: string,
    payload: string | Uint8Array,
    { signal, ...options }: MqttResourcePublishOptions = {},
  ): Promise<void> {
    return this.#ctx.runTask(async (): Promise<void> => {
      await abortify(this.#client.publishAsync(topic, payload as any, options), {
        signal: mergeAbortSignals([signal, this.#ctx.signal]),
      });
    });
  }

  async subscribe(
    topic: string,
    {
      qos = 0,
      noLocal = false,
      retainAsPublished = false,
      retainHandling = 0,
      signal,
    }: MqttResourceSubscribeOptions = {},
  ): Promise<MqttSubscriptionResource> {
    let activeSubscription: ActiveSubscription | undefined = this.#activeSubscriptions.get(topic);

    if (activeSubscription === undefined) {
      activeSubscription = {
        qos,
        noLocal,
        retainAsPublished,
        retainHandling,

        // TODO continue here
        shared: new SharedResourceFactory<Resource<void>, MqttSubscriptionResource>({
          shared: async ({ signal }: OpenMainResourceOptions): Promise<Resource<void>> => {
            try {
              const [granted]: ISubscriptionGrant[] = await this.#client.subscribeAsync(topic, {
                qos,
                nl: noLocal,
                rap: retainAsPublished,
                rh: retainHandling,
              });

              if (signal.aborted) {
                await this.#client.unsubscribeAsync(topic);
                throw signal.reason;
              }

              if (qos !== undefined && granted.qos < qos) {
                await this.#client.unsubscribeAsync(topic);
                throw new Error(
                  `Cannot subscribe to "${topic}" with a qos of ${qos}. Granted ${granted.qos}.`,
                );
              }

              const sharedResource = new Resource<void>((ctx: InitResourceContext): void => {
                ctx.addTeardown(async (): Promise<void> => {
                  try {
                    await this.#client.unsubscribeAsync(topic);
                  } finally {
                    this.#activeSubscriptions.delete(topic);
                    this.#sharedSubscriptions.delete(sharedResource);
                  }
                });
              });

              this.#sharedSubscriptions.add(sharedResource);

              return sharedResource;
            } catch (error: unknown) {
              this.#activeSubscriptions.delete(topic);
              throw error;
            }
          },
          child: (): MqttSubscriptionResource => {
            return new MqttSubscriptionResource(this.#client, topic);
          },
        }),
      };

      this.#activeSubscriptions.set(topic, activeSubscription);
    } else {
      if (
        qos !== activeSubscription.qos ||
        noLocal !== activeSubscription.noLocal ||
        retainAsPublished !== activeSubscription.retainAsPublished ||
        retainHandling !== activeSubscription.retainHandling
      ) {
        throw new Error(
          `Subscription "${topic}" with options ${JSON.stringify({ qos, noLocal, retainAsPublished, retainHandling })} is already locked. Use the same options, or close the previous one.`,
        );
      }
    }

    return await activeSubscription.shared.open({ signal });
  }
}
