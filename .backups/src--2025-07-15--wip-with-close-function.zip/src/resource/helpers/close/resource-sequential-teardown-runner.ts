import { type Abortable } from '@xstd/abortable';
import { type OnResourceClose } from '../../resource.js';
import { ResourceCloser } from './resource-closer.js';

export class ResourceSequentialTeardownRunner extends ResourceCloser {
  #closed: boolean;
  readonly #teardowns: OnResourceClose[];

  constructor() {
    super(async (reason?: unknown): Promise<void> => {
      this.#throwIfClosed();

      this.#closed = true;

      let isErrored: boolean = false;
      let error: unknown;

      for (let i: number = this.#teardowns.length - 1; i >= 0; i--) {
        try {
          await this.#teardowns[i](reason);
        } catch (closeError: unknown) {
          if (isErrored) {
            error = new SuppressedError(closeError, error);
          } else {
            isErrored = true;
            error = closeError;
          }
        }
      }

      if (isErrored) {
        throw error;
      }
    });
    this.#closed = false;
    this.#teardowns = [];
  }

  #throwIfClosed(): void {
    if (this.#closed) {
      throw new Error('Resource closed.');
    }
  }

  addTeardown(teardown: OnResourceClose, { signal }: Abortable = {}): void {
    if (signal?.aborted) {
      return;
    }

    this.#throwIfClosed();
    this.#teardowns.push(teardown);

    signal?.addEventListener(
      'abort',
      (): void => {
        if (!this.#closed) {
          this.#teardowns.splice(this.#teardowns.indexOf(teardown), 1);
        }
      },
      {
        once: true,
      },
    );
  }
}
