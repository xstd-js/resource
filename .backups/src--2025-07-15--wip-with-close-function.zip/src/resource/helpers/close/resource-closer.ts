import { type CloseResource, type Resource } from '../../resource.js';

export class ResourceCloser {
  readonly #close: CloseResource;

  static closeChildResourceWhenParentCloses<GChild extends Resource>(
    child: GChild,
    parent: Resource,
  ): GChild {
    if (child !== parent && !child.closeSignal.aborted) {
      if (parent.closeSignal.aborted) {
        void child.close(parent.closeSignal.reason);
      } else {
        parent.closeSignal.addEventListener(
          'abort',
          (): void => {
            void child.close(parent.closeSignal.reason);
          },
          {
            signal: child.closeSignal,
          },
        );
      }
    }

    return child;
  }

  static closeResourcesWhenAnyCloses(resources: Iterable<Resource>): void {
    for (const a of resources) {
      for (const b of resources) {
        this.closeChildResourceWhenParentCloses(a, b);
      }
    }
  }

  constructor(close: CloseResource) {
    this.#close = close;
  }

  get close(): CloseResource {
    return this.#close;
  }
}
