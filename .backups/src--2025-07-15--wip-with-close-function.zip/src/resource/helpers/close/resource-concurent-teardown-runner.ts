import { type Abortable } from '@xstd/abortable';
import { type OnResourceClose } from '../../resource.js';
import { ResourceCloser } from './resource-closer.js';

export class ResourceConcurrentTeardownRunner extends ResourceCloser {
  #closed: boolean;
  readonly #teardowns: OnResourceClose[];

  constructor() {
    super(async (reason?: unknown): Promise<void> => {
      this.#throwIfClosed();

      this.#closed = true;

      const errors: readonly PromiseRejectedResult[] = (
        await Promise.allSettled(
          this.#teardowns.map((teardown: OnResourceClose): Promise<any> => {
            return Promise.try(teardown, reason);
          }),
        )
      ).filter((result: PromiseSettledResult<void>): result is PromiseRejectedResult => {
        return result.status === 'rejected';
      });

      if (errors.length === 1) {
        throw errors[0];
      } else if (errors.length > 1) {
        throw new AggregateError(errors);
      }
    });
    this.#closed = false;
    this.#teardowns = [];
  }

  #throwIfClosed(): void {
    if (this.#closed) {
      throw new Error('Resource closed.');
    }
  }

  addTeardown(teardown: OnResourceClose, { signal }: Abortable = {}): void {
    if (signal?.aborted) {
      return;
    }

    this.#throwIfClosed();
    this.#teardowns.push(teardown);

    signal?.addEventListener(
      'abort',
      (): void => {
        if (!this.#closed) {
          this.#teardowns.splice(this.#teardowns.indexOf(teardown), 1);
        }
      },
      {
        once: true,
      },
    );
  }
}
