import { ResourceCloser } from './resource-closer.js';

export interface ResourceTask<GReturn> {
  (): GReturn;
}

export interface AsyncResourceTask<GReturn> {
  (signal: AbortSignal): PromiseLike<GReturn> | GReturn;
}

export class ResourceTaskRunner extends ResourceCloser {
  readonly #controller: AbortController;
  readonly #pendingTasks: Set<Promise<unknown>>;

  constructor() {
    super(async (reason?: unknown): Promise<void> => {
      this.#throwIfClosed();

      this.#controller.abort(reason);

      await Promise.allSettled(this.#pendingTasks.values());
    });
    this.#controller = new AbortController();
    this.#pendingTasks = new Set<Promise<unknown>>();
  }

  #throwIfClosed(): void {
    if (this.#controller.signal.aborted) {
      throw new Error('Resource closed.');
    }
  }

  runTask<GReturn>(task: ResourceTask<GReturn>): GReturn {
    this.#throwIfClosed();
    return task();
  }

  async runAsyncTask<GReturn>(
    task: AsyncResourceTask<GReturn> | PromiseLike<GReturn>,
  ): Promise<GReturn> {
    this.#throwIfClosed();

    const taskPromise: Promise<GReturn> =
      typeof task === 'function' ?
        Promise.try(task, this.#controller.signal)
      : Promise.resolve(task);

    this.#pendingTasks.add(taskPromise);

    try {
      return await taskPromise;
    } finally {
      this.#pendingTasks.delete(taskPromise);
    }
  }
}
