import { type Abortable } from '@xstd/abortable';
import { Resource } from '../resource.js';

export interface OpenResource<GResource extends Resource> {
  (options?: OpenResourceOptions): PromiseLike<GResource> | GResource;
}

export interface OpenResourceOptions extends Abortable {}
