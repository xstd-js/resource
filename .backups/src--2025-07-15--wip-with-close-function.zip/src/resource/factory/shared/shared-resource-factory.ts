import { type Abortable, abortify } from '@xstd/abortable';
import { noop } from '@xstd/noop';
import { Resource } from '../../resource.js';

/*---*/

export interface OpenSharedResource<GSharedResource extends Resource<any>> {
  (options: OpenSharedResourceOptions): PromiseLike<GSharedResource> | GSharedResource;
}

export interface OpenSharedResourceOptions extends Required<Abortable> {
  readonly close: CloseResource;
}

/*---*/

export interface CreateChildResource<
  GSharedResource extends Resource<any>,
  GChildResource extends Resource<any>,
> {
  (
    options: CreateChildResourceOptions<GSharedResource>,
  ): PromiseLike<GChildResource> | GChildResource;
}

export interface CreateChildResourceOptions<GSharedResource extends Resource<any>>
  extends Abortable {
  readonly sharedResource: GSharedResource;
  readonly close: CloseResource;
}

/*---*/

export interface SharedResourceFactoryOptions<
  GSharedResource extends Resource<any>,
  GChildResource extends Resource<any>,
> {
  readonly shared: OpenSharedResource<GSharedResource>;
  readonly child: CreateChildResource<GSharedResource, GChildResource>;
}

export class SharedResourceFactory<
  GSharedResource extends Resource<any>,
  GChildResource extends Resource<any>,
> {
  readonly #shared: OpenSharedResource<GSharedResource>;
  readonly #child: CreateChildResource<GSharedResource, GChildResource>;

  #usageCount: number;
  readonly #childResources: Set<GChildResource>;
  #openController: AbortController | undefined;
  #openPromise: Promise<GSharedResource> | undefined;
  #closePromise: Promise<void> | undefined;

  constructor({ shared, child }: SharedResourceFactoryOptions<GSharedResource, GChildResource>) {
    this.#shared = shared;
    this.#child = child;
    this.#usageCount = 0;
    this.#childResources = new Set<GChildResource>();
  }

  async open(options?: Abortable): Promise<GChildResource> {
    return this.#open(options);
  }

  async #open(options?: Abortable): Promise<GChildResource> {
    options?.signal?.throwIfAborted();

    // await previous close
    if (this.#closePromise !== undefined) {
      await abortify(this.#closePromise.catch(noop), options);
    }

    this.#usageCount++;

    // open the shared `sharedResource`
    if (this.#openPromise === undefined) {
      const openController: AbortController = new AbortController();
      this.#openController = openController;

      this.#openPromise = Promise.try(() =>
        this.#shared({
          signal: openController.signal,
          close: (reason: unknown): Promise<void> => {
            return parallelCloseResources(this.#childResources, reason);
          },
        }),
      ).finally((): void => {
        openController.abort();
      });
    }

    // acquire for the `sharedResource`
    let sharedResource: GSharedResource;
    try {
      sharedResource = await abortify(this.#openPromise!, options);
    } catch (error: unknown) {
      // failed to acquire for the `sharedResource`
      this.#usageCount--;

      if (this.#usageCount === 0) {
        this.#openController!.abort();
        this.#openController = undefined;
        this.#openPromise = undefined;
      }

      throw error;
    }

    // acquire for the `childResource`
    let childResource: GChildResource;
    try {
      let closed: boolean = false;
      childResource = await this.#child({
        ...options,
        sharedResource,
        close: async (reason: unknown): Promise<void> => {
          if (closed) {
            throw new Error('Already closed.');
          } else {
            closed = true;

            // close the `childResource`
            this.#usageCount--;
            this.#childResources.delete(childResource);

            if (this.#usageCount === 0) {
              this.#openPromise = undefined;

              if (!sharedResource.closeSignal.aborted) {
                // close `sharedResource` if it IS NOT already closed or closing
                await (this.#closePromise = sharedResource.close(reason).finally((): void => {
                  this.#closePromise = undefined;
                }));
              }
            }
          }
        },
      });
    } catch (error: unknown) {
      // failed to acquire for the `childResource`
      this.#usageCount--;

      if (this.#usageCount === 0) {
        this.#openPromise = undefined;
      }

      throw error;
    }

    this.#childResources.add(childResource);

    return childResource;
  }
}
