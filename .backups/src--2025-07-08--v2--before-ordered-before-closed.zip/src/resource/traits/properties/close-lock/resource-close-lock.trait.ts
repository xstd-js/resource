import { type Lockable } from '@xstd/lock';

export interface ResourceCloseLockTrait {
  /**
   * A "lock" on `Resource.close`.
   */
  readonly closeLock: Lockable;
}
