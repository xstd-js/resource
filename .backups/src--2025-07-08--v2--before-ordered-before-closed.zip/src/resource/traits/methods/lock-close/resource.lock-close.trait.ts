export interface ResourceLockCloseTrait {
  lockClose(): UnlockResourceClose;
}

export interface UnlockResourceClose {
  <GReturn>(context: UnlockResourceCloseContext<GReturn>): GReturn;
}

export interface UnlockResourceCloseContext<GReturn> {
  (): GReturn;
}
