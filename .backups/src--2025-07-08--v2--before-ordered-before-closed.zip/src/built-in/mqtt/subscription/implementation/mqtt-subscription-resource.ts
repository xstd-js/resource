import { IPublishPacket, MqttClient } from 'mqtt';
import { Resource } from '../../../../resource/implementations/resource.js';
import { EmitterResource } from '../../../emitter-resource/implementations/emitter-resource.js';
import { EmitterResourceTrait } from '../../../emitter-resource/traits/emitter-resource.trait.js';
import { EmitterResourceWithDispatcher } from '../../../emitter-resource/traits/static-methods/with-dispatcher/emitter-resource-with-dispatcher.js';
import { MqttTopic } from '../../topic/mqtt-topic.js';
import { MqttSubscriptionResourceTrait } from '../trait/mqtt-subscription-resource.trait.js';
import { MqttPublishPacket } from '../trait/properties/receive$/mqtt-publish-packet.js';

export class MqttSubscriptionResource extends Resource implements MqttSubscriptionResourceTrait {
  readonly #receive$: EmitterResourceWithDispatcher<MqttPublishPacket>;

  constructor(client: MqttClient, topic: string) {
    const topicMatcher: MqttTopic = new MqttTopic(topic);

    const onClientMessage = (topic: string, payload: Buffer, _packet: IPublishPacket): void => {
      if (topicMatcher.matches(topic)) {
        this.#receive$.dispatch({
          topic,
          payload,
        });
      }
    };

    client.on('message', onClientMessage);

    super();

    this.#receive$ = EmitterResource.withDispatcher<MqttPublishPacket>();

    this.fork(this.#receive$.emitter, {
      mode: 'hard',
    });

    this.beforeClosed((): PromiseLike<void> | void => {
      client.off('message', onClientMessage);
    });
  }

  get receive$(): EmitterResourceTrait<MqttPublishPacket> {
    return this.#receive$.emitter;
  }
}
