import { Abortable } from '@xstd/abortable';
import { Lockable } from '@xstd/lock';
import { type ResourceRunTaskFunction } from '../traits/methods/run-task/resource-run-task.function.js';
import { type ResourceTrait } from '../traits/resource.trait.js';
import { type CloseResource } from '../traits/types/close-resource.js';

export class Resource implements ResourceTrait {
  static closeTogether(
    resourceA: ResourceTrait,
    resourceB: ResourceTrait,
    options?: Abortable,
  ): void {
    resourceA.closesWith(resourceB, options);
    resourceB.closesWith(resourceA, options);
  }

  // lock
  readonly #closeLock: Lockable;

  // close
  readonly #close: CloseResource | undefined;
  readonly #controller: AbortController;
  readonly #closedPromise: PromiseWithResolvers<unknown>;

  // tasks
  readonly #pendingTasks: Set<Promise<any>>;

  constructor(close?: CloseResource) {
    this.#closeLock = new Lockable();

    this.#close = close;
    this.#controller = new AbortController();
    this.#closedPromise = Promise.withResolvers<unknown>();

    this.#pendingTasks = new Set<Promise<any>>();
  }

  /* LOCK */

  get closeLock(): Lockable {
    return this.#closeLock;
  }

  /* CLOSE */

  #throwIfClosed(): void {
    if (this.#controller.signal.aborted) {
      throw new Error('Resource closed.');
    }
  }

  /**
   * A Promise resolved when the `Resource` is closed.
   */
  get closed(): Promise<unknown> {
    return this.#closedPromise.promise;
  }

  /**
   * An `AbortSignal` aborted when the `Resource` is closing.
   */
  get closeSignal(): AbortSignal {
    return this.#controller.signal;
  }

  /**
   * Closes the `Resource`.
   */
  async close(reason?: unknown): Promise<void> {
    this.#closeLock.throwIfLocked();

    if (!this.#controller.signal.aborted) {
      this.#controller.abort(reason);

      this.#closedPromise.resolve(
        Promise.allSettled(this.#pendingTasks.values()).then((): PromiseLike<void> | void => {
          return this.#close?.(reason);
        }),
      );
    }

    await this.#closedPromise.promise!;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }

  closesWith(closer: ResourceTrait, { signal }: Abortable = {}): void {
    if (!signal?.aborted) {
      this.#throwIfClosed();

      const close = (): void => {
        void this.close(closer.closeSignal.reason);
      };

      if (closer.closeSignal.aborted) {
        close();
      } else {
        closer.closeSignal.addEventListener('abort', close, {
          signal:
            signal === undefined ? this.closeSignal : AbortSignal.any([this.closeSignal, signal]),
        });
      }
    }
  }

  /* TASKS */

  /**
   * Runs and appends a _task_ linked to this `Resource`.
   */
  async runTask<GReturn>(
    taskFnc: ResourceRunTaskFunction<GReturn> | Promise<GReturn>,
  ): Promise<GReturn> {
    this.#throwIfClosed();

    if (typeof taskFnc === 'function') {
      taskFnc = Promise.try<GReturn, [AbortSignal]>(taskFnc, this.#controller.signal);
    }

    if (this.#pendingTasks.has(taskFnc)) {
      throw new Error('Task already running.');
    }

    this.#pendingTasks.add(taskFnc);

    try {
      return await taskFnc;
    } finally {
      this.#pendingTasks.delete(taskFnc);
    }
  }
}
