import { type CloseResource } from '../traits/types/close-resource.js';

// export function sequentialCloseResourceFunctions(
//   closeFunctions: Iterable<CloseResource>,
// ): CloseResource {
//   return async (reason: unknown): Promise<void> => {
//     let isErrored: boolean = false;
//     let sharedError: unknown;
//
//     for (const closeFunction of closeFunctions) {
//       try {
//         await closeFunction(reason);
//       } catch (error: unknown) {
//         if (isErrored) {
//           throw new SuppressedError(error, sharedError);
//         } else {
//           isErrored = true;
//           sharedError = error;
//         }
//       }
//     }
//
//     if (isErrored) {
//       throw sharedError;
//     }
//   };
// }

export async function sequentialCloseResourceFunctions(
  closeFunctions: Iterable<CloseResource>,
  reason: unknown,
): Promise<void> {
  let isErrored: boolean = false;
  let sharedError: unknown;

  for (const closeFunction of closeFunctions) {
    try {
      await closeFunction(reason);
    } catch (error: unknown) {
      if (isErrored) {
        throw new SuppressedError(error, sharedError);
      } else {
        isErrored = true;
        sharedError = error;
      }
    }
  }

  if (isErrored) {
    throw sharedError;
  }
}
