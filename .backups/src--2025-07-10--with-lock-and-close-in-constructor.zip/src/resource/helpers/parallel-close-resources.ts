import { type ResourceTrait } from '../traits/resource.trait.js';

// export function parallelCloseResources(
//   resources: Iterable<ResourceTrait>,
//   reason: unknown,
// ): Promise<void> {
//   return parallelCloseResourceFunctions(
//     Array.from(resources, (resource: ResourceTrait): CloseResource => {
//       return resource.close.bind(resource);
//     }),
//     reason,
//   );
// }

export async function parallelCloseResources(
  resources: Iterable<ResourceTrait>,
  reason: unknown,
): Promise<void> {
  const results: readonly PromiseSettledResult<void>[] = await Promise.allSettled(
    Array.from(resources, (resource: ResourceTrait): Promise<void> => {
      return resource.close(reason);
    }),
  );

  const errors: readonly PromiseRejectedResult[] = results.filter(
    (result: PromiseSettledResult<void>): result is PromiseRejectedResult => {
      return result.status === 'rejected';
    },
  );

  if (errors.length === 1) {
    throw errors[0];
  } else if (errors.length > 1) {
    throw new AggregateError(errors);
  }
}
