import { type ResourceTrait } from '../../../../resource/traits/resource.trait.js';
import { type MqttResourcePublishTrait } from './methods/publish/mqtt-resource.publish.trait.js';
import { type MqttResourceSubscribeTrait } from './methods/subscribe/mqtt-resource.subscribe.trait.js';

export interface MqttResourceTrait
  extends ResourceTrait,
    MqttResourcePublishTrait,
    MqttResourceSubscribeTrait {}
