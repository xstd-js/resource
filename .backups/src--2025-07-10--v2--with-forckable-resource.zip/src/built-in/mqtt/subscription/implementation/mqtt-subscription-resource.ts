import { Locked } from '@xstd/lock';
import { IPublishPacket, MqttClient } from 'mqtt';
import { Resource } from '../../../../resource/implementations/resource.js';
import { EmitterResource } from '../../../emitter-resource/implementations/emitter-resource.js';
import { EmitterResourceDispatchFunction } from '../../../emitter-resource/implementations/types/emitter-resource-dispatch-function.js';
import { EmitterResourceTrait } from '../../../emitter-resource/traits/emitter-resource.trait.js';
import { MqttTopic } from '../../topic/mqtt-topic.js';
import { MqttSubscriptionResourceTrait } from '../trait/mqtt-subscription-resource.trait.js';
import { MqttPublishPacket } from '../trait/properties/receive$/mqtt-publish-packet.js';

export class MqttSubscriptionResource extends Resource implements MqttSubscriptionResourceTrait {
  readonly #receive$: EmitterResourceTrait<MqttPublishPacket>;
  readonly #$receive: EmitterResourceDispatchFunction<MqttPublishPacket>;

  constructor(client: MqttClient, topic: string) {
    const topicMatcher: MqttTopic = new MqttTopic(topic);

    const onClientMessage = (topic: string, payload: Buffer, _packet: IPublishPacket): void => {
      if (topicMatcher.matches(topic)) {
        this.#$receive({
          topic,
          payload,
        });
      }
    };

    client.on('message', onClientMessage);

    const { emitter: receive$, dispatch: $receive } =
      EmitterResource.withDispatcher<MqttPublishPacket>();

    const lock: Locked = receive$.closeLock.lock();

    super(async (reason: unknown): Promise<void> => {
      client.off('message', onClientMessage);

      await lock.unlock((): Promise<void> => receive$.close(reason));
    });

    this.#receive$ = this.fork(receive$, {
      mode: 'hard',
    });
    this.#$receive = $receive;
  }

  get receive$(): EmitterResourceTrait<MqttPublishPacket> {
    return this.#receive$;
  }
}
