import { type EmitterResourceTrait } from '../../../../emitter-resource/traits/emitter-resource.trait.js';
import { type WebSocketDownValue } from '../../types/web-socket-down-value.js';

export interface WebSocketResourceReceiveTrait {
  /**
   * An emitter receiving the payloads.
   */
  readonly receive$: EmitterResourceTrait<WebSocketDownValue>;
}
