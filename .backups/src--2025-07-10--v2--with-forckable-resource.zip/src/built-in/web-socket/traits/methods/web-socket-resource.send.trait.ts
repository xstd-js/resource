import { type WebSocketUpValue } from '../types/web-socket-up-value.js';

export interface WebSocketResourceTraitSend {
  /**
   * Sends a payload.
   */
  send(payload: WebSocketUpValue): Promise<void>;
}
