import { type ResourceTrait } from '../../../resource/traits/resource.trait.js';
import { type WebSocketResourceTraitSend } from './methods/web-socket-resource.send.trait.js';
import { type WebSocketResourceReceiveTrait } from './properties/receive$/web-socket-resource.receive$.trait.js';

export interface WebSocketResourceTrait
  extends ResourceTrait,
    WebSocketResourceTraitSend,
    WebSocketResourceReceiveTrait {}
