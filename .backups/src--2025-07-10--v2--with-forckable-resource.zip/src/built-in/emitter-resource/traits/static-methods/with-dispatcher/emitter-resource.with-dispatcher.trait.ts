import { type EmitterResourceWithDispatcher } from './emitter-resource-with-dispatcher.js';

export interface EmitterResourceWithDispatcherTrait {
  withDispatcher<GValue>(): EmitterResourceWithDispatcher<GValue>;
}
