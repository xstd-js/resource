import { type EmitterResourceDispatchFunction } from '../../../implementations/types/emitter-resource-dispatch-function.js';
import { type EmitterResourceTrait } from '../../emitter-resource.trait.js';

export interface EmitterResourceWithDispatcher<GValue> {
  readonly emitter: EmitterResourceTrait<GValue>;
  readonly dispatch: EmitterResourceDispatchFunction<GValue>;
}
