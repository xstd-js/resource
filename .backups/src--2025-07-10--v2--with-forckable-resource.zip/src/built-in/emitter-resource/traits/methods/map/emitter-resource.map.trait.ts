import { type MapFunction } from '@xstd/functional';
import { type EmitterResourceTrait } from '../../emitter-resource.trait.js';

export interface EmitterResourceMapTrait<GValue> {
  map<GNewValue>(mapFnc: MapFunction<GValue, GNewValue>): EmitterResourceTrait<GNewValue>;
}
