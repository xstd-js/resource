/**
 * A callback receiving a value.
 */
export interface EmitterResourceListener<GValue> {
  (value: GValue): void;
}
