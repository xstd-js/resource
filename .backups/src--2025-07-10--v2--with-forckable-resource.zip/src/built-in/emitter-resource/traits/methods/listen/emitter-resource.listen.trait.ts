import { type ResourceTrait } from '../../../../../resource/traits/resource.trait.js';
import { type EmitterResourceListener } from './emitter-resource-listener.js';

export interface EmitterResourceListenTrait<GValue> {
  /**
   * Listens to the values sent by the `EmitterResource`.
   */
  listen(listener: EmitterResourceListener<GValue>): ResourceTrait;
}
