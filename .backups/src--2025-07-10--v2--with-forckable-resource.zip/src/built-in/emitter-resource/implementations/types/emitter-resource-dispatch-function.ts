/**
 * A function used to dispatch values to the `EmitterResource`.
 */
export interface EmitterResourceDispatchFunction<GValue> {
  (value: GValue): void;
}
