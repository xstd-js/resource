import { type ResourceTrait } from '../traits/resource.trait.js';

/**
 * @deprecated
 * @param resource
 * @param requiredResources
 */
export function resourceRequires(
  resource: ResourceTrait,
  requiredResources: Iterable<ResourceTrait>,
): void {
  if (resource.closeSignal.aborted) {
    throw new Error('Resource closed.');
  }

  for (const requiredResource of requiredResources) {
    if (requiredResource.closeSignal.aborted) {
      throw new Error('Required resource closed.');
    }

    requiredResource.closeSignal.addEventListener(
      'abort',
      (): void => {
        void resource.close(requiredResource.closeSignal.reason);
      },
      {
        signal: resource.closeSignal,
      },
    );
  }
}
