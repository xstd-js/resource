import { type Abortable } from '@xstd/abortable';
import { type Resource } from '../implementations/resource.js';

export interface OpenResource<GResource extends Resource> {
  (options?: OpenResourceOptions): PromiseLike<GResource> | GResource;
}

export interface OpenResourceOptions extends Abortable {}
