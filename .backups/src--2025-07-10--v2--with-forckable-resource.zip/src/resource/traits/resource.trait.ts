import { type ResourceCloseTrait } from './methods/close/resource.close.trait.js';
import { type ResourceClosesWithTrait } from './methods/closes-with/resource.closes-with.trait.js';
import { type ResourceRunTaskTrait } from './methods/run-task/resource.run-task.trait.js';
import { type ResourceCloseLockTrait } from './properties/close-lock/resource-close-lock.trait.js';
import { type ResourceCloseSignalTrait } from './properties/close-signal/resource-close-signal.trait.js';
import { type ResourceClosedTrait } from './properties/closed/resource.closed.trait.js';

export interface ResourceTrait
  extends ResourceCloseLockTrait,
    ResourceClosedTrait,
    ResourceCloseSignalTrait,
    ResourceCloseTrait,
    ResourceClosesWithTrait,
    AsyncDisposable,
    ResourceRunTaskTrait {}
