export interface CloseResource {
  (reason: unknown): PromiseLike<void> | void;
}
