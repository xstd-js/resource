import { type Lockable } from '@xstd/lock';

export interface ResourceCloseLockTrait {
  /**
   * A `Lock` on the `close` method.
   */
  readonly closeLock: Lockable;
}
