export interface ResourceClosedTrait {
  /**
   * A Promise resolved when the `Resource` is closed.
   */
  readonly closed: Promise<unknown>;
}
