export interface ResourceCloseSignalTrait {
  /**
   * An `AbortSignal` aborted when the `Resource` is closing.
   */
  readonly closeSignal: AbortSignal;
}
