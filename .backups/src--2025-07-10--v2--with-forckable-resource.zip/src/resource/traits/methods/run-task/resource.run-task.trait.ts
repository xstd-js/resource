import { type ResourceRunTaskFunction } from './resource-run-task.function.js';

export interface ResourceRunTaskTrait {
  /**
   * Runs and appends a _task_ linked to this `Resource`.
   */
  runTask<GReturn>(taskFnc: ResourceRunTaskFunction<GReturn> | Promise<GReturn>): Promise<GReturn>;
}
