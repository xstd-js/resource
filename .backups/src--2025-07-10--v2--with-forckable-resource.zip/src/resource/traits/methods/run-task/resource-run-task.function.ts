export interface ResourceRunTaskFunction<GReturn> {
  (signal: AbortSignal): PromiseLike<GReturn> | GReturn;
}
