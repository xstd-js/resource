import { type Abortable } from '@xstd/abortable';
import { type ResourceTrait } from '../../resource.trait.js';

export interface ResourceRequiresTrait {
  requires(requiredResource: ResourceTrait, options?: Abortable): void;
}

/*
requires(requiredResource: ResourceTrait, options?: Abortable): void {
    this.#throwIfClosed();

    if (requiredResource.closeSignal.aborted) {
      throw new Error('Required resource closed.');
    }

    requiredResource.closeSignal.addEventListener(
      'abort',
      (): void => {
        void this.close(requiredResource.closeSignal.reason);
      },
      {
        signal: this.closeSignal,
      },
    );
  }
 */
