import { type Abortable } from '@xstd/abortable';
import { type ResourceTrait } from '../../resource.trait.js';

export interface ResourceClosesWithTrait {
  closesWith(closer: ResourceTrait, options?: Abortable): void;
}
