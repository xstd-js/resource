export interface ResourceCloseTrait {
  /**
   * Closes the `Resource`.
   */
  close(reason?: unknown): Promise<void>;
}
