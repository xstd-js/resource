import { type ResourceTrait } from '../../resource.trait.js';

export interface ResourceForkTrait {
  /**
   * Forks a `Resource`.
   */
  fork<GResource extends ResourceTrait>(forked: GResource): GResource;
}
