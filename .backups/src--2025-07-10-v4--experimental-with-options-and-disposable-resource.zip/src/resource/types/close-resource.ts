export interface OnCloseResource {
  (reason: unknown): PromiseLike<void> | void;
}

export interface CloseResource {
  (reason: unknown): Promise<void>;
}
