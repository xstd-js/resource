import { Resource, type ResourceOptions } from './resource.js';

export interface DisposableResourceOptions extends Omit<ResourceOptions, 'signal'> {}

export class DisposableResource extends Resource implements AsyncDisposable {
  readonly #controller: AbortController;

  constructor(options: DisposableResourceOptions) {
    const controller: AbortController = new AbortController();

    super({
      ...options,
      signal: controller.signal,
    });

    this.#controller = new AbortController();
  }

  /**
   * Closes the `Resource`.
   */
  async close(reason?: unknown): Promise<void> {
    this.#controller.abort(reason);
    await this.closed;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }
}
