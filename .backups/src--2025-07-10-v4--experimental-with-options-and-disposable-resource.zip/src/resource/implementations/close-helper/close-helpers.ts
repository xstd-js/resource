import { Abortable, type AbortablePromiseFactory } from '@xstd/abortable';
import { OnCloseResource } from '../../types/close-resource.js';
import { ResourceOptions } from '../resource.js';
/*--------*/

export interface ResourceOptionsWithRunTask extends ResourceOptions {
  readonly runTask: RunTask;
}

export interface RunTask {
  <GReturn>(task: AbortablePromiseFactory<GReturn> | Promise<GReturn>): Promise<GReturn>;
}

export function resourceOptionsWithRunTask({
  close,
  signal,
}: ResourceOptions): ResourceOptionsWithRunTask {
  const pendingTasks: Set<Promise<unknown>> = new Set<Promise<unknown>>();

  return {
    runTask: async <GReturn>(
      task: AbortablePromiseFactory<GReturn> | Promise<GReturn>,
    ): Promise<GReturn> => {
      if (signal) {
        throw new Error('Resource closed.');
      }

      if (typeof task === 'function') {
        task = Promise.try<GReturn, [AbortSignal]>(task, signal);
      }

      if (pendingTasks.has(task)) {
        throw new Error('Task already running.');
      }

      pendingTasks.add(task);

      try {
        return await task;
      } finally {
        pendingTasks.delete(task);
      }
    },
    close: async (reason: unknown): Promise<void> => {
      try {
        await Promise.allSettled(pendingTasks.values());
      } catch (pendingTasksError: unknown) {
        try {
          await close(reason);
        } catch (closeError: unknown) {
          throw new SuppressedError(closeError, pendingTasksError);
        }

        throw pendingTasksError;
      }

      await close(reason);
    },
    signal,
  };
}

/*--------*/

export interface ResourceOptionsWithBeforeClosed extends ResourceOptions {
  readonly beforeClosed: BeforeClosed;
}

export interface BeforeClosed {
  (task: OnCloseResource, options?: Abortable): void;
}

export function resourceOptionsWithBeforeClosed(
  mode: 'parallel' | 'sequential',
  { close, signal }: ResourceOptions,
): ResourceOptionsWithBeforeClosed {
  const beforeClosedTasks: Set<OnCloseResource> = new Set<OnCloseResource>();

  return {
    beforeClosed: (task: OnCloseResource, { signal: beforeClosedSignal }: Abortable = {}): void => {
      if (!beforeClosedSignal?.aborted) {
        if (signal.aborted) {
          throw new Error('Resource closed.');
        }

        if (beforeClosedTasks.has(task)) {
          throw new Error('Task already running.');
        }

        beforeClosedTasks.add(task);

        beforeClosedSignal?.addEventListener(
          'abort',
          (): void => {
            beforeClosedTasks.delete(task);
          },
          {
            signal,
            once: true,
          },
        );
      }
    },
    close: async (reason: unknown): Promise<void> => {
      try {
        switch (mode) {
          case 'parallel': {
            const errors: readonly PromiseRejectedResult[] = (
              await Promise.allSettled(
                beforeClosedTasks
                  .values()
                  .map((task: OnCloseResource): PromiseLike<void> | void => {
                    return task(reason);
                  }),
              )
            ).filter((result: PromiseSettledResult<void>): result is PromiseRejectedResult => {
              return result.status === 'rejected';
            });

            if (errors.length === 1) {
              throw errors[0];
            } else if (errors.length > 1) {
              throw new AggregateError(errors);
            }

            break;
          }
          case 'sequential': {
            throw 'TODO'; // TODO
          }
        }
      } catch (pendingTasksError: unknown) {
        try {
          await close(reason);
        } catch (closeError: unknown) {
          throw new SuppressedError(closeError, pendingTasksError);
        }

        throw pendingTasksError;
      }

      await close(reason);
    },
    signal,
  };
}
