import { OnCloseResource } from '../types/close-resource.js';

export interface ResourceOptions {
  readonly close: OnCloseResource;
  readonly signal: AbortSignal;
}

export class Resource {
  readonly #close: OnCloseResource;
  readonly #signal: AbortSignal;
  readonly #closedPromise: PromiseWithResolvers<unknown>;

  constructor({ close, signal }: ResourceOptions) {
    if (signal.aborted) {
      throw new Error('Cannot construct a Resource using an aborted Signal.');
    }

    this.#close = close;
    this.#signal = signal;
    this.#closedPromise = Promise.withResolvers<unknown>();

    this.#signal.addEventListener(
      'abort',
      (): void => {
        this.#closedPromise.resolve(Promise.try(this.#close, this.#signal.reason));
      },
      {
        once: true,
      },
    );
  }

  /**
   * An `AbortSignal` aborted when the `Resource` is closing.
   */
  get closeSignal(): AbortSignal {
    return this.#signal;
  }

  /**
   * A Promise resolved when the `Resource` is closed.
   */
  get closed(): Promise<unknown> {
    return this.#closedPromise.promise;
  }

  /**
   * Closes the `Resource`.
   */
  async close(reason?: unknown): Promise<void> {
    this.#controller.abort(reason);
    await this.closed;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }
}
