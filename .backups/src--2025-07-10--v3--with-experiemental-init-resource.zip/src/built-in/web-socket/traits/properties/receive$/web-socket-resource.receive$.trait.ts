import { type EmitterResourceTrait } from '../../../../emitter-resource/__traits.private/emitter-resource.trait.js';
import { type WebSocketDownValue } from '../../types/web-socket-down-value.js';

export interface WebSocketResourceReceiveTrait {
  /**
   * An emitter receiving the payloads.
   */
  readonly receive$: EmitterResourceTrait<WebSocketDownValue>;
}
