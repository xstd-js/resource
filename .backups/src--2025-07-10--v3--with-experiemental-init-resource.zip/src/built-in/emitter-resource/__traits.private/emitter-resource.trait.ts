import { type ResourceTrait } from '../../../resource/__traits.private/resource.trait.js';
import { type EmitterResourceListenTrait } from './methods/listen/emitter-resource.listen.trait.js';
import { EmitterResourceMapTrait } from './methods/map/emitter-resource.map.trait.js';

export interface EmitterResourceTrait<GValue>
  extends ResourceTrait,
    EmitterResourceListenTrait<GValue>,
    EmitterResourceMapTrait<GValue>,
    AsyncIterable<GValue> {}
