import { InitCloseResource, OnCloseResource } from '../types/close-resource.js';
import { Resource } from './resource.js';

// export interface DisposableResourceOptions extends Omit<ResourceOptions, 'signal'> {}

export class DisposableResource extends Resource implements AsyncDisposable {
  readonly #onCloseResource: OnCloseResource;
  readonly #initCloseResource: InitCloseResource;

  constructor(onCloseResource: OnCloseResource) {
    let initCloseResource!: InitCloseResource;

    super((_initCloseResource: InitCloseResource): void => {
      initCloseResource = _initCloseResource;
    });

    this.#onCloseResource = onCloseResource;
    this.#initCloseResource = initCloseResource;
  }

  /**
   * Closes the `Resource`.
   */
  async close(reason?: unknown): Promise<void> {
    const { resolve, promise } = this.#initCloseResource(reason);
    resolve(Promise.try(this.#onCloseResource, reason));
    await promise;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }
}
