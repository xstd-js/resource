import { Abortable, type AbortablePromiseFactory } from '@xstd/abortable';
import { InitCloseResource, OnCloseResource } from '../../types/close-resource.js';
/*--------*/

export interface ResourceOptionsWithRunTask {
  readonly runTask: RunTask;
  readonly close: InitCloseResource;
}

export interface RunTask {
  <GReturn>(task: AbortablePromiseFactory<GReturn> | Promise<GReturn>): Promise<GReturn>;
}

export function resourceOptionsWithRunTask(close: OnCloseResource): ResourceOptionsWithRunTask {
  const pendingTasks: Set<Promise<unknown>> = new Set<Promise<unknown>>();

  return {
    runTask: async <GReturn>(
      task: AbortablePromiseFactory<GReturn> | Promise<GReturn>,
    ): Promise<GReturn> => {
      if (signal.aborted) {
        throw new Error('Resource closed.');
      }

      if (typeof task === 'function') {
        task = Promise.try<GReturn, [AbortSignal]>(task, signal);
      }

      if (pendingTasks.has(task)) {
        throw new Error('Task already running.');
      }

      pendingTasks.add(task);

      try {
        return await task;
      } finally {
        pendingTasks.delete(task);
      }
    },
    close: async (reason: unknown): Promise<void> => {
      try {
        await Promise.allSettled(pendingTasks.values());
      } catch (pendingTasksError: unknown) {
        try {
          await close(reason);
        } catch (closeError: unknown) {
          throw new SuppressedError(closeError, pendingTasksError);
        }

        throw pendingTasksError;
      }

      await close(reason);
    },
    signal,
  };
}

/*--------*/

export interface ResourceOptionsWithBeforeClosed extends ResourceOptions {
  readonly beforeClosed: BeforeClosed;
}

export interface BeforeClosed {
  (task: OnCloseResource, options?: Abortable): void;
}

export function resourceOptionsWithBeforeClosed(
  mode: 'parallel' | 'sequential',
  { close, signal }: ResourceOptions,
): ResourceOptionsWithBeforeClosed {
  const pendingTasks: Set<OnCloseResource> = new Set<OnCloseResource>();

  return {
    beforeClosed: (task: OnCloseResource, { signal: localSignal }: Abortable = {}): void => {
      if (signal.aborted) {
        throw new Error('Resource closed.');
      }

      if (pendingTasks.has(task)) {
        throw new Error('Task already running.');
      }

      pendingTasks.add(task);
    },
    close: async (reason: unknown): Promise<void> => {
      try {
        await Promise.allSettled(pendingTasks.values());
      } catch (pendingTasksError: unknown) {
        try {
          await close(reason);
        } catch (closeError: unknown) {
          throw new SuppressedError(closeError, pendingTasksError);
        }

        throw pendingTasksError;
      }

      await close(reason);
    },
    signal,
  };
}
