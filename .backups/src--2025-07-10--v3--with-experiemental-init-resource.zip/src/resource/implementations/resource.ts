import { type CloseResource, type InitCloseResource } from '../types/close-resource.js';

export interface InitResource {
  (initClose: InitCloseResource): void;
}

export class Resource {
  readonly #controller: AbortController;
  readonly #closed: PromiseWithResolvers<void>;

  constructor(init: InitResource) {
    this.#controller = new AbortController();
    this.#closed = Object.freeze(Promise.withResolvers<void>());

    init((reason: unknown): CloseResource => {
      if (this.#controller.signal.aborted) {
        throw new Error('Resource closed.');
      }

      this.#controller.abort(reason);

      return this.#closed;
    });
  }

  /**
   * An `AbortSignal` aborted when the `Resource` is closing.
   */
  get closeSignal(): AbortSignal {
    return this.#controller.signal;
  }

  /**
   * A Promise resolved when the `Resource` is closed.
   */
  get closed(): Promise<void> {
    return this.#closed.promise;
  }
}
