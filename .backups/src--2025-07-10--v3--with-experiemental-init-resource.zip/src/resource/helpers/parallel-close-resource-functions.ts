import { type CloseResource } from '../__traits.private/types/close-resource.js';

// export function parallelCloseResourceFunctions(
//   closeFunctions: Iterable<CloseResource>,
// ): CloseResource {
//   return async (reason: unknown): Promise<void> => {
//     const results: readonly PromiseSettledResult<void>[] = await Promise.allSettled(
//       Array.from(closeFunctions, (closeFunction: CloseResource): PromiseLike<void> | void => {
//         return closeFunction(reason);
//       }),
//     );
//
//     const errors: readonly PromiseRejectedResult[] = results.filter(
//       (result: PromiseSettledResult<void>): result is PromiseRejectedResult => {
//         return result.status === 'rejected';
//       },
//     );
//
//     if (errors.length === 1) {
//       throw errors[0];
//     } else if (errors.length > 1) {
//       throw new AggregateError(errors);
//     }
//   };
// }

/**
 * @deprecated
 */
export async function parallelCloseResourceFunctions(
  closeFunctions: Iterable<CloseResource>,
  reason: unknown,
): Promise<void> {
  const results: readonly PromiseSettledResult<void>[] = await Promise.allSettled(
    Array.from(closeFunctions, (closeFunction: CloseResource): PromiseLike<void> | void => {
      return closeFunction(reason);
    }),
  );

  const errors: readonly PromiseRejectedResult[] = results.filter(
    (result: PromiseSettledResult<void>): result is PromiseRejectedResult => {
      return result.status === 'rejected';
    },
  );

  if (errors.length === 1) {
    throw errors[0];
  } else if (errors.length > 1) {
    throw new AggregateError(errors);
  }
}
