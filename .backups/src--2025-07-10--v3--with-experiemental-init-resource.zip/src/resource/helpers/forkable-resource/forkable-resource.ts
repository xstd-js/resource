import { type Abortable } from '@xstd/abortable';
import { type ResourceTrait } from '../../__traits.private/resource.trait.js';
import { type CloseResource } from '../../__traits.private/types/close-resource.js';
import { ClosableResource } from '../../implementations/resource.js';

export interface InitForkableResource {
  (fork: ForkResource): void;
}

export interface ForkResource {
  (child: ResourceTrait, options?: Abortable): void;
}

export class ForkableResource extends ClosableResource {
  constructor(init: InitForkableResource, close?: CloseResource) {
    const forked: Set<ResourceTrait> = new Set<ResourceTrait>();

    super(async (reason: unknown): Promise<void> => {
      const forkedResults: readonly PromiseSettledResult<void>[] = await Promise.allSettled(
        forked.values().map((resource: ResourceTrait): Promise<void> => {
          return resource.close(reason);
        }),
      );

      const forkedErrors: readonly PromiseRejectedResult[] = forkedResults.filter(
        (result: PromiseSettledResult<void>): result is PromiseRejectedResult => {
          return result.status === 'rejected';
        },
      );

      let forkedError: unknown;
      if (forkedErrors.length === 1) {
        forkedError = forkedErrors[0];
      } else if (forkedErrors.length > 1) {
        forkedError = new AggregateError(forkedErrors);
      }

      if (close === undefined) {
        if (forkedErrors.length > 0) {
          throw forkedError;
        }
      } else {
        try {
          await close(reason);
        } catch (closeError: unknown) {
          if (forkedErrors.length > 0) {
            throw new SuppressedError(closeError, forkedError);
          } else {
            throw closeError;
          }
        }
      }
    });

    init((child: ResourceTrait, { signal }: Abortable = {}): void => {
      if (!signal?.aborted) {
        if (this.closeSignal.aborted) {
          throw new Error('Parent resource closed.');
        }

        if (child.closeSignal.aborted) {
          throw new Error('Child resource closed.');
        }

        if (forked.has(child)) {
          throw new Error('The given "child" resource is already forked.');
        }

        forked.add(child);

        child.closed.then((): void => {
          if (!signal?.aborted) {
            forked.delete(child);
          }
        });

        signal?.addEventListener(
          'abort',
          (): void => {
            forked.delete(child);
          },
          {
            signal: child.closeSignal,
            once: true,
          },
        );
      }
    });
  }
}
