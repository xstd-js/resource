export interface InitCloseResource {
  (reason: unknown): CloseResource;
}

export type CloseResource = PromiseWithResolvers<void>;

export interface OnCloseResource {
  (reason: unknown): PromiseLike<void> | void;
}
