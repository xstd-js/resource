import { type Abortable } from '@xstd/abortable';
import { type ClosableResource } from '../implementations/resource.js';

export interface OpenResource<GResource extends ClosableResource> {
  (options?: OpenResourceOptions): PromiseLike<GResource> | GResource;
}

export interface OpenResourceOptions extends Abortable {}
