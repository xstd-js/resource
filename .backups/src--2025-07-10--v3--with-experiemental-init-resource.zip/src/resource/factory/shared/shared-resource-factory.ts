import { type Abortable, abortify } from '@xstd/abortable';
import { noop } from '@xstd/noop';
import { CloseResource } from '../../__traits.private/types/close-resource.js';
import { parallelCloseResources } from '../../helpers/parallel-close-resources.js';
import { type ClosableResource } from '../../implementations/resource.js';

/*---*/

export interface OpenMainResource<GMainResource extends ClosableResource> {
  (options: OpenMainResourceOptions): PromiseLike<GMainResource> | GMainResource;
}

export interface OpenMainResourceOptions extends Required<Abortable> {
  readonly close: CloseResource;
}

/*---*/

export interface CreateChildResource<
  GMainResource extends ClosableResource,
  GChildResource extends ClosableResource,
> {
  (
    options: CreateChildResourceOptions<GMainResource>,
  ): PromiseLike<GChildResource> | GChildResource;
}

export interface CreateChildResourceOptions<GMainResource extends ClosableResource>
  extends Abortable {
  readonly mainResource: GMainResource;
  readonly close: CloseResource;
}

/*---*/

export interface SharedResourceFactoryOptions<
  GMainResource extends ClosableResource,
  GChildResource extends ClosableResource,
> {
  readonly main: OpenMainResource<GMainResource>;
  readonly child: CreateChildResource<GMainResource, GChildResource>;
}

export class SharedResourceFactory<
  GMainResource extends ClosableResource,
  GChildResource extends ClosableResource,
> {
  readonly #main: OpenMainResource<GMainResource>;
  readonly #child: CreateChildResource<GMainResource, GChildResource>;

  #usageCount: number;
  readonly #childResources: Set<GChildResource>;
  #openController: AbortController | undefined;
  #openPromise: Promise<GMainResource> | undefined;
  #closePromise: Promise<void> | undefined;

  constructor({ main, child }: SharedResourceFactoryOptions<GMainResource, GChildResource>) {
    this.#main = main;
    this.#child = child;
    this.#usageCount = 0;
    this.#childResources = new Set<GChildResource>();
  }

  async open(options?: Abortable): Promise<GChildResource> {
    return this.#open(options);
  }

  async #open(options?: Abortable): Promise<GChildResource> {
    options?.signal?.throwIfAborted();

    // await previous close
    if (this.#closePromise !== undefined) {
      await abortify(this.#closePromise.catch(noop), options);
    }

    this.#usageCount++;

    // open the shared `mainResource`
    if (this.#openPromise === undefined) {
      const openController: AbortController = new AbortController();
      this.#openController = new AbortController();

      this.#openPromise = Promise.try(() =>
        this.#main({
          signal: openController.signal,
          close: (reason: unknown): Promise<void> => {
            return parallelCloseResources(this.#childResources, reason);
          },
        }),
      ).finally((): void => {
        openController.abort();
      });
    }

    // acquire for the `mainResource`
    let mainResource: GMainResource;
    try {
      mainResource = await abortify(this.#openPromise!, options);
    } catch (error: unknown) {
      // failed to acquire for the `mainResource`
      this.#usageCount--;

      if (this.#usageCount === 0) {
        this.#openController!.abort();
        this.#openController = undefined;
        this.#openPromise = undefined;
      }

      throw error;
    }

    // acquire for the `childResource`
    let childResource: GChildResource;
    try {
      let closed: boolean = false;
      childResource = await this.#child({
        ...options,
        mainResource,
        close: async (reason: unknown): Promise<void> => {
          if (closed) {
            throw new Error('Already closed.');
          } else {
            closed = true;

            // close the `childResource`
            this.#usageCount--;
            this.#childResources.delete(childResource);

            if (this.#usageCount === 0) {
              this.#openPromise = undefined;

              if (!mainResource.closeSignal.aborted) {
                // close `mainResource` if it IS NOT already closed or closing
                await (this.#closePromise = mainResource.close(reason).finally((): void => {
                  this.#closePromise = undefined;
                }));
              }
            }
          }
        },
      });
    } catch (error: unknown) {
      // failed to acquire for the `childResource`
      this.#usageCount--;

      if (this.#usageCount === 0) {
        this.#openPromise = undefined;
      }

      throw error;
    }

    this.#childResources.add(childResource);

    return childResource;
  }
}
