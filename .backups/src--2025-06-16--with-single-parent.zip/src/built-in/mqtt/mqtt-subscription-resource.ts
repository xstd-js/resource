import { IPublishPacket, MqttClient } from 'mqtt';
import { Resource, ResourceEventMap } from '../../resource/resource.js';
import { CreateChildResourceOptions } from '../../resource/shared-resource.js';
import { MqttTopic } from './topic/mqtt-topic.js';

export interface MqttPublishPaket {
  readonly topic: string;
  readonly payload: Uint8Array;
}

export interface MqttSubscriptionResourceEventMap extends ResourceEventMap {
  readonly packet: CustomEvent<MqttPublishPaket>;
}

export interface MqttSubscriptionResourceOptions extends CreateChildResourceOptions {
  readonly client: MqttClient;
  readonly topic: string;
}

export class MqttSubscriptionResource extends Resource<MqttSubscriptionResourceEventMap> {
  constructor({ client, topic, close, ...options }: MqttSubscriptionResourceOptions) {
    const topicMatcher: MqttTopic = new MqttTopic(topic);

    const onClientMessage = (topic: string, payload: Buffer, _packet: IPublishPacket): void => {
      if (topicMatcher.matches(topic)) {
        this.dispatchEvent(
          new CustomEvent('packet', {
            detail: {
              topic,
              payload,
            },
          }),
        );
      }
    };

    client.on('message', onClientMessage);

    super({
      ...options,
      close: (reason: unknown): PromiseLike<void> | void => {
        client.off('message', onClientMessage);
        return close(reason);
      },
    });
  }
}
