import { type Abortable, mergeAbortSignals, sleep } from '@xstd/abortable';
import { WebSocketError } from '@xstd/custom-error';
import { Resource, ResourceEventMap, ResourceOptions } from '../../resource/resource.js';

export type WebSocketDownValue = ArrayBuffer | string;
export type WebSocketUpValue = string | ArrayBufferLike | Blob | ArrayBufferView;

export interface WebSocketResourceOptions extends Omit<ResourceOptions, 'close'>, Abortable {
  readonly protocols?: string | readonly string[];
  readonly parent?: Resource | null;
}

interface InternalWebSocketResourceOptions extends Omit<ResourceOptions, 'close'> {
  readonly webSocket: WebSocket;
}

export interface WebSocketResourceEventMap extends ResourceEventMap {
  readonly message: CustomEvent<WebSocketDownValue>;
}

export class WebSocketResource extends Resource<WebSocketResourceEventMap> {
  static open(
    url: string | URL,
    { protocols, parent, signal: _signal }: WebSocketResourceOptions = {},
  ): Promise<WebSocketResource> {
    return new Promise(
      (_resolve: (value: WebSocketResource) => void, _reject: (error: unknown) => void): void => {
        const signal: AbortSignal = mergeAbortSignals([parent?.signal, _signal]);
        signal.throwIfAborted();

        const end = (): void => {
          signal.removeEventListener('abort', onAbort);
          webSocket.removeEventListener('open', onOpen);
          webSocket.removeEventListener('close', onClose);
          webSocket.removeEventListener('error', onError);
        };

        const resolve = (value: WebSocketResource): void => {
          end();
          _resolve(value);
        };

        const reject = (error: unknown): void => {
          end();
          _reject(error);
        };

        const onAbort = (): void => {
          end();
          reject(signal.reason);
        };

        const onOpen = (): void => {
          end();
          resolve(
            new WebSocketResource({
              webSocket,
              parent,
            }),
          );
        };

        const onClose = (event: CloseEvent): void => {
          end();
          reject(WebSocketError.fromCloseEvent(event));
        };

        const onError = (): void => {
          end();
          reject(new WebSocketError());
        };

        const webSocket: WebSocket = new WebSocket(url, protocols as string[]);
        webSocket.binaryType = 'arraybuffer';

        signal.addEventListener('abort', onAbort);
        webSocket.addEventListener('open', onOpen);
        webSocket.addEventListener('close', onClose);
        webSocket.addEventListener('error', onError);
      },
    );
  }

  readonly #webSocket: WebSocket;

  private constructor({ webSocket, parent }: InternalWebSocketResourceOptions) {
    if (webSocket.readyState !== WebSocket.OPEN) {
      throw new Error('WebSocket not open.');
    }

    const onClose = (event: CloseEvent): void => {
      void this.close(WebSocketError.fromCloseEvent(event));
    };

    const onError = (): void => {
      void this.close(new WebSocketError());
    };

    const onMessage = (event: MessageEvent<WebSocketDownValue>): void => {
      this.dispatchEvent(
        new CustomEvent('message', {
          detail: event.data,
        }),
      );
    };

    webSocket.addEventListener('close', onClose);
    webSocket.addEventListener('error', onError);
    webSocket.addEventListener('message', onMessage);

    super({
      close: (reason: unknown): void => {
        webSocket.removeEventListener('close', onClose);
        webSocket.removeEventListener('error', onError);
        webSocket.removeEventListener('message', onMessage);

        if (
          webSocket.readyState === WebSocket.CONNECTING ||
          webSocket.readyState === WebSocket.OPEN
        ) {
          // TODO await buffer flushed ?
          if (reason instanceof WebSocketError) {
            webSocket.close(reason.code, reason.reason);
          } else {
            webSocket.close();
          }
        }
      },
      parent,
    });

    this.#webSocket = webSocket;
  }

  send(payload: WebSocketUpValue): Promise<void> {
    return this.runTask(async (): Promise<void> => {
      this.#webSocket.send(payload);

      while (this.#webSocket.bufferedAmount > 0) {
        if (
          this.#webSocket.readyState === WebSocket.CLOSING ||
          this.#webSocket.readyState === WebSocket.CLOSED
        ) {
          throw new Error(
            `WebSocket ${this.#webSocket.readyState === WebSocket.CLOSING ? 'closing' : 'closed'}.`,
          );
        }
        await sleep(0, { signal: this.signal });
      }
    });
  }
}
