import { type Abortable } from '@xstd/abortable';
import { type EventMapConstraint, ModernEventTarget } from '../misc/modern-event-target.js';
import { debugResource } from './helpers/debug-resource.js';

/*----*/

export interface OpenResource<GResource extends Resource> {
  (options?: Abortable): PromiseLike<GResource> | GResource;
}

export interface ResourceOptions {
  readonly close: CloseResource;
  readonly parent?: Resource | null;
}

export interface CloseResource {
  (reason: unknown): PromiseLike<void> | void;
}

export type ResourceState = 'open' | 'closing' | 'closed';

export interface ResourceEventMap {
  readonly closing: Event;
  readonly closed: Event;
}

export interface InspectResourceOptions {
  readonly open?: () => void;
  readonly closing?: (reason: unknown) => void;
  readonly closed?: (reason: unknown) => void;
}

export class Resource<
    GEventMap extends EventMapConstraint<GEventMap> & ResourceEventMap = ResourceEventMap,
  >
  extends ModernEventTarget<GEventMap>
  implements AsyncDisposable
{
  // close
  readonly #close: CloseResource;
  #state: ResourceState;
  #closeReason: unknown;
  #closePromise: Promise<void> | undefined;

  // tree
  #parent: Resource | null;
  #children: Set<Resource>;

  // tasks
  readonly #pendingTasks: Set<Promise<any>>;

  // misc
  #controller: AbortController | undefined;

  constructor({ close, parent = null }: ResourceOptions) {
    super();

    this.#close = close;
    this.#state = 'open';

    this.#parent = parent;
    this.#children = new Set<Resource>();

    this.#pendingTasks = new Set<Promise<any>>();

    if (this.#parent !== null) {
      if (this.#parent.#state !== 'open') {
        throw new Error('Parent should have an "open" state.');
      }

      this.#parent.#children.add(this);
    }
  }

  /* CLOSE */

  get state(): ResourceState {
    return this.#state;
  }

  get closeReason(): unknown {
    return this.#closeReason;
  }

  throwIfClosed(direct: boolean = false): void {
    if (this.#state !== 'open') {
      throw direct ?
          this.#closeReason
        : new Error('Resource closed.', {
            cause: this.#closeReason,
          });
    }
  }

  close(reason?: unknown): Promise<void> {
    if (this.#state === 'open') {
      this.#state = 'closing';
      this.#closeReason = reason;
      this.dispatchEvent(new Event('closing'));

      if (this.#controller !== undefined) {
        this.#controller.abort(reason);
      }

      this.#closePromise = Promise.allSettled([
        ...this.#children.values().map((childResource: Resource): Promise<void> => {
          return childResource.close(reason);
        }),
        ...this.#pendingTasks.values(),
      ])
        .then((): PromiseLike<void> | void => {
          return this.#close(reason);
        })
        .finally((): void => {
          this.#state = 'closed';
          if (this.#parent !== null) {
            this.#parent.#children.delete(this);
          }
          this.dispatchEvent(new Event('closed'));
        });
    }

    return this.#closePromise!;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }

  /* TREE */

  get parent(): Resource | null {
    return this.#parent;
  }

  get children(): ReadonlySet<Resource> {
    return this.#children;
  }

  /* TASKS */

  async runTask<GReturn>(
    task: Promise<GReturn> | (() => PromiseLike<GReturn> | GReturn),
  ): Promise<GReturn> {
    this.throwIfClosed();

    if (typeof task === 'function') {
      task = Promise.try(task);
    }

    if (this.#pendingTasks.has(task)) {
      throw new Error('Task already running.');
    }

    this.#pendingTasks.add(task);

    try {
      return await task;
    } finally {
      this.#pendingTasks.delete(task);
    }
  }

  /* MISC */

  get signal(): AbortSignal {
    if (this.#controller === undefined) {
      this.#controller = new AbortController();

      if (this.#state !== 'open') {
        this.#controller.abort(this.#closeReason);
      }
    }

    return this.#controller.signal;
  }

  inspect({ open, closing, closed }: InspectResourceOptions = {}): this {
    if (open !== undefined) {
      open();
    }

    if (closing !== undefined) {
      this.addEventListener('closing', (): void => {
        closing(this.#closeReason);
      });
    }

    if (closed !== undefined) {
      this.addEventListener('closed', (): void => {
        closed(this.#closeReason);
      });
    }

    return this;
  }

  debug(name: string): this {
    return this.inspect(debugResource(name));
  }
}
