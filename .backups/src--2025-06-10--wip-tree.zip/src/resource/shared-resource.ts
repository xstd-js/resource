import { type Abortable, abortify } from '@xstd/abortable';
import { block } from '@xstd/block';
import { CloseResource, Resource } from './resource.js';

export interface OpenSharedResource<GData> {
  (signal: AbortSignal): PromiseLike<SharedResourceData<GData>> | SharedResourceData<GData>;
}

export interface SharedResourceData<GData> {
  readonly data: GData;
  readonly close: CloseSharedResource;
}

export interface CloseSharedResource {
  (reason: unknown): PromiseLike<void> | void;
}

export interface CreateSharedResource<GData, GResource extends Resource> {
  (data: GData, close: CloseResource): GResource;
}

export interface SharedResourceOptions<GData, GResource extends Resource> {
  readonly open: OpenSharedResource<GData>;
  readonly create: CreateSharedResource<GData, GResource>;
}

export class SharedResource<GData, GResource extends Resource> {
  readonly #openData: OpenSharedResource<GData>;
  readonly #create: CreateSharedResource<GData, GResource>;

  #usageCount: number;
  #openController: AbortController | undefined;
  #openPromise: Promise<void> | undefined;
  #data: SharedResourceData<GData> | undefined;
  #closePromise: Promise<void> | undefined;

  constructor({ open, create }: SharedResourceOptions<GData, GResource>) {
    this.#openData = open;
    this.#create = create;
    this.#usageCount = 0;
  }

  async open(options?: Abortable): Promise<GResource> {
    await this.#open(options);

    return this.#create(this.#data);

    // this.#open(() => {
    //   this.#usageCount--;
    // }, options);
  }

  async #open(options?: Abortable): Promise<GResource> {
    options?.signal?.throwIfAborted();

    // await previous disposal
    if (this.#closePromise !== undefined) {
      await abortify(this.#closePromise, options);
    }

    try {
      await abortify(
        block(async (): Promise<void> => {
          this.#usageCount++;

          if (this.#usageCount === 1) {
            this.#openController = new AbortController();
            const signal: AbortSignal = this.#openController.signal;

            const openPromiseWithResolvers: PromiseWithResolvers<void> =
              Promise.withResolvers<void>();
            this.#openPromise = openPromiseWithResolvers.promise;

            try {
              const data: SharedResourceData<GData> = await this.#openData(signal);
              signal?.throwIfAborted();
              this.#data = data;
              openPromiseWithResolvers.resolve();
            } catch (error: unknown) {
              openPromiseWithResolvers.reject(error);
              throw error;
            } finally {
              if (this.#openController !== undefined) {
                this.#openController.abort();
                this.#openController = undefined;
              }
              this.#openPromise = undefined;
            }
          } else {
            await this.#openPromise!;
          }

          this.#create(this.#data, () => {
            this.#close();
          });
        }),
        options,
      );
    } catch (error: unknown) {
      await this.#close(error);
      throw error;
    }
  }

  async #close(reason?: unknown): Promise<void> {
    this.#usageCount--;

    if (this.#usageCount === 0) {
      if (this.#openController !== undefined) {
        this.#openController.abort();
        this.#openController = undefined;
      }

      const closePromiseWithResolvers: PromiseWithResolvers<void> = Promise.withResolvers<void>();
      this.#closePromise = closePromiseWithResolvers.promise;

      try {
        if (this.#data !== undefined) {
          await this.#data.close(reason);
        }
      } finally {
        this.#data = undefined;
        this.#closePromise = undefined;
        closePromiseWithResolvers.resolve();
      }
    }
  }
}
