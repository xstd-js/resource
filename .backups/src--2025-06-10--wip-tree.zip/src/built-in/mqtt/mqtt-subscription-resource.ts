import { Resource, ResourceEventMap } from '../../resource/resource.js';

export interface MqttPublishPaket {
  readonly topic: string;
  readonly payload: Uint8Array;
}

export interface MqttSubscriptionResourceEventMap extends ResourceEventMap {
  readonly packet: CustomEvent<MqttPublishPaket>;
}

export type MqttSubscriptionResource = Resource<MqttSubscriptionResourceEventMap>;

// export class MqttSubscriptionResource extends Resource<MqttSubscriptionResourceEventMap> {
//   readonly #client: MqttClient;
//
//   // TODO continue here
//   private constructor(client: MqttClient, topic: string) {
//     const topicMatcher: MqttTopic = new MqttTopic(topic);
//
//     const onClientMessage = (topic: string, payload: Buffer, packet: IPublishPacket): void => {
//       if (topicMatcher.matches(topic)) {
//         this.dispatchEvent(
//           new CustomEvent('packet', {
//             detail: {
//               topic,
//               payload,
//             },
//           }),
//         );
//       }
//     };
//
//     client.on('message', onClientMessage);
//
//     super(async (): Promise<void> => {
//       client.off('message', onClientMessage);
//       await client.unsubscribeAsync(topic);
//     });
//   }
// }
