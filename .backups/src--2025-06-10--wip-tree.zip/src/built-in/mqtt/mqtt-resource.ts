import { Abortable, abortify, mergeAbortSignals } from '@xstd/abortable';
import { CompleteError } from '@xstd/custom-error';
import { SharedResource } from '@xstd/shared-resource';
import mqtt, { IDisconnectPacket, MqttClient } from 'mqtt';
import { SharedMqttClientFactory } from '../../../../../iot-core/v9/src/mqtt/adapters/mqtt-client.private/shared/shared-mqtt-client-factory.js';
import { Resource } from '../../resource/resource.js';
import {
  MqttSubscriptionResource,
  MqttSubscriptionResourceEventMap,
} from './mqtt-subscription-resource.js';
import { MqttTopic } from './topic/mqtt-topic.js';

export interface MqttResourceOptions extends Abortable {
  readonly clientId?: string;
  readonly username?: string;
  readonly password?: string;

  // readonly keepalive?: number;
  // readonly clean?: boolean;
}

export interface MqttResourcePublishOptions extends Abortable {
  readonly qos?: 0 | 1 | 2;
  readonly retain?: boolean;
  readonly dup?: boolean;
}

export interface MqttResourceSubscribeOptions extends Abortable {
  readonly qos?: 0 | 1 | 2;
  readonly noLocal?: boolean;
  readonly retainAsPublished?: boolean;
  readonly retainHandling?: 0 | 1 | 2;
}

interface ActiveSubscription {
  readonly qos: 0 | 1 | 2;
  readonly noLocal: boolean;
  readonly retainAsPublished: boolean;
  readonly retainHandling: 0 | 1 | 2;

  count: number;
}

export class MqttResource extends Resource {
  static async open(
    url: string | URL,
    { signal, ...options }: MqttResourceOptions = {},
  ): Promise<MqttResource> {
    const client: MqttClient = await mqtt.connectAsync(url.toString(), {
      ...options,
      reconnectPeriod: 0,
      autoUseTopicAlias: true,
      autoAssignTopicAlias: true,
    });

    // TODO
    client.setMaxListeners(20);
    // client.setMaxListeners(50);

    if (signal?.aborted) {
      await client.endAsync();
      throw signal.reason;
    }

    return new MqttResource(client);
  }

  readonly #client: MqttClient;
  readonly #activeSubscriptions: Map<string /* topic */, ActiveSubscription>;

  protected constructor(client: MqttClient) {
    if (!client.connected) {
      throw new Error('MqttClient not open.');
    }

    const onClientDisconnect = (packet: IDisconnectPacket): void => {
      if (packet.reasonCode === undefined || packet.reasonCode === 0x00) {
        void this.close(new CompleteError());
      } else {
        void this.close(new Error('Disconnected', { cause: packet }));
      }
    };

    const onClientError = (error: unknown): void => {
      void this.close(error);
    };

    const onClientEnd = (): void => {
      void this.close(new Error('Client ended'));
    };

    client.on('disconnect', onClientDisconnect);
    client.on('error', onClientError);
    client.on('end', onClientEnd);

    super(async (): Promise<void> => {
      client.off('disconnect', onClientDisconnect);
      client.off('error', onClientError);
      client.off('end', onClientEnd);

      await client.endAsync();
    });

    this.#client = client;
    this.#activeSubscriptions = new Map<string, ActiveSubscription>();
  }

  publish(
    topic: string,
    payload: string | Uint8Array,
    { signal, ...options }: MqttResourcePublishOptions = {},
  ): Promise<void> {
    return this.runTask(async (): Promise<void> => {
      await abortify(this.#client.publishAsync(topic, payload as any, options), {
        signal: mergeAbortSignals([signal, this.signal]),
      });
    });
  }

  async subscribe(
    topic: string,
    {
      qos = 0,
      noLocal = false,
      retainAsPublished = false,
      retainHandling = 0,
      signal,
    }: MqttResourceSubscribeOptions,
  ): Promise<MqttSubscriptionResource> {
    let activeSubscription: ActiveSubscription | undefined = this.#activeSubscriptions.get(topic);

    if (activeSubscription === undefined) {
      activeSubscription = {
        count: 0,
        qos,
        noLocal,
        retainAsPublished,
        retainHandling,
      };
    } else {
      if (
        qos !== activeSubscription.qos ||
        noLocal !== activeSubscription.noLocal ||
        retainAsPublished !== activeSubscription.retainAsPublished ||
        retainHandling !== activeSubscription.retainHandling
      ) {
        throw new Error(
          `Subscription "${topic}" with options ${JSON.stringify({ qos, noLocal, retainAsPublished, retainHandling })} is already locked. Use the same options, or close the previous one.`,
        );
      }
    }

    activeSubscription.count++;

    if (activeSubscription.count === 1) {
      const topicMatcher: MqttTopic = new MqttTopic(topic);
    }

    const client: SharedResource<MqttClient> = await SharedMqttClientFactory.open(
      clientOptions,
      signal,
    );

    return new Resource<MqttSubscriptionResourceEventMap>();
  }
}
