import { IPublishPacket, MqttClient } from 'mqtt';
import { TypedEventListener } from '../../../../../../typed-event-target/typed-event-listener.js';
import { CreateChildResourceOptions } from '../../../../resource/factory/shared/shared-resource-factory.js';
import { Resource } from '../../../../resource/implementations/resource.js';
import { MqttPublishPacketEvent } from '../../events/mqtt-publish-packet-event.js';
import { MqttTopic } from '../../topic/mqtt-topic.js';
import { MqttSubscriptionResourceTrait } from '../trait/mqtt-subscription-resource.trait.js';
import { MqttSubscriptionResourceEventMap } from '../types/mqtt-subscription-resource-event-map.js';

export interface MqttSubscriptionResourceOptions extends CreateChildResourceOptions {
  readonly client: MqttClient;
  readonly topic: string;
}

export class MqttSubscriptionResource extends Resource implements MqttSubscriptionResourceTrait {
  constructor({ client, topic, close, ...options }: MqttSubscriptionResourceOptions) {
    const topicMatcher: MqttTopic = new MqttTopic(topic);

    const onClientMessage = (topic: string, payload: Buffer, _packet: IPublishPacket): void => {
      if (topicMatcher.matches(topic)) {
        this.dispatchEvent(
          new MqttPublishPacketEvent('packet', {
            topic,
            payload,
          }),
        );
      }
    };

    client.on('message', onClientMessage);

    super({
      ...options,
      close: (reason: unknown): PromiseLike<void> | void => {
        client.off('message', onClientMessage);
        return close?.(reason);
      },
    });
  }

  /* EVENT TARGET */

  override addEventListener<GKey extends keyof MqttSubscriptionResourceEventMap>(
    type: GKey,
    listener: TypedEventListener<MqttSubscriptionResourceEventMap[GKey]>,
    options?: AddEventListenerOptions,
  ): void {
    return super.addEventListener(type as any, listener, options);
  }

  override removeEventListener<GKey extends keyof MqttSubscriptionResourceEventMap>(
    type: GKey,
    listener: TypedEventListener<MqttSubscriptionResourceEventMap[GKey]>,
    options?: EventListenerOptions,
  ): void {
    return super.removeEventListener(type as any, listener, options);
  }
}
