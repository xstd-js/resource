import { type TypedEventTarget } from '../../../../../../typed-event-target/typed-event-target.js';
import { type Resource } from '../../../../resource/implementations/resource.js';
import { type MqttSubscriptionResourceEventMap } from '../types/mqtt-subscription-resource-event-map.js';

export interface MqttSubscriptionResourceTrait
  extends Omit<Resource, keyof TypedEventTarget<MqttSubscriptionResourceEventMap>>,
    TypedEventTarget<MqttSubscriptionResourceEventMap> {}
