import { type ResourceEventMap } from '../../../../resource/traits/types/resource-event-map.js';
import { type MqttPublishPacketEvent } from '../../events/mqtt-publish-packet-event.js';

export interface MqttSubscriptionResourceEventMap extends ResourceEventMap {
  readonly packet: MqttPublishPacketEvent;
}
