// TODO trait
export class MqttPublishPacketEvent extends Event {
  readonly topic: string;
  readonly payload: Uint8Array;

  constructor(type: string, { topic, payload, ...options }: MqttPublishPacketEventInit) {
    super(type, options);

    this.topic = topic;
    this.payload = payload;
  }
}

export interface MqttPublishPacketEventInit extends EventInit {
  readonly topic: string;
  readonly payload: Uint8Array;
}
