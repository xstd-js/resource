import { type InspectResourceOptions } from '../traits/methods/inspect/inspect-resource-options.js';

const COLOR_SCHEME =
  typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches ?
    {
      light: '75%',
      open: '#35e062',
      closing: '#f6a62e',
      closed: '#ff5a5a',
    }
  : {
      light: '25%',
      open: '#2dba52',
      closing: '#fda31b',
      closed: '#ff2222',
    };

export function debugResource(
  name: string,
  color: string = `hsl(${Math.floor(Math.random() * 360).toString(10)}deg, 100%, ${COLOR_SCHEME.light})`,
): InspectResourceOptions {
  return {
    open: (): void => {
      console.log(`%c[OPEN]%c ${name}`, `color: ${COLOR_SCHEME.open}`, `color: ${color}`);
    },
    closing: (): void => {
      console.log(`%c[CLOSING]%c ${name}`, `color: ${COLOR_SCHEME.closing}`, `color: ${color}`);
    },
    closed: (error: unknown): void => {
      console.log(
        `%c[CLOSED]%c ${name}`,
        `color: ${COLOR_SCHEME.closed}`,
        `color: ${color}`,
        error,
      );
    },
  };
}
