export type ResourceState = 'open' | 'closing' | 'closed';
