import { ResourceState } from './resource-state.js';

export interface ResourceStateTrait {
  readonly state: ResourceState;
}
