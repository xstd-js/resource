import { TypedEventTarget } from '../../../../typed-event-target/typed-event-target.js';
import { ResourceCloseTrait } from './methods/close/resource.close.trait.js';
import { ResourceDebugTrait } from './methods/debug/resource.debug.trait.js';
import { ResourceInspectTrait } from './methods/inspect/resource.inspect.trait.js';
import { ResourceRunTaskTrait } from './methods/run-task/resource.run-task.trait.js';
import { ResourceThrowIfClosedTrait } from './methods/throw-if-closed/resource.throw-if-closed.trait.js';
import { ResourceCloseReasonTrait } from './properties/close-reason/resource.close-reason.trait.js';
import { ResourceStateTrait } from './properties/state/resource.state.trait.js';
import { ResourceEventMap } from './types/resource-event-map.js';

export interface ResourceTrait
  extends TypedEventTarget<ResourceEventMap>,
    /* CLOSE */
    ResourceStateTrait,
    ResourceCloseReasonTrait,
    ResourceThrowIfClosedTrait,
    ResourceCloseTrait,
    AsyncDisposable,
    /* TASKS */
    ResourceRunTaskTrait,
    /* MISC */
    ResourceInspectTrait<ResourceTrait>,
    ResourceDebugTrait<ResourceTrait> {
  readonly signal: AbortSignal;
}
