export interface ResourceDebugTrait<GThis> {
  debug(name: string): GThis;
}
