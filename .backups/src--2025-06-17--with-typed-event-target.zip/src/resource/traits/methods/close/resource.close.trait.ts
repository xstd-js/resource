export interface ResourceCloseTrait {
  close(reason?: unknown): Promise<void>;
}
