export interface ResourceThrowIfClosedTrait {
  throwIfClosed(direct?: boolean): void;
}
