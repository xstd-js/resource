export interface ResourceRunTaskTrait {
  runTask<GReturn>(
    task: Promise<GReturn> | (() => PromiseLike<GReturn> | GReturn),
  ): Promise<GReturn>;
}
