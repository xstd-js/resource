import { InspectResourceOptions } from './inspect-resource-options.js';

export interface ResourceInspectTrait<GThis> {
  inspect(options?: InspectResourceOptions): GThis;
}
