export interface InspectResourceOptions {
  readonly open?: () => void;
  readonly closing?: (reason: unknown) => void;
  readonly closed?: (reason: unknown) => void;
}
