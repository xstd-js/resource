import { type Abortable, abortify } from '@xstd/abortable';
import { noop } from '@xstd/noop';
import { Resource, ResourceOptions } from '../../implementations/resource.js';

export interface OpenMainResource<GMainResource extends Resource> {
  (signal: AbortSignal): PromiseLike<GMainResource> | GMainResource;
}

export interface CreateChildResource<
  GMainResource extends Resource,
  GChildResource extends Resource,
> {
  (
    options: CreateChildResourceOptions<GMainResource>,
  ): PromiseLike<GChildResource> | GChildResource;
}

export interface CreateChildResourceOptions<GMainResource extends Resource = Resource>
  extends Omit<ResourceOptions, 'requires'>,
    Abortable {
  readonly requires: readonly [GMainResource];
}

export interface SharedResourceFactoryOptions<
  GMainResource extends Resource,
  GChildResource extends Resource,
> {
  readonly main: OpenMainResource<GMainResource>;
  readonly child: CreateChildResource<GMainResource, GChildResource>;
}

export class SharedResourceFactory<
  GMainResource extends Resource,
  GChildResource extends Resource,
> {
  readonly #main: OpenMainResource<GMainResource>;
  readonly #child: CreateChildResource<GMainResource, GChildResource>;

  #usageCount: number;
  #openController: AbortController | undefined;
  #openPromise: Promise<void> | undefined;
  #mainResource: GMainResource | undefined;
  #closePromise: Promise<void> | undefined;

  constructor({ main, child }: SharedResourceFactoryOptions<GMainResource, GChildResource>) {
    this.#main = main;
    this.#child = child;
    this.#usageCount = 0;
  }

  async open(options?: Abortable): Promise<GChildResource> {
    return this.#open(options);
  }

  async #open(options?: Abortable): Promise<GChildResource> {
    options?.signal?.throwIfAborted();

    // await previous close
    if (this.#closePromise !== undefined) {
      await abortify(this.#closePromise.catch(noop), options);
    }

    try {
      this.#usageCount++;

      if (this.#usageCount === 1) {
        const openController = new AbortController();
        this.#openController = openController;

        this.#openPromise = Promise.try(() => this.#main(openController.signal))
          .then((mainResource: GMainResource): void => {
            openController.signal.throwIfAborted();
            this.#mainResource = mainResource;
          })
          .finally((): void => {
            openController.abort();
            if (this.#openController === openController) {
              this.#openController = undefined;
            }
          });
      }

      await abortify(this.#openPromise!, options);

      return await this.#child({
        ...options,
        close: (reason: unknown): Promise<void> => {
          return this.#close(reason);
        },
        requires: [this.#mainResource!],
      });
    } catch (error: unknown) {
      await this.#close(error);
      throw error;
    }
  }

  async #close(reason: unknown): Promise<void> {
    this.#usageCount--;

    if (this.#usageCount === 0) {
      if (this.#openController !== undefined) {
        this.#openController.abort();
        this.#openController = undefined;
      }

      if (this.#mainResource !== undefined) {
        if (this.#mainResource.state === 'open') {
          this.#closePromise = this.#mainResource.close(reason).finally((): void => {
            this.#closePromise = undefined;
            this.#mainResource = undefined;
          });

          await this.#closePromise;
        } else {
          this.#mainResource = undefined;
        }
      }
    }
  }
}
