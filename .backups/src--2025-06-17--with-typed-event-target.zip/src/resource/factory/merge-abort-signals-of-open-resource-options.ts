import { mergeAbortSignals } from '@xstd/abortable';
import type { Resource } from '../implementations/resource.js';
import { OpenResourceOptions } from './open-resource.js';

export function mergeAbortSignalsOfOpenResourceOptions({
  requires = [],
  signal,
}: OpenResourceOptions): AbortSignal {
  return mergeAbortSignals([
    signal,
    ...Array.from(requires, (required: Resource): AbortSignal => required.signal),
  ]);
}
