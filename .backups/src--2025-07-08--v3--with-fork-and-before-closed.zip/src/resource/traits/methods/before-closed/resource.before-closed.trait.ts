import { type ResourceBeforeClosedFunction } from './resource-before-closed.function.js';

export interface ResourceBeforeClosedTrait<GThis> {
  /**
   * Registers a _function_ to run before this `Resource` is closed.
   */
  beforeClosed(cleanupFnc: ResourceBeforeClosedFunction): GThis;
}
