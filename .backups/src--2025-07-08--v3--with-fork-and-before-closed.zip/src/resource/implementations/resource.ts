import { Lockable, Locked } from '@xstd/lock';
import { type ResourceBeforeClosedFunction } from '../traits/methods/before-closed/resource-before-closed.function.js';
import { ResourceForkOptions } from '../traits/methods/fork/resource.fork.trait.js';
import { type ResourceRunTaskFunction } from '../traits/methods/run-task/resource-run-task.function.js';
import { type ResourceTrait } from '../traits/resource.trait.js';

// const NEVER = Symbol('NEVER');

export class Resource implements ResourceTrait {
  // lock
  readonly #closeLock: Lockable;

  // close
  readonly #controller: AbortController;
  readonly #beforeClosed: ResourceBeforeClosedFunction[];
  readonly #closedPromise: PromiseWithResolvers<unknown>;

  // tasks
  readonly #pendingTasks: Set<Promise<any>>;

  constructor() {
    this.#controller = new AbortController();
    this.#beforeClosed = [];
    this.#closedPromise = Promise.withResolvers<unknown>();
    this.#closeLock = new Lockable();
    this.#pendingTasks = new Set<Promise<any>>();
  }

  /* LOCK */

  get closeLock(): Lockable {
    return this.#closeLock;
  }

  /* CLOSE */

  #throwIfClosed(): void {
    if (this.#controller.signal.aborted) {
      throw new Error('Resource closed.');
    }
  }

  /**
   * A Promise resolved when the `Resource` is closed.
   */
  get closed(): Promise<unknown> {
    return this.#closedPromise.promise;
  }

  /**
   * An `AbortSignal` aborted when the `Resource` is closing.
   */
  get closeSignal(): AbortSignal {
    return this.#controller.signal;
  }

  /**
   * Closes the `Resource`.
   */
  async close(reason?: unknown): Promise<void> {
    this.#closeLock.throwIfLocked();

    if (!this.#controller.signal.aborted) {
      this.#controller.abort(reason);

      this.#closedPromise.resolve(
        Promise.allSettled(this.#pendingTasks.values()).then(async (): Promise<void> => {
          let isErrored: boolean = false;
          let cascadedError: unknown;

          for (let i: number = this.#beforeClosed.length - 1; i >= 0; i--) {
            const beforeClosed: ResourceBeforeClosedFunction = this.#beforeClosed[i];

            try {
              await beforeClosed(reason);
            } catch (error: unknown) {
              if (isErrored) {
                cascadedError = new SuppressedError(error, cascadedError);
              } else {
                isErrored = true;
                cascadedError = error;
              }
            }
          }

          if (isErrored) {
            throw cascadedError;
          }
        }),
      );
    }

    await this.#closedPromise.promise!;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }

  /* TASKS */

  /**
   * Runs and appends a _task_ linked to this `Resource`.
   */
  async runTask<GReturn>(
    taskFnc: ResourceRunTaskFunction<GReturn> | Promise<GReturn>,
  ): Promise<GReturn> {
    this.#throwIfClosed();

    if (typeof taskFnc === 'function') {
      taskFnc = Promise.try<GReturn, [AbortSignal]>(taskFnc, this.#controller.signal);
    }

    if (this.#pendingTasks.has(taskFnc)) {
      throw new Error('Task already running.');
    }

    this.#pendingTasks.add(taskFnc);

    try {
      return await taskFnc;
    } finally {
      this.#pendingTasks.delete(taskFnc);
    }
  }

  /**
   * Registers a _function_ to run before this `Resource` is closed.
   */
  beforeClosed(cleanupFnc: ResourceBeforeClosedFunction): this {
    this.#throwIfClosed();

    this.#beforeClosed.push(cleanupFnc);

    return this;
  }

  fork<GResource extends ResourceTrait>(
    childResource: GResource,
    { mode = 'soft' }: ResourceForkOptions = {},
  ): GResource {
    switch (mode) {
      case 'soft': {
        this.beforeClosed((reason: unknown): Promise<void> | void => {
          if (!childClosed) {
            return childResource.close(reason);
          }
        });

        let childClosed: boolean = false;
        childResource.closed.finally((): void => {
          childClosed = true;
        });
        break;
      }
      case 'hard': {
        const lock: Locked = childResource.closeLock.lock();
        this.beforeClosed(
          (reason: unknown): Promise<void> =>
            lock.unlock((): Promise<void> => childResource.close(reason)),
        );
        break;
      }
    }

    return childResource;
  }
}
