import { FilterFunction } from '@lirx/utils';
import { type Abortable, mergeAbortSignals } from '@xstd/abortable';
import { FilterFunctionWithSubType, MapFilterFunction, type MapFunction } from '@xstd/functional';
import { noop } from '@xstd/noop';
import { Resource } from '../../../resource/implementations/resource.js';
import { type EmitterResourceTrait } from '../traits/emitter-resource.trait.js';
import { type EmitterResourceListener } from '../traits/methods/listen/emitter-resource-listener.js';
import { type EmitterResourceWithDispatcher } from '../traits/static-methods/with-dispatcher/emitter-resource-with-dispatcher.js';
import { type EmitterResourceDispatchFunction } from './types/emitter-resource-dispatch-function.js';
import { type EmitterResourceInitFunction } from './types/emitter-resource-init-function.js';

export interface EmitterResourceAsyncIteratorOptions extends Abortable {
  readonly bufferSize?: number;
  readonly windowTime?: number;
}

export class EmitterResource<GValue> extends Resource implements EmitterResourceTrait<GValue> {
  static withDispatcher<GValue>(): EmitterResourceWithDispatcher<GValue> {
    let dispatch!: EmitterResourceDispatchFunction<GValue>;

    return {
      emitter: new EmitterResource<GValue>(
        (_dispatch: EmitterResourceDispatchFunction<GValue>): void => {
          dispatch = _dispatch;
        },
      ),
      dispatch,
    };
  }

  static readonly #maxUnsubscribeCount: number = 0xff;

  // the list of listeners
  #listeners: EmitterResourceListener<GValue>[];

  // the number of postponed unsubscribed listeners
  #postponedUnsubscriptions: number;
  // the id of the last batch of unsubscriptions
  #lastUnsubscriptionsBatchId: number;
  // if we are dispatching
  #dispatching: boolean;

  constructor(init: EmitterResourceInitFunction<GValue>) {
    super();

    this.#listeners = [];
    this.#postponedUnsubscriptions = 0;
    this.#lastUnsubscriptionsBatchId = 0;
    this.#dispatching = false;

    // Reflect.apply(init, this, [
    //   (value: GValue): void => {
    //     this.#dispatch(value);
    //   },
    // ]);

    init((value: GValue): void => {
      this.#dispatch(value);
    });
  }

  #throwIfClosed(): void {
    if (this.closeSignal.aborted) {
      throw new Error('Resource closed.');
    }
  }

  #dispatch(value: GValue): void {
    this.#throwIfClosed();

    if (this.#dispatching) {
      throw new Error('Dispatch loop detected.');
    }

    this.#dispatching = true;

    for (let i: number = 0; i < this.#listeners.length; i++) {
      this.#listeners[i](value);
    }

    this.#batchUnsubscribe();

    this.#dispatching = false;
  }

  #batchUnsubscribe(): void {
    if (this.#postponedUnsubscriptions >= EmitterResource.#maxUnsubscribeCount) {
      this.#postponedUnsubscriptions = 0;
      this.#lastUnsubscriptionsBatchId++;
      this.#listeners = this.#listeners.filter(
        (listener: EmitterResourceListener<GValue>): boolean => {
          return listener !== noop;
        },
      );
    }
  }

  listen(listener: EmitterResourceListener<GValue>): Resource {
    this.#throwIfClosed();

    let listenerIndex: number = this.#listeners.length;
    let listenerUnsubscriptionsBatchId: number = this.#lastUnsubscriptionsBatchId;

    this.#listeners.push(listener);

    return this.fork(
      new Resource().beforeClosed((): void => {
        if (listenerUnsubscriptionsBatchId !== this.#lastUnsubscriptionsBatchId) {
          // => a batch of unsubscriptions happened before we unsubscribed this listener
          listenerIndex = this.#listeners.indexOf(listener);
        }
        this.#listeners[listenerIndex] = noop;
        this.#postponedUnsubscriptions++;

        if (!this.#dispatching) {
          this.#batchUnsubscribe();
        }
      }),
    );
  }

  /* TRANSFORM */

  #transform<GNewValue>(
    onValue: (value: GValue, dispatch: EmitterResourceDispatchFunction<GNewValue>) => void,
  ): EmitterResource<GNewValue> {
    let dispatch: EmitterResourceDispatchFunction<GNewValue>;

    return this.listen((value: GValue): void => {
      onValue(value, dispatch);
    }).fork(
      new EmitterResource<GNewValue>(
        (_dispatch: EmitterResourceDispatchFunction<GNewValue>): void => {
          dispatch = _dispatch;
        },
      ),
    );
  }

  map<GNewValue>(mapFnc: MapFunction<GValue, GNewValue>): EmitterResource<GNewValue> {
    return this.#transform(
      (value: GValue, dispatch: EmitterResourceDispatchFunction<GNewValue>): void => {
        dispatch(mapFnc(value));
      },
    );
  }

  filter<GNewValue extends GValue>(
    filterFnc: FilterFunctionWithSubType<GValue, GNewValue>,
  ): EmitterResource<GNewValue>;
  filter(filterFnc: FilterFunction<GValue>): EmitterResource<GValue>;
  filter(filterFnc: FilterFunction<GValue>): EmitterResource<GValue> {
    return this.#transform(
      (value: GValue, dispatch: EmitterResourceDispatchFunction<GValue>): void => {
        if (filterFnc(value)) {
          dispatch(value);
        }
      },
    );
  }

  mapFilter<GNewValue>(
    mapFilterFnc: MapFilterFunction<GValue, GNewValue>,
  ): EmitterResource<GNewValue> {
    return this.#transform(
      (value: GValue, dispatch: EmitterResourceDispatchFunction<GNewValue>): void => {
        const newValue: GNewValue | null = mapFilterFnc(value);
        if (newValue !== null) {
          dispatch(newValue);
        }
      },
    );
  }

  /* TO */

  async *toAsyncGenerator({
    bufferSize = Number.POSITIVE_INFINITY,
    windowTime = Number.POSITIVE_INFINITY,
    signal,
  }: EmitterResourceAsyncIteratorOptions = {}): AsyncGenerator<GValue> {
    bufferSize = Math.max(0, bufferSize);
    windowTime = Math.max(0, windowTime);

    const sharedSignal: AbortSignal = mergeAbortSignals([signal, this.closeSignal]);

    interface PendingValue {
      readonly value: GValue;
      readonly expirationDate: number;
    }

    const values: PendingValue[] = [];
    let pendingRead: PromiseWithResolvers<void> | undefined;

    await using _listenerHook = this.listen((value: GValue): void => {
      if (bufferSize > 0 && windowTime > 0) {
        values.push({
          value,
          expirationDate: Date.now() + windowTime,
        });

        if (values.length > bufferSize) {
          values.shift();
        }
      } else {
        if (pendingRead !== undefined) {
          values.length = 0;
          values.push({
            value,
            expirationDate: Number.POSITIVE_INFINITY,
          });
        }
      }

      if (pendingRead !== undefined) {
        pendingRead.resolve();
        pendingRead = undefined;
      }
    });

    while (true) {
      sharedSignal.throwIfAborted();

      // remove the expired values
      const now: number = Date.now();
      while (values.length > 0 && values[0].expirationDate < now) {
        values.shift();
      }

      if (values.length > 0) {
        yield values.shift()!.value;
      } else {
        pendingRead = Promise.withResolvers<void>();

        const onAbort = (): void => {
          sharedSignal.removeEventListener('abort', onAbort);
          pendingRead!.reject(sharedSignal!.reason);
          pendingRead = undefined;
        };

        sharedSignal.addEventListener('abort', onAbort);

        try {
          await pendingRead.promise;
        } finally {
          sharedSignal.removeEventListener('abort', onAbort);
        }
      }
    }
  }

  [Symbol.asyncIterator](): AsyncGenerator<GValue> {
    return this.toAsyncGenerator();
  }
}
