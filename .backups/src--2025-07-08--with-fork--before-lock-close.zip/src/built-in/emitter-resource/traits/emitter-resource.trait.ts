import { type ResourceTrait } from '../../../resource/traits/resource.trait.js';
import { type EmitterResourceListenTrait } from './methods/listen/emitter-resource.listen.trait.js';

export interface EmitterResourceTrait<GValue>
  extends ResourceTrait,
    EmitterResourceListenTrait<GValue>,
    AsyncIterable<GValue> {}
