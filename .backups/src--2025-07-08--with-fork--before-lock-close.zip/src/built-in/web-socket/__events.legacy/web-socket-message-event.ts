import { WebSocketDownValue } from '../traits/types/web-socket-down-value.js';

/**
 * @deprecated
 */
export class WebSocketMessageEvent extends Event {
  readonly payload: WebSocketDownValue;

  constructor(type: string, { payload, ...options }: WebSocketMessageEventInit) {
    super(type, options);

    this.payload = payload;
  }
}

export interface WebSocketMessageEventInit extends EventInit {
  readonly payload: WebSocketDownValue;
}
