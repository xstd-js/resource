export interface ResourceEventMap {
  readonly closing: Event;
  readonly closed: Event;
}
