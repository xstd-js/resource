export interface ResourceBeforeClosedFunction {
  (reason: unknown): PromiseLike<void> | void;
}
