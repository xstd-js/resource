import { type Abortable } from '@xstd/abortable';
import { type ResourceTrait } from '../../resource.trait.js';

export interface ResourceForkTrait {
  /**
   * Forks a `Resource`: when this `Resource` closes, runs and awaits `resource.close()` before.
   */
  fork<GResource extends ResourceTrait>(
    resource: GResource,
    options?: ResourceForkOptions,
  ): GResource;
}

export interface ResourceForkOptions extends Abortable {
  readonly mode?: ResourceForkMode;
}

export type ResourceForkMode =
  | 'soft' // in "soft" mode, if `resource` (the child) closes before this `Resource` (the parent), then we remove the `beforeClosed` of the parent (closing the parent won't reject if closing the child rejected).
  | 'hard'; // in "hard" mode, if closing the child rejected, then closing the parent will reject too.
