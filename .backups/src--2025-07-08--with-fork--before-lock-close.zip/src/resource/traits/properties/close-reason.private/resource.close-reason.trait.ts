export interface ResourceCloseReasonTrait {
  readonly closeReason: unknown;
}
