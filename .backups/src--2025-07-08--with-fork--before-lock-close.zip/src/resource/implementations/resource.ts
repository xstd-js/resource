import { type Abortable } from '@xstd/abortable';
import { type ResourceBeforeClosedFunction } from '../traits/methods/before-closed/resource-before-closed.function.js';
import { ResourceForkOptions } from '../traits/methods/fork/resource.fork.trait.js';
import { type ResourceRunTaskFunction } from '../traits/methods/run-task/resource-run-task.function.js';
import { type ResourceTrait } from '../traits/resource.trait.js';

export class Resource implements ResourceTrait {
  // close
  readonly #controller: AbortController;
  readonly #beforeClosed: ResourceBeforeClosedFunction[];
  readonly #closedPromise: PromiseWithResolvers<unknown>;

  // tasks
  readonly #pendingTasks: Set<Promise<any>>;

  constructor() {
    this.#controller = new AbortController();
    this.#beforeClosed = [];
    this.#closedPromise = Promise.withResolvers<unknown>();
    this.#pendingTasks = new Set<Promise<any>>();
  }

  /* CLOSE */

  #throwIfClosed(): void {
    if (this.#controller.signal.aborted) {
      throw new Error('Resource closed.');
    }
  }

  /**
   * A Promise resolved when the `Resource` is closed.
   */
  get closed(): Promise<unknown> {
    return this.#closedPromise.promise;
  }

  /**
   * An `AbortSignal` aborted when the `Resource` is closing.
   */
  get closeSignal(): AbortSignal {
    return this.#controller.signal;
  }

  /**
   * Closes the `Resource`.
   */
  async close(reason?: unknown): Promise<void> {
    if (!this.#controller.signal.aborted) {
      this.#controller.abort(reason);

      this.#closedPromise.resolve(
        Promise.allSettled(this.#pendingTasks.values())
          .then((): Promise<readonly PromiseSettledResult<void>[]> => {
            return Promise.allSettled<void>(
              this.#beforeClosed.map(
                (beforeClosed: ResourceBeforeClosedFunction): PromiseLike<void> | void => {
                  return beforeClosed(reason);
                },
              ),
            );
          })
          .then((results: readonly PromiseSettledResult<void>[]): void => {
            this.#beforeClosed.length = 0;

            const errors: readonly PromiseRejectedResult[] = results.filter(
              (result: PromiseSettledResult<void>): result is PromiseRejectedResult => {
                return result.status === 'rejected';
              },
            );

            if (errors.length === 0) {
              return;
            } else if (errors.length === 1) {
              return errors[0].reason;
            } else {
              throw new AggregateError(
                errors.map((result: PromiseRejectedResult): unknown => {
                  return result.reason;
                }),
              );
            }
          }),
      );
    }

    await this.#closedPromise.promise!;
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.close();
  }

  /* TASKS */

  /**
   * Runs and appends a _task_ linked to this `Resource`.
   */
  async runTask<GReturn>(
    taskFnc: ResourceRunTaskFunction<GReturn> | Promise<GReturn>,
  ): Promise<GReturn> {
    this.#throwIfClosed();

    if (typeof taskFnc === 'function') {
      taskFnc = Promise.try<GReturn, [AbortSignal]>(taskFnc, this.#controller.signal);
    }

    if (this.#pendingTasks.has(taskFnc)) {
      throw new Error('Task already running.');
    }

    this.#pendingTasks.add(taskFnc);

    try {
      return await taskFnc;
    } finally {
      this.#pendingTasks.delete(taskFnc);
    }
  }

  /**
   * Registers a _function_ to run before this `Resource` is closed.
   */
  beforeClosed(cleanupFnc: ResourceBeforeClosedFunction, { signal }: Abortable = {}): this {
    this.#throwIfClosed();

    if (signal === undefined) {
      this.#beforeClosed.push(cleanupFnc);
    } else {
      if (!signal.aborted) {
        this.#beforeClosed.push(cleanupFnc);

        signal.addEventListener(
          'abort',
          (): void => {
            this.#beforeClosed.splice(this.#beforeClosed.indexOf(cleanupFnc), 1);
          },
          {
            signal: AbortSignal.any([this.#controller.signal, signal]),
          },
        );
      }
    }

    return this;
  }

  fork<GResource extends ResourceTrait>(
    resource: GResource,
    { mode = 'soft', signal }: ResourceForkOptions = {},
  ): GResource {
    switch (mode) {
      case 'soft': {
        const controller: AbortController = new AbortController();

        this.beforeClosed((reason: unknown): Promise<void> => resource.close(reason), {
          signal:
            signal === undefined ? controller.signal : AbortSignal.any([signal, controller.signal]),
        });

        resource.closed.finally((): void => {
          // if `resource` (the child) closes before this `Resource` (the parent), then we remove the `beforeClosed`
          if (!this.#controller.signal.aborted) {
            controller.abort();
          }
        });
        break;
      }
      case 'hard': {
        this.beforeClosed((reason: unknown): Promise<void> => resource.close(reason), { signal });
        break;
      }
    }

    return resource;
  }
}
