import { runSequentiallyVoidPromiseFactories } from '../../helpers/run-sequentially-void-promise-factories.js';
import { Resource } from '../../resource/resource.js';
import { type OnCloseResource } from '../../resource/types/on-close-resource.js';

// ContextualResource
// ManagedResource
// GuidedResource
// SupervisedResource

export class GuidedResource extends Resource {
  static #close: OnCloseResource[] = [];

  static use<GArguments extends readonly any[], GReturn>(
    close: OnCloseResource,
    callback: (...args: GArguments) => GReturn,
    ...args: GArguments
  ): GReturn {
    this.#close.push(close);

    try {
      return callback(...args);
    } finally {
      this.#close.pop();
    }
  }

  static #getClose(close?: OnCloseResource): OnCloseResource | undefined {
    if (GuidedResource.#close.length === 0) {
      return close;
    } else {
      const snapshot: readonly OnCloseResource[] = GuidedResource.#close.toReversed();
      return (reason: unknown): Promise<void> => {
        return runSequentiallyVoidPromiseFactories(snapshot, reason);
      };
    }
  }

  constructor(close?: OnCloseResource) {
    super(GuidedResource.#getClose(close));
  }
}
