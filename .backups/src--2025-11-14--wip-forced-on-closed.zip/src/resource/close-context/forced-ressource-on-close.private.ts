import { type OnCloseResource } from '../types/on-close-resource.js';

let FORCED_RESSOURCE_ON_CLOSE: OnCloseResource | undefined = undefined;

export function getForcedResourceOnClose(): OnCloseResource | undefined {
  return FORCED_RESSOURCE_ON_CLOSE;
}

export function forceResourcesToAdoptThisOnclose<GReturn>(
  close: OnCloseResource | undefined,
  callback: () => GReturn,
): GReturn {
  let previousOnClose: OnCloseResource | undefined = FORCED_RESSOURCE_ON_CLOSE;
  FORCED_RESSOURCE_ON_CLOSE = close;
  try {
    return callback();
  } finally {
    FORCED_RESSOURCE_ON_CLOSE = previousOnClose;
  }
}
