import { describe } from 'vitest';

describe.todo('SharedResource', () => {});
