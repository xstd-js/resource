import { type SharedResourceFactoryOptionsForConsumer } from '../../../shared/shared-resource-factory.js';

export interface MqttSubscriptionResourceOptions extends SharedResourceFactoryOptionsForConsumer {
  readonly qos?: 0 | 1 | 2;
  readonly noLocal?: boolean;
  readonly retainAsPublished?: boolean;
  readonly retainHandling?: 0 | 1 | 2;
}
